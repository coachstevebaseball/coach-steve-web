import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

const BatSpeed101Page = ({ isEmbedded = false }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);

  return (
    <div className={cn(
      "flex flex-col overflow-hidden w-full max-w-full",
      isEmbedded 
        ? "h-full min-h-[500px] md:min-h-[700px] relative bg-transparent rounded-[var(--r-xl)] shadow-[var(--sh-lg)]" 
        : "min-h-[100dvh] pt-[60px] md:pt-[70px] bg-navy-950"
    )}>
      {!isEmbedded && (
        <Helmet>
          <title>Bat Speed 101 | Improve Your Exit Velocity | Coach Steve</title>
          <meta name="description" content="Discover how to increase your bat speed and hit with more power with Coach Steve's Bat Speed 101." />
          <link rel="canonical" href="https://www.coachstevebaseball.com/bat-speed-101" />
          <meta property="og:title" content="Bat Speed 101 | Improve Your Exit Velocity | Coach Steve" />
          <meta property="og:url" content="https://www.coachstevebaseball.com/bat-speed-101" />
          <meta name="twitter:card" content="summary_large_image" />
          <meta name="twitter:title" content="Bat Speed 101 | Improve Your Exit Velocity | Coach Steve" />
          <meta property="og:image:alt" content="Bat Speed 101 Course" />
        </Helmet>
      )}

      <div className={cn(
        "relative flex-grow flex flex-col w-full max-w-full overflow-hidden @container",
        !isEmbedded && "h-[calc(100dvh-60px)] md:h-[calc(100dvh-70px)]"
      )}>
        {isLoading && !hasError && (
          <div className="absolute inset-0 flex items-center justify-center bg-navy-950/90 backdrop-blur-sm z-10 px-4">
            <div className="flex flex-col items-center gap-3 md:gap-4 text-center">
              <Loader2 className="w-10 h-10 md:w-12 md:h-12 text-red-500 animate-spin" />
              <p className="text-white text-sm md:text-base font-bold tracking-wider animate-pulse">Loading Course...</p>
            </div>
          </div>
        )}
        
        {hasError ? (
          <div className="absolute inset-0 flex items-center justify-center bg-navy-950 z-10 p-4 md:p-6 text-center">
            <div className="bg-navy-900 border border-red-500/30 p-6 md:p-8 rounded-xl w-full max-w-md shadow-2xl mx-auto">
              <h2 className="text-lg md:text-xl lg:text-2xl font-bold text-white mb-2 md:mb-3">Unable to load content</h2>
              <p className="text-sm md:text-base text-gray-400 mb-5 md:mb-6 leading-relaxed">There was an error loading the Bat Speed 101 course. Please try again later.</p>
              <button 
                onClick={() => {
                  setHasError(false);
                  setIsLoading(true);
                  const iframe = document.getElementById('bat-speed-iframe');
                  if (iframe) iframe.src = iframe.src;
                }}
                className="w-full sm:w-auto px-6 py-3 bg-red-500 text-white text-sm md:text-base font-bold rounded-lg hover:bg-red-600 transition-colors min-h-[44px]"
              >
                Retry Connection
              </button>
            </div>
          </div>
        ) : (
          <iframe
            id="bat-speed-iframe"
            src="https://batspeed.coachstevenbaseball.com/"
            title="Bat Speed 101 Course"
            className="w-full h-full border-0 flex-grow block absolute inset-0 object-cover"
            style={{ width: '100%', height: '100%' }}
            onLoad={() => setIsLoading(false)}
            onError={() => {
              setIsLoading(false);
              setHasError(true);
            }}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        )}
      </div>
    </div>
  );
};

export default BatSpeed101Page;