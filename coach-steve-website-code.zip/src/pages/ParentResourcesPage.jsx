import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { Trophy, MapPin, Target, Shield, TrendingUp, Clock, Flame, Check, X, FileText, Brain, Plus, PlayCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import ExitVelo101Page from './ExitVelo101Page';
import BatSpeed101Page from './BatSpeed101Page';

const ParentResourcesPage = () => {
  const [activeFaq, setActiveFaq] = useState(null);
  const [checkedItems, setCheckedItems] = useState({});

  const scrollToSection = (e, id) => {
    e.preventDefault();
    const element = document.getElementById(id);
    if (element) {
      const y = element.getBoundingClientRect().top + window.scrollY - 80;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  const toggleCheck = (id) => {
    setCheckedItems(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleFaq = (index) => {
    setActiveFaq(activeFaq === index ? null : index);
  };

  const checklists = [
    {
      id: 'prep',
      title: 'Session Prep',
      icon: <FileText className="w-6 h-6 text-[var(--red)]" />,
      items: [
        'Athlete has a bat that fits their height and weight',
        'Batting gloves and helmet ready',
        'Athletic clothing and cleats / turf shoes',
        'Water bottle for the session',
        'Athlete arrives 5–10 min early to warm up'
      ]
    },
    {
      id: 'mindset',
      title: 'Mindset Check',
      icon: <Brain className="w-6 h-6 text-[var(--red)]" />,
      items: [
        'Athlete genuinely wants to be there (not forced)',
        'Parent ready to let the coach coach',
        'Clear goal identified (EV, mechanics, approach)',
        'Realistic timeline expectations set (weeks, not days)',
        'Committed to at-home drill practice between sessions'
      ]
    },
    {
      id: 'recruiting',
      title: 'Recruiting Ready',
      icon: <Trophy className="w-6 h-6 text-[var(--red)]" />,
      items: [
        'Athlete\'s GPA maintained (3.0+ recommended)',
        'Highlight reel / skill video in progress',
        'Recruiting profile created (NCSA or similar)',
        'Showcase schedule planned for upcoming season',
        'Target school list started (5–10 realistic programs)'
      ]
    }
  ];

  const faqs = [
    {
      q: "How old should my child be to start private lessons?",
      a: "Coach Steve works with athletes as young as 8 years old. The key at that age isn't mechanics — it's developing a love for the game and building foundational movement patterns. Lessons are fully age-appropriate. A 9-year-old session looks nothing like a 16-year-old's session."
    },
    {
      q: "How many sessions before I see results?",
      a: "Confidence and awareness often shift after the first session. Mechanical changes take longer — the body needs repetitions to form new habits. Most athletes show measurable improvement in exit velocity and contact quality within the 5-session package. Significant game-day results typically take 3–6 months of consistent training. This is not a gimmick — it's real player development."
    },
    {
      q: "Should I watch sessions or wait outside?",
      a: "You're welcome to watch — especially early on. Many parents find it helpful to understand what's being worked on so they can support at home. The one request: let the coach coach. Avoid coaching from the side during the session. Your athlete performs better when they're not processing multiple voices at once."
    },
    {
      q: "My son/daughter is in a slump. Is that a good time to book?",
      a: "Yes — slumps are often the best time to work with a coach. We diagnose whether it's mechanical (something changed in the swing) or mental (approach/confidence). Sometimes a single session can identify and fix the root cause quickly. Slumps are data — not failures."
    },
    {
      q: "Will private lessons conflict with what the team coach teaches?",
      a: "Coach Steve is aware of this dynamic. The goal is always to support — not contradict — the team coach. If there's a specific team system in place, we'll work within it. The focus is on making your athlete better within their current environment, not creating mechanical confusion."
    },
    {
      q: "Where are sessions held?",
      a: "Sessions are held in Westbury, NY and at partnered facilities across Long Island. Indoor batting cage facilities are used during the offseason. Please mention your location when booking and Coach Steve will confirm the best facility option."
    },
    {
      q: "Can I get a recruiting consultation even if my son isn't doing regular sessions?",
      a: "Recruiting profile review and guidance is included in the 10-Session Package. For standalone consulting, reach out directly and Coach Steve can discuss options. Having navigated the D1 recruiting process firsthand — from Long Island to Stony Brook — the advice is practical and real."
    }
  ];

  return (
    <div className="bg-[var(--navy)] min-h-screen text-[var(--text)] font-inter selection:bg-[var(--red)] selection:text-white pb-20 w-full overflow-hidden">
      <Helmet>
        <title>Parent Resources | Coach Steve Baseball</title>
        <meta name="description" content="Everything Long Island baseball parents need to know about private lessons, recruiting, and supporting your athlete." />
        <link rel="canonical" href="https://www.coachstevebaseball.com/parent-resources" />
        <meta property="og:title" content="Parent Resources | Coach Steve Baseball" />
        <meta property="og:url" content="https://www.coachstevebaseball.com/parent-resources" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Parent Resources | Coach Steve Baseball" />
        <meta property="og:image:alt" content="Baseball Parent Resources" />
      </Helmet>

      {/* HERO SECTION */}
      <section className="relative min-h-[85svh] pt-[80px] flex items-center justify-center overflow-hidden w-full max-w-[100vw]">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://user-gen-media-assets.s3.amazonaws.com/gemini_images/5e9f1e39-9918-48c9-abd2-10c769f12c36.png" 
            alt="Baseball Training"
            className="w-full h-full object-cover object-[center_40%] opacity-[0.22]"
          />
          <div className="absolute inset-0 bg-[linear-gradient(110deg,rgba(10,5,5,.98)_0%,rgba(26,0,8,.9)_40%,rgba(20,20,20,.6)_100%)]" />
        </div>

        <div className="container relative z-10 mx-auto px-4 md:px-6 max-w-[1200px] flex flex-col items-center text-center reveal w-full">
          <div className="bg-[rgba(228,0,43,.15)] border border-[rgba(228,0,43,.4)] text-[#ff6b82] uppercase tracking-[.1em] font-bold px-4 py-1.5 rounded-full text-xs sm:text-sm mb-6">
            For Long Island Baseball Parents
          </div>
          
          <h1 className="font-barlow font-black uppercase leading-[.92] text-white text-5xl sm:text-6xl md:text-7xl lg:text-[5.5rem] mb-6 tracking-tight">
            EVERYTHING YOU NEED<br />TO KNOW.
          </h1>
          
          <p className="text-[var(--gray-300)] text-lg md:text-xl max-w-[55ch] mb-10 leading-relaxed mx-auto">
            Your guide to what private lessons actually do, how to support your athlete the right way, the recruiting timeline, and honest answers to every question parents ask.
          </p>

          <div className="flex flex-row flex-wrap justify-center gap-4 sm:gap-3 max-w-full">
            <a 
              href="https://coachstevenbaseball.com/contact" 
              className="bg-[var(--red)] hover:bg-[var(--red-hover)] text-white px-8 py-3.5 rounded-[var(--r-md)] font-bold transition-all duration-180 flex items-center gap-2 shadow-[var(--sh-md)] w-full sm:w-auto justify-center"
            >
              Book a Session &rarr;
            </a>
            <a 
              href="#guide" 
              onClick={(e) => scrollToSection(e, 'guide')}
              className="border border-[rgba(255,255,255,.15)] text-[var(--gray-300)] hover:border-[var(--red)] hover:text-white hover:bg-[rgba(228,0,43,.08)] px-6 py-3.5 rounded-[var(--r-md)] font-medium transition-all duration-180 w-full sm:w-auto text-center"
            >
              Parent Guide
            </a>
            <a 
              href="#minicourses" 
              onClick={(e) => scrollToSection(e, 'minicourses')}
              className="border border-[rgba(255,255,255,.15)] text-[var(--gray-300)] hover:border-[var(--red)] hover:text-white hover:bg-[rgba(228,0,43,.08)] px-6 py-3.5 rounded-[var(--r-md)] font-medium transition-all duration-180 w-full sm:w-auto text-center"
            >
              Free Mini-Courses
            </a>
            <a 
              href="#faq" 
              onClick={(e) => scrollToSection(e, 'faq')}
              className="border border-[rgba(255,255,255,.15)] text-[var(--gray-300)] hover:border-[var(--red)] hover:text-white hover:bg-[rgba(228,0,43,.08)] px-6 py-3.5 rounded-[var(--r-md)] font-medium transition-all duration-180 w-full sm:w-auto text-center"
            >
              FAQs
            </a>
          </div>
        </div>
      </section>

      {/* QUICK LINKS BAR */}
      <div className="w-full bg-[rgba(228,0,43,.12)] border-y border-[rgba(228,0,43,.2)] py-4 px-6 sticky top-[70px] z-40 backdrop-blur-md max-w-[100vw] overflow-hidden">
        <div className="max-w-[1200px] mx-auto flex flex-row flex-wrap items-center gap-x-8 gap-y-3">
          <span className="text-[var(--red)] text-xs font-extrabold uppercase tracking-[.12em]">JUMP TO:</span>
          {[
            { label: 'About Coach Steve', id: 'about-coach' },
            { label: 'What to Expect', id: 'guide' },
            { label: 'Mini-Courses', id: 'minicourses' },
            { label: 'How to Support Your Athlete', id: 'say' },
            { label: 'Recruiting Timeline', id: 'recruiting' },
            { label: 'Parent Checklist', id: 'checklist' },
            { label: 'FAQ', id: 'faq' }
          ].map(link => (
            <a 
              key={link.id}
              href={`#${link.id}`}
              onClick={(e) => scrollToSection(e, link.id)}
              className="text-xs font-semibold text-[var(--gray-300)] uppercase tracking-[.06em] hover:text-[var(--red)] transition-colors duration-180 after:content-['\2192'] after:ml-1.5"
            >
              {link.label}
            </a>
          ))}
        </div>
      </div>

      {/* FREE MINI-COURSES EMBED SECTION */}
      <section id="minicourses" className="py-24 bg-[var(--navy-card)] scroll-mt-20 border-t border-[var(--navy-border)] w-full max-w-[100vw] overflow-hidden">
        <div className="container mx-auto px-0 md:px-6 w-full max-w-full lg:max-w-[1200px] reveal">
          <div className="text-center mb-12 px-4 md:px-0">
            <span className="text-[var(--red)] font-bold uppercase tracking-wider text-sm mb-2 block">Free Education</span>
            <h2 className="font-barlow font-black uppercase text-4xl md:text-5xl text-white mb-4">FREE MINI-COURSES</h2>
            <p className="text-[var(--gray-300)] max-w-[60ch] mx-auto text-lg leading-relaxed">
              Equip your athlete with elite-level knowledge. Interactive mini-courses designed to help them understand the mechanics behind the metrics.
            </p>
          </div>

          <div className="flex flex-col gap-16 md:gap-24 w-full">
            {/* Exit Velo 101 Embed */}
            <div className="w-full bg-[var(--navy-2)] py-8 md:py-12 md:rounded-[var(--r-xl)] border-y md:border border-[var(--navy-border)] shadow-[var(--sh-lg)] flex flex-col items-center">
              <div className="px-4 md:px-8 mb-6 text-center max-w-[800px] w-full">
                <div className="inline-flex items-center gap-2 text-white bg-[var(--red)] font-black uppercase px-4 py-1.5 rounded-full text-xs tracking-wider mb-4">
                  <PlayCircle size={16} /> Course #1
                </div>
                <h3 className="text-3xl md:text-4xl font-barlow font-black text-white mb-2">EXIT VELO 101</h3>
                <p className="text-[var(--gray-300)] text-sm md:text-base">Master the physics of hitting harder and driving the ball with authority.</p>
              </div>
              <div className="w-full px-0 md:px-8 max-w-full">
                <div className="responsive-embed-container bg-black min-h-[500px] md:min-h-[700px] shadow-2xl relative w-full">
                  <ExitVelo101Page isEmbedded={true} />
                </div>
              </div>
            </div>

            {/* Bat Speed 101 Embed */}
            <div className="w-full bg-[var(--navy-2)] py-8 md:py-12 md:rounded-[var(--r-xl)] border-y md:border border-[var(--navy-border)] shadow-[var(--sh-lg)] flex flex-col items-center">
              <div className="px-4 md:px-8 mb-6 text-center max-w-[800px] w-full">
                <div className="inline-flex items-center gap-2 text-white bg-blue-600 font-black uppercase px-4 py-1.5 rounded-full text-xs tracking-wider mb-4">
                  <PlayCircle size={16} /> Course #2
                </div>
                <h3 className="text-3xl md:text-4xl font-barlow font-black text-white mb-2">BAT SPEED 101</h3>
                <p className="text-[var(--gray-300)] text-sm md:text-base">Learn the mechanical sequences required to generate elite bat speed.</p>
              </div>
              <div className="w-full px-0 md:px-8 max-w-full">
                <div className="responsive-embed-container bg-black min-h-[500px] md:min-h-[700px] shadow-2xl relative w-full">
                  <BatSpeed101Page isEmbedded={true} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ABOUT COACH SECTION */}
      <section id="about-coach" className="py-24 bg-[var(--navy)] scroll-mt-20 w-full max-w-[100vw] overflow-hidden">
        <div className="container mx-auto px-4 md:px-6 max-w-[1200px] reveal">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-[var(--red)] font-bold uppercase tracking-wider text-sm mb-2 block">Who You're Trusting</span>
              <h2 className="font-barlow font-black uppercase text-4xl md:text-5xl text-white mb-6 leading-tight">D1 PEDIGREE. PROVEN RESULTS.</h2>
              <p className="text-[var(--gray-300)] mb-8 text-lg leading-relaxed">
                Coach Steve isn't a former rec-league player with a YouTube channel. He competed at the highest level — and those experiences directly inform every drill and cue he gives your athlete.
              </p>
              
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="text-2xl mt-1">🏆</div>
                  <div>
                    <strong className="text-white block mb-1">Louisville Slugger Freshman All-American</strong>
                    <p className="text-[var(--text-muted)] text-sm leading-relaxed">Stony Brook University — .337 BA, 4 HR, 34 RBIs, 14 SB as a freshman</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="text-2xl mt-1">⚾</div>
                  <div>
                    <strong className="text-white block mb-1">2012 College World Series</strong>
                    <p className="text-[var(--text-muted)] text-sm leading-relaxed">Game-winning home run vs. LSU on ESPN. Competed against Aaron Judge, Alex Bregman, and other future MLB All-Stars</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="text-2xl mt-1">⛅</div>
                  <div>
                    <strong className="text-white block mb-1">Cape Cod Baseball League</strong>
                    <p className="text-[var(--text-muted)] text-sm leading-relaxed">Bourne Braves — one of the most prestigious collegiate summer leagues in the country</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="text-2xl mt-1">📍</div>
                  <div>
                    <strong className="text-white block mb-1">Long Island Native</strong>
                    <p className="text-[var(--text-muted)] text-sm leading-relaxed">St. Dominic HS standout, #1 ranked LI prospect Class of '11. Now giving back to the Island that built him</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="relative w-full overflow-hidden rounded-[var(--r-xl)]">
              <img 
                src="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/IMG_2386.JPG" 
                alt="Coach Steven Goldstein Hitting at the College World Series" 
                className="w-full h-[300px] md:h-[400px] object-cover shadow-[var(--sh-lg)]"
              />
              <div className="absolute bottom-2 left-2 md:bottom-[-1.5rem] md:left-[-2rem] bg-[rgba(0,0,0,.8)] border border-[rgba(228,0,43,.4)] p-3 md:p-4 rounded-[var(--r-lg)] backdrop-blur-sm shadow-xl z-10 max-w-[90%] md:max-w-none">
                <strong className="text-white block text-sm md:text-base">Coach Steve Goldstein</strong>
                <span className="text-[var(--gray-300)] text-[10px] md:text-xs block mt-1">Long Island • 10+ Years Coaching • 100+ Athletes Developed</span>
              </div>
            </div>
          </div>

          {/* STAT BANNER */}
          <div className="mt-20 bg-[linear-gradient(135deg,#1e0007_0%,rgba(228,0,43,.18)_50%,#1e0007_100%)] border border-[rgba(228,0,43,.25)] rounded-[var(--r-xl)] p-6 md:p-10 md:px-12 grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8 text-center reveal overflow-hidden">
            <div>
              <div className="font-barlow font-black text-3xl md:text-4xl lg:text-5xl text-[var(--red)] mb-2">100+</div>
              <strong className="text-white block text-xs md:text-sm mb-1 uppercase tracking-wider">Athletes Trained</strong>
              <span className="text-[var(--text-muted)] text-[10px] md:text-xs">Youth through college-bound</span>
            </div>
            <div>
              <div className="font-barlow font-black text-3xl md:text-4xl lg:text-5xl text-[var(--red)] mb-2">50+</div>
              <strong className="text-white block text-xs md:text-sm mb-1 uppercase tracking-wider">College Commits</strong>
              <span className="text-[var(--text-muted)] text-[10px] md:text-xs">D1, D2, D3, JUCO</span>
            </div>
            <div>
              <div className="font-barlow font-black text-3xl md:text-4xl lg:text-5xl text-[var(--red)] mb-2">10+</div>
              <strong className="text-white block text-xs md:text-sm mb-1 uppercase tracking-wider">Years on Long Island</strong>
              <span className="text-[var(--text-muted)] text-[10px] md:text-xs">Private instruction</span>
            </div>
            <div>
              <div className="font-barlow font-black text-3xl md:text-4xl lg:text-5xl text-[var(--red)] mb-2">.337</div>
              <strong className="text-white block text-xs md:text-sm mb-1 uppercase tracking-wider">Freshman BA</strong>
              <span className="text-[var(--text-muted)] text-[10px] md:text-xs">America East All-Rookie</span>
            </div>
          </div>
        </div>
      </section>

      {/* PARENT GUIDE SECTION */}
      <section id="guide" className="py-24 bg-[var(--navy-2)] scroll-mt-20 border-t border-[var(--navy-border)] w-full max-w-[100vw] overflow-hidden">
        <div className="container mx-auto px-4 md:px-6 max-w-[1200px] reveal w-full">
          <span className="text-[var(--red)] font-bold uppercase tracking-wider text-sm mb-2 block text-center">Parent Guide</span>
          <h2 className="font-barlow font-black uppercase text-4xl md:text-5xl text-white mb-4 text-center">WHAT PRIVATE LESSONS ACTUALLY DO</h2>
          <p className="text-[var(--gray-300)] text-center mb-12 max-w-[60ch] mx-auto text-lg px-4">Here's an honest look at what you can expect — and what takes real time.</p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full">
            <div className="bg-[var(--navy-card)] border border-[var(--navy-border)] rounded-[var(--r-xl)] p-6 md:p-8 transition-all duration-300 hover:-translate-y-1 hover:border-[rgba(228,0,43,.3)] hover:shadow-[var(--sh-lg)] flex flex-col">
              <TrendingUp className="w-8 h-8 text-[var(--red)] mb-4" />
              <h3 className="text-xl font-bold text-white mb-1">What Improves First</h3>
              <span className="text-[var(--text-muted)] text-sm mb-4 block">Visible in 1–3 sessions</span>
              <p className="text-[var(--gray-300)] text-sm mb-6 leading-relaxed flex-grow">Some changes are immediate because they're mental and mechanical cues that click right away.</p>
              <ul className="space-y-3">
                {['Confidence and body language at the plate', 'Tee work and practice rep quality', 'Awareness of their own swing mechanics', 'Bat path understanding and contact point'].map((item, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-[var(--gray-300)]">
                    <span className="text-[var(--red)] mt-1.5 text-[8px]">●</span> {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-[var(--navy-card)] border border-[var(--navy-border)] rounded-[var(--r-xl)] p-6 md:p-8 transition-all duration-300 hover:-translate-y-1 hover:border-[rgba(228,0,43,.3)] hover:shadow-[var(--sh-lg)] flex flex-col">
              <Clock className="w-8 h-8 text-[var(--red)] mb-4" />
              <h3 className="text-xl font-bold text-white mb-1">What Takes a Season</h3>
              <span className="text-[var(--text-muted)] text-sm mb-4 block">Consistent reps over time</span>
              <p className="text-[var(--gray-300)] text-sm mb-6 leading-relaxed flex-grow">The biggest mechanical gains come from repetition. These aren't shortcuts — they're real development.</p>
              <ul className="space-y-3">
                {['Exit velocity gains (avg +5–10 mph over 6 months)', 'Statline improvements (BA, hard-hit rate)', 'At-bat approach against off-speed pitching', 'Pressure performance and mental toughness'].map((item, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-[var(--gray-300)]">
                    <span className="text-[var(--red)] mt-1.5 text-[8px]">●</span> {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-[var(--navy-card)] border border-[var(--navy-border)] rounded-[var(--r-xl)] p-6 md:p-8 transition-all duration-300 hover:-translate-y-1 hover:border-[rgba(228,0,43,.3)] hover:shadow-[var(--sh-lg)] flex flex-col">
              <Flame className="w-8 h-8 text-[var(--red)] mb-4" />
              <h3 className="text-xl font-bold text-white mb-1">Your Role as a Parent</h3>
              <span className="text-[var(--text-muted)] text-sm mb-4 block">How to accelerate progress</span>
              <p className="text-[var(--gray-300)] text-sm mb-6 leading-relaxed flex-grow">The parent's role is significant. Here's what the most successful families do:</p>
              <ul className="space-y-3">
                {['Encourage at-home drill practice (15–20 min/day)', 'Watch session videos with your athlete', 'Ask "What did you work on?" — not "Did you fix it?"', 'Let the coach be the coach during games'].map((item, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-[var(--gray-300)]">
                    <span className="text-[var(--red)] mt-1.5 text-[8px]">●</span> {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* WHAT TO SAY SECTION */}
      <section id="say" className="py-24 bg-[var(--navy)] scroll-mt-20 border-t border-[var(--navy-border)] w-full max-w-[100vw] overflow-hidden">
        <div className="container mx-auto px-4 md:px-6 max-w-[1000px] reveal w-full">
          <div className="text-center mb-12">
            <span className="text-[var(--red)] font-bold uppercase tracking-wider text-sm mb-2 block">Game Day Parenting</span>
            <h2 className="font-barlow font-black uppercase text-4xl md:text-5xl text-white mb-4">WHAT TO SAY — AND WHAT NOT TO</h2>
            <p className="text-[var(--gray-300)] max-w-[70ch] mx-auto text-lg leading-relaxed px-4">
              Research and 10+ years of coaching make this clear: the right words after a game matter as much as the lesson itself.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
            <div className="bg-[var(--navy-card)] border border-[rgba(16,185,129,.3)] rounded-[var(--r-xl)] p-6 md:p-8">
              <div className="flex items-center gap-3 mb-6 border-b border-[rgba(16,185,129,.2)] pb-4">
                <div className="w-8 h-8 rounded-full bg-[rgba(16,185,129,.1)] flex items-center justify-center text-emerald-500">
                  <Check size={18} strokeWidth={3} />
                </div>
                <h3 className="text-xl font-bold text-white tracking-wide uppercase">SAY THIS</h3>
              </div>
              <ul className="space-y-4 mb-6">
                {[
                  "I love watching you play.",
                  "How did you feel out there today?",
                  "What's one thing you want to work on this week?",
                  "That was a tough at-bat — you competed hard.",
                  "Coach Steve showed me that drill — want to rep it?",
                  "The process is working. Trust it."
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3 text-[var(--text)]">
                    <span className="text-emerald-500 font-bold mt-0.5">+</span> <span className="flex-1">{item}</span>
                  </li>
                ))}
              </ul>
              <p className="text-sm text-[var(--text-muted)] italic leading-relaxed pt-4 border-t border-[var(--navy-border)]">
                The theme: focus on effort, process, and feelings — not results. Your athlete already knows when they struck out.
              </p>
            </div>

            <div className="bg-[var(--navy-card)] border border-[rgba(228,0,43,.3)] rounded-[var(--r-xl)] p-6 md:p-8">
              <div className="flex items-center gap-3 mb-6 border-b border-[rgba(228,0,43,.2)] pb-4">
                <div className="w-8 h-8 rounded-full bg-[rgba(228,0,43,.1)] flex items-center justify-center text-[var(--red)]">
                  <X size={18} strokeWidth={3} />
                </div>
                <h3 className="text-xl font-bold text-white tracking-wide uppercase">AVOID THIS</h3>
              </div>
              <ul className="space-y-4 mb-6">
                {[
                  "You should have swung at that pitch.",
                  "You were dropping your hands again.",
                  "Why didn't you do what Coach Steve taught you?",
                  "The other kid on your team hits way better.",
                  "Coaching from the stands during at-bats",
                  "Analyzing the performance on the car ride home"
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3 text-[var(--text)]">
                    <span className="text-[var(--red)] font-bold mt-0.5">−</span> <span className="flex-1">{item}</span>
                  </li>
                ))}
              </ul>
              <p className="text-sm text-[var(--text-muted)] italic leading-relaxed pt-4 border-t border-[var(--navy-border)]">
                Multiple coaches in a player's ear creates confusion. Trust the process. The car ride home should be peaceful — not a film session.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* RECRUITING TIMELINE SECTION */}
      <section id="recruiting" className="py-24 bg-[var(--navy-2)] scroll-mt-20 border-t border-[var(--navy-border)] w-full max-w-[100vw] overflow-hidden">
        <div className="container mx-auto px-4 md:px-6 max-w-[900px] reveal w-full">
          <div className="text-center mb-16">
            <span className="text-[var(--red)] font-bold uppercase tracking-wider text-sm mb-2 block">College Recruiting</span>
            <h2 className="font-barlow font-black uppercase text-4xl md:text-5xl text-white mb-4">THE RECRUITING TIMELINE BY GRADE</h2>
            <p className="text-[var(--gray-300)] max-w-[65ch] mx-auto text-lg leading-relaxed px-4">
              Recruiting has changed dramatically. Here's what your athlete should be doing — and when — to maximize their opportunity.
            </p>
          </div>

          <div className="relative pl-0 md:pl-[60px] w-full">
            <div className="hidden md:block absolute top-4 bottom-4 left-[40px] w-[2px] bg-[rgba(255,255,255,.07)]"></div>
            
            <div className="space-y-8 md:space-y-12">
              {[
                {
                  grade: '8th',
                  sub: 'Grade',
                  yearLabel: 'Year 1 of the Radar',
                  title: 'Foundation Building',
                  desc: 'Focus 100% on development. Travel ball exposure begins. This is NOT the time to reach out to coaches — it\'s the time to build the tools that make coaches reach out to you.',
                  tags: ['Travel Ball', 'Exit Velocity Baseline', 'Mechanics Foundation']
                },
                {
                  grade: 'FR',
                  sub: 'Year',
                  yearLabel: 'Freshman Year',
                  title: 'Develop & Be Seen',
                  desc: 'Play high school and travel ball. Start building measurable metrics (EV, sprint speed). Attend showcases at the right level. Coaches can make verbal offers beginning Sept. 1 of sophomore year.',
                  tags: ['Showcase Season', 'Metrics Development', 'Academic GPA']
                },
                {
                  grade: 'SO',
                  sub: 'Year',
                  yearLabel: 'Sophomore Year — The Pivot',
                  title: 'Active Outreach Begins',
                  desc: 'Build a recruiting profile (NCSA, BeRecruited). Email college coaches directly. Sept. 1 is when D1/D2 coaches can contact you. Identify your target school tier (D1, D2, D3, JUCO, Ivy).',
                  tags: ['Recruiting Profile', 'Coach Emails', 'Campus Visits', 'Sept. 1 Rule']
                },
                {
                  grade: 'JR',
                  sub: 'Year',
                  yearLabel: 'Junior Year — Decision Season',
                  title: 'Offers, Visits, Commits',
                  desc: 'Most D1 commitments happen junior year. Official/unofficial visits. If no D1 traction by fall, pivot yourtarget list. Coach Steve's recruiting profile review helps position athletes correctly for their level.',
                  tags: ['Verbal Offers', 'Official Visits', 'Commitment Decision']
                },
                {
                  grade: 'SR',
                  sub: 'Year',
                  yearLabel: 'Senior Year',
                  title: 'Sign & Continue Developing',
                  desc: 'Early signing period (November) and regular signing (February). If uncommitted, continue outreach — D1, D2, and JUCO programs recruit actively through April. Keep training. Coaches continue to monitor.',
                  tags: ['NLI Signing', 'College Active Recruiting', 'Spring Showcases']
                }
              ].map((item, i) => (
                <div key={i} className="flex flex-col md:flex-row gap-4 md:gap-6 relative w-full">
                  <div className="flex-shrink-0 flex md:block items-center gap-4">
                    <div className="w-[50px] h-[50px] md:w-[80px] md:h-[80px] rounded-full bg-[rgba(228,0,43,.1)] border border-[rgba(228,0,43,.3)] flex flex-col items-center justify-center md:absolute md:left-[-60px] md:top-0 z-10">
                      <span className="font-barlow font-black text-lg md:text-2xl text-[var(--red)] leading-none">{item.grade}</span>
                      <span className="text-[9px] md:text-xs text-white uppercase font-bold tracking-wider mt-1">{item.sub}</span>
                    </div>
                    <span className="md:hidden text-[var(--red)] text-xs font-bold uppercase tracking-wider">{item.yearLabel}</span>
                  </div>
                  <div className="bg-[var(--navy-card)] border border-[var(--navy-border)] p-6 md:p-8 rounded-[var(--r-xl)] flex-grow w-full">
                    <span className="hidden md:block text-[var(--red)] text-xs font-bold uppercase tracking-wider mb-2">{item.yearLabel}</span>
                    <h3 className="text-xl md:text-2xl font-bold text-white mb-3">{item.title}</h3>
                    <p className="text-[var(--text-muted)] text-sm md:text-base leading-relaxed mb-6">{item.desc}</p>
                    <div className="flex flex-wrap gap-2">
                      {item.tags.map((tag, j) => (
                        <span key={j} className="bg-[rgba(255,255,255,.05)] text-[var(--gray-300)] text-xs px-3 py-1 rounded-full border border-[rgba(255,255,255,.1)] whitespace-nowrap">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-12 bg-[rgba(228,0,43,.08)] border border-[rgba(228,0,43,.25)] rounded-[var(--r-xl)] p-6 md:p-8 w-full">
            <p className="text-[var(--gray-300)] leading-relaxed">
              <strong className="text-white">Coach Steve's Note:</strong> Specific Packages include a full recruiting profile review. We'll look at your athlete's measurables, highlight reel positioning, and target school list together — the same process I went through from Long Island to Stony Brook.
            </p>
          </div>
        </div>
      </section>

      {/* PARENT CHECKLIST SECTION */}
      <section id="checklist" className="py-24 bg-[var(--navy)] scroll-mt-20 border-t border-[var(--navy-border)] w-full max-w-[100vw] overflow-hidden">
        <div className="container mx-auto px-4 md:px-6 max-w-[1200px] reveal w-full">
          <div className="text-center mb-12">
            <span className="text-[var(--red)] font-bold uppercase tracking-wider text-sm mb-2 block">Interactive Checklist</span>
            <h2 className="font-barlow font-black uppercase text-4xl md:text-5xl text-white mb-4">IS YOUR ATHLETE READY TO TRAIN?</h2>
            <p className="text-[var(--gray-300)] max-w-[60ch] mx-auto text-lg leading-relaxed px-4">
              Click each item to track your preparation. Check these off before your first session.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 w-full">
            {checklists.map((list) => (
              <div key={list.id} className="bg-[var(--navy-card)] border border-[var(--navy-border)] rounded-[var(--r-xl)] p-6 md:p-8 w-full">
                <div className="flex items-center gap-3 mb-6 pb-4 border-b border-[var(--navy-border)]">
                  <div className="w-10 h-10 rounded-[var(--r-md)] bg-[rgba(228,0,43,.1)] flex items-center justify-center flex-shrink-0">
                    {list.icon}
                  </div>
                  <h3 className="text-lg md:text-xl font-bold text-white tracking-wide uppercase break-words">{list.title}</h3>
                </div>
                <div className="space-y-4">
                  {list.items.map((item, i) => {
                    const itemId = `${list.id}-${i}`;
                    const isChecked = checkedItems[itemId] || false;
                    return (
                      <div 
                        key={i} 
                        className="flex items-start gap-4 cursor-pointer group"
                        onClick={() => toggleCheck(itemId)}
                      >
                        <div className={cn(
                          "mt-0.5 w-5 h-5 flex-shrink-0 rounded-[var(--r-sm)] border transition-all duration-180 flex items-center justify-center",
                          isChecked 
                            ? "bg-[var(--red)] border-[var(--red)]" 
                            : "border-[rgba(255,255,255,.3)] bg-transparent group-hover:border-[var(--red)]"
                        )}>
                          {isChecked && <Check size={14} className="text-white" strokeWidth={3} />}
                        </div>
                        <span className={cn(
                          "text-sm leading-snug transition-all duration-180 select-none flex-1",
                          isChecked ? "text-[var(--text-muted)] line-through" : "text-[var(--gray-300)] group-hover:text-white"
                        )}>
                          {item}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ SECTION */}
      <section id="faq" className="py-24 bg-[var(--navy-2)] scroll-mt-20 border-t border-[var(--navy-border)] w-full max-w-[100vw] overflow-hidden">
        <div className="container mx-auto px-4 md:px-6 max-w-[800px] reveal w-full">
          <div className="text-center mb-12">
            <span className="text-[var(--red)] font-bold uppercase tracking-wider text-sm mb-2 block">Parent FAQ</span>
            <h2 className="font-barlow font-black uppercase text-4xl md:text-5xl text-white">QUESTIONS PARENTS ASK</h2>
          </div>

          <div className="flex flex-col gap-3 w-full">
            {faqs.map((faq, index) => {
              const isOpen = activeFaq === index;
              return (
                <div 
                  key={index} 
                  className={cn(
                    "bg-[var(--navy-card)] border rounded-[var(--r-xl)] overflow-hidden transition-colors duration-180 w-full",
                    isOpen ? "border-[rgba(228,0,43,.4)]" : "border-[rgba(255,255,255,.08)] hover:border-[rgba(228,0,43,.25)]"
                  )}
                >
                  <div 
                    className="flex justify-between items-center p-5 md:px-6 cursor-pointer select-none"
                    onClick={() => toggleFaq(index)}
                  >
                    <h3 className="font-semibold text-white pr-4 text-sm md:text-base leading-snug">{faq.q}</h3>
                    <div className="w-7 h-7 flex-shrink-0 rounded-full bg-[rgba(228,0,43,.1)] border border-[rgba(228,0,43,.3)] flex items-center justify-center text-[var(--red)] transition-transform duration-300" style={{ transform: isOpen ? 'rotate(45deg)' : 'rotate(0)' }}>
                      <Plus size={16} strokeWidth={2.5} />
                    </div>
                  </div>
                  <div 
                    className="overflow-hidden transition-all duration-400 ease-[cubic-bezier(.16,1,.3,1)]"
                    style={{ maxHeight: isOpen ? '400px' : '0px' }}
                  >
                    <p className="text-sm text-[var(--gray-300)] leading-relaxed px-5 md:px-6 pb-6 pt-0">
                      {faq.a}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA BANNER */}
      <section className="py-24 bg-[var(--navy)] border-t border-[var(--navy-border)] w-full max-w-[100vw] overflow-hidden">
        <div className="container mx-auto px-4 md:px-6 max-w-[1000px] reveal w-full">
          <div className="bg-[linear-gradient(135deg,#e4002b_0%,#b50020_100%)] rounded-[var(--r-xl)] p-8 md:p-12 text-center shadow-[var(--sh-lg)] w-full">
            <h2 className="font-barlow font-black uppercase text-3xl md:text-4xl text-white mb-4">READY TO GET YOUR ATHLETE STARTED?</h2>
            <p className="text-white/90 max-w-[52ch] mx-auto mb-8 text-sm md:text-lg">
              Limited sessions available each month. Reach out today and Coach Steve will respond within 24 hours.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full">
              <a 
                href="/booking"
                className="bg-white text-[var(--red)] font-extrabold uppercase tracking-wide px-8 py-4 rounded-[var(--r-md)] hover:bg-[#f0f0f0] transition-all duration-180 hover:-translate-y-[2px] w-full sm:w-auto text-sm md:text-base whitespace-nowrap"
              >
                Book a Training Session &rarr;
              </a>
              <a 
                href="/"
                className="bg-[rgba(255,255,255,.1)] border-2 border-[rgba(255,255,255,.4)] text-white font-bold uppercase tracking-wide px-8 py-3.5 rounded-[var(--r-md)] hover:bg-[rgba(255,255,255,.2)] transition-all duration-180 w-full sm:w-auto text-sm md:text-base whitespace-nowrap"
              >
                Visit Main Site
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ParentResourcesPage;