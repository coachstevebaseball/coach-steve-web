import React, { useRef, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  ArrowRight, 
  CheckCircle2, 
  MapPin, 
  Target, 
  Trophy, 
  Award, 
  Check, 
  Star, 
  Play 
} from 'lucide-react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.2 } }
};

// Video Card Component for Coach Steve Action Section
const VideoCard = ({ url, title, caption, delay, poster }) => {
  const videoRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const handlePlay = () => {
    if (videoRef.current) {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay }}
      className="bg-navy-950 rounded-2xl overflow-hidden border border-gray-800 shadow-2xl hover:border-red-500/30 hover:shadow-red-500/10 transition-all duration-300 group flex flex-col max-w-full"
    >
      <div className="relative aspect-video bg-black flex items-center justify-center overflow-hidden w-full">
        <video
          ref={videoRef}
          className="w-full h-full object-contain"
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
          controls={isPlaying}
          playsInline
          muted={!isPlaying}
          preload="metadata"
          poster={poster}
        >
          <source src={url} type="video/mp4" />
          Your browser does not support the video tag.
        </video>
        {!isPlaying && (
          <div
            className="absolute inset-0 bg-black/40 flex items-center justify-center cursor-pointer group-hover:bg-black/20 transition-all duration-300 min-h-[44px] min-w-[44px]"
            onClick={handlePlay}
            aria-label={`Play ${title}`}
          >
            <div className="w-16 h-16 bg-red-500/90 rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(239,68,68,0.5)] transform group-hover:scale-110 transition-transform duration-300 backdrop-blur-sm">
              <Play className="text-white ml-1.5" size={32} fill="currentColor" />
            </div>
          </div>
        )}
      </div>
      <div className="p-5 sm:p-6 md:p-8 flex-grow flex flex-col justify-center">
        <h3 className="text-lg sm:text-xl md:text-2xl font-black text-white mb-2 sm:mb-3 tracking-tight group-hover:text-red-500 transition-colors">{title}</h3>
        <p className="text-gray-400 text-sm md:text-base leading-relaxed">{caption}</p>
      </div>
    </motion.div>
  );
};

const HittingInstructorLongIsland = () => {
  const schemaData = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": "Coach Steve Baseball",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Westbury",
      "addressRegion": "NY",
      "postalCode": "11590"
    },
    "telephone": "516-428-8081",
    "areaServed": [
      "Roslyn",
      "Syosset",
      "Jericho",
      "Glen Cove",
      "Manhasset",
      "Great Neck",
      "Port Washington",
      "Old Westbury",
      "Westbury",
      "Nassau County"
    ]
  };

  const fadeInUp = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } }
  };

  const credentials = [
    "Louisville Slugger Division One All-American",
    "College World Series Outfielder",
    "Former Long Island #1 Prospect",
    "Game-Winning Home Run vs LSU on ESPN",
    "10+ years coaching experience",
    "100+ athletes trained & developed"
  ];

  const packages = [
    {
      tier: "STARTER",
      sessions: 12,
      total: 720,
      perSession: 60,
      label: "12 Sessions",
      badge: null,
      description: "The entry point. Premium instruction with no long-term commitment — perfect for new players and families who want to experience the process before going all in.",
      includes: [
        "Baseline swing evaluation & development plan",
        "Blast Motion swing analytics every session",
        "Session video breakdowns",
        "Access to Coach Steve's drill library"
      ],
      tagline: "Premium instruction. No discount. No fluff. Just results.",
      highlight: false,
      color: "border-white-800 hover:border-red-500/40",
      badgeBg: null,
    },
    {
      tier: "DEVELOPMENT",
      sessions: 24,
      total: 1320,
      perSession: 55,
      bonus: "2 FREE sessions ($240 value)",
      label: "24 Sessions",
      badge: "Most Popular",
      description: "This is where real development happens. Enough sessions to build, reinforce, and translate mechanics into game performance.",
      includes: [
        "2 FREE bonus 1-hour sessions",
        "Personalized training plan updated every 4 sessions",
        "200+ drill library with custom assigned drills",
        "Blast Motion swing analytics every session",
        "Session video breakdowns",
        "Direct access to Coach Steve between sessions"
      ],
      tagline: "Most families choose this package. The sweet spot between commitment and results.",
      highlight: true,
      color: "border-red-500/70 shadow-2xl shadow-red-500/10",
      badgeBg: "bg-red-500",
    },
    {
      tier: "ELITE",
      sessions: 48,
      total: 2400,
      perSession: 50,
      bonus: "4 FREE sessions ($480 value)",
      label: "48 Sessions",
      badge: "Most Popular for ages 12-16",
      description: "The complete development cycle. Enough time to fully rebuild mechanics, develop baseball IQ, and make improvements stick under real game pressure.",
      includes: [
        "4 FREE bonus 1-hour sessions",
        "Advanced AI swing analysis",
        "Weekly progress reports with updated metrics",
        "Priority booking & schedule lock-in",
        "Custom hitting portal with 200+ drills",
        "Session notes, swing video & metric tracking"
      ],
      tagline: "Maximum commitment. Maximum results.",
      highlight: true,
      color: "border-gray-800 hover:border-red-500/40",
      badgeBg: "bg-red-500",
    },
    {
      tier: "PRO TRACK",
      sessions: 72,
      total: 3240,
      perSession: 45,
      bonus: "6 FREE sessions ($720 value)",
      label: "72 Sessions",
      badge: "All In",
      description: "Built for the player who is all in. College-bound athletes, elite travel players, and anyone chasing the highest level of the game.",
      includes: [
        "6 FREE bonus 1-hour sessions",
        "Everything in the Elite Transformation plan",
        "Monthly 1-on-1 video consultation calls",
        "College recruiting exposure guidance",
        "Custom multi-year development roadmap",
        "VIP priority booking & unlimited drill library updates"
      ],
      tagline: "Total commitment to reaching the highest level.",
      highlight: false,
      color: "border-gray-800 hover:border-red-500/40",
      badgeBg: null,
    }
  ];

  const includedInAll = [
    {
      icon: "📋",
      title: "Personalized Training Plans",
      desc: "No two players are the same. Every session is built around your mechanics, your data, and your goals."
    },
    {
      icon: "🎥",
      title: "Session Video Breakdowns",
      desc: "Key drills are recorded and broken down using markup tools — you see the progress, not just feel it."
    },
    {
      icon: "📊",
      title: "Blast Motion Swing Analytics",
      desc: "Bat speed, attack angle, rotational acceleration, time to contact, and on-plane efficiency tracked every session."
    },
    {
      icon: "🎯",
      title: "200+ Drill Library Access",
      desc: "Personally created by Coach Steve and assigned based on your specific development needs."
    }
  ];

  return (
    <>
      <Helmet>
        <title>Hitting Instructor Long Island | Coach Steve Baseball</title>
        <meta name="description" content="Looking for a hitting instructor on Long Island? Coach Steve is a D1 All-American offering private baseball hitting lessons in Nassau County, NY." />
        <link rel="canonical" href="https://www.coachstevebaseball.com/hitting-instructor-long-island" />
        <meta property="og:title" content="Hitting Instructor Long Island | Coach Steve Baseball" />
        <meta property="og:url" content="https://www.coachstevebaseball.com/hitting-instructor-long-island" />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/cs-hr-celebration.png" />
        <meta property="og:image:alt" content="Coach Steve Hitting Instructor" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Hitting Instructor Long Island | Coach Steve Baseball" />
        <script type="application/ld+json">
          {JSON.stringify(schemaData)}
        </script>
      </Helmet>

      <div className="min-h-screen bg-navy-950 text-white font-sans overflow-x-hidden">

        {/* HERO SECTION */}
        <section className="py-10 sm:py-16 md:py-24 bg-[#0a0e12] relative overflow-hidden">
          <div className="absolute top-0 right-0 w-[300px] sm:w-[500px] h-[300px] sm:h-[500px] bg-[#e4002b]/5 rounded-full blur-[80px] sm:blur-[100px] pointer-events-none" />

          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col lg:flex-row items-center gap-8 sm:gap-10 lg:gap-24">

              {/* Image Side */}
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.8 }}
                className="w-full lg:w-1/2 relative group order-2 lg:order-1"
              >
                <div className="absolute -inset-1 bg-gradient-to-tr from-[#e4002b] to-transparent rounded-lg opacity-30 group-hover:opacity-60 transition-opacity duration-500 blur-sm"></div>

                <div className="relative rounded-lg overflow-hidden shadow-2xl bg-[#0f1419] max-h-[400px] sm:max-h-[500px] lg:max-h-none">
                  <div className="absolute top-3 left-3 sm:top-4 sm:left-4 z-20 bg-[#e4002b] text-white font-bold px-3 py-1 sm:px-4 sm:py-1 text-[10px] sm:text-xs uppercase tracking-widest rounded-sm shadow-lg">
                    COACH STEVE
                  </div>
                  <img
                    src="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/cs-hr-celebration.png"
                    alt="Coach Steve Goldstein"
                    className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 transform group-hover:scale-105"
                  />

                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black via-black/80 to-transparent p-5 sm:p-6 md:p-8 pt-20">
                    <h3 className="text-white font-montserrat font-bold text-lg sm:text-xl md:text-2xl mb-1">Steve Goldstein</h3>
                    <p className="text-[#e4002b] font-medium tracking-wide text-xs sm:text-sm md:text-base">D1 ALL-AMERICAN</p>
                  </div>
                </div>

                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  whileInView={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.5 }}
                  className="absolute -bottom-4 -right-4 sm:-bottom-6 sm:-right-6 bg-[#0f1419] border border-[#e4002b]/30 p-3 sm:p-4 rounded-lg shadow-xl hidden sm:flex items-center gap-3 z-30"
                >
                  <div className="bg-[#e4002b]/10 p-2 rounded-full">
                    <Trophy className="text-[#e4002b] w-5 h-5 sm:w-6 sm:h-6" />
                  </div>
                  <div>
                    <p className="text-white font-bold text-xs sm:text-sm">D1 All-American</p>
                    <p className="text-gray-400 text-[10px] sm:text-xs">Top Tier Experience</p>
                  </div>
                </motion.div>
              </motion.div>

              {/* Content Side */}
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.8 }}
                className="w-full lg:w-1/2 order-1 lg:order-2"
              >
                <div className="inline-flex items-center gap-2 mb-4 md:mb-6 bg-[#e4002b]/10 px-3 py-1.5 sm:px-4 sm:py-1.5 rounded-full border border-[#e4002b]/20">
                  <Award size={14} className="text-[#e4002b]" />
                  <span className="text-[#e4002b] text-[10px] sm:text-xs font-bold tracking-[0.2em] uppercase">
                    Elite Player Development
                  </span>
                </div>

                <h2 className="font-montserrat font-black text-3xl sm:text-4xl lg:text-5xl text-white mb-4 sm:mb-6 md:mb-8 leading-tight md:leading-[1.1]">
                  PRIVATE 1 ON 1 <br className="hidden sm:block" />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#e4002b] to-[#fff]">
                    SESSIONS
                  </span>
                </h2>

                <p className="text-gray-300 text-sm sm:text-base md:text-lg mb-6 sm:mb-8 md:mb-10 leading-relaxed font-light border-l-2 border-[#e4002b]/30 pl-4 md:pl-6">
                  This isn't random reps or copying someone else's swing.
                  Every session is built around <span className="text-white font-medium">how you move, how you think, and how the game actually plays out.</span>
                  We train mechanics, mindset, and game awareness so your work shows up when it matters — in real at-bats, under real pressure.
                </p>

                <ul className="space-y-3 md:space-y-4">
                  {credentials.map((cred, index) => (
                    <motion.li
                      key={index}
                      initial={{ opacity: 0, x: 20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.1 }}
                      className="flex items-start md:items-center gap-3 md:gap-4 group p-2 sm:p-2.5 rounded-lg hover:bg-white/5 transition-colors"
                    >
                      <div className="flex-shrink-0 w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-[#e4002b]/20 flex items-center justify-center border border-[#e4002b]/50 group-hover:bg-[#e4002b] transition-all mt-0.5 md:mt-0">
                        <Check className="text-[#e4002b] w-3 h-3 sm:w-3.5 sm:h-3.5 group-hover:text-white transition-colors" strokeWidth={3} />
                      </div>
                      <span className="text-white font-medium text-sm sm:text-base md:text-lg group-hover:text-[#e4002b] transition-colors leading-tight">
                        {cred}
                      </span>
                    </motion.li>
                  ))}
                </ul>
              </motion.div>

            </div>
          </div>
        </section>

        {/* SECTION 2: PACKAGE PRICING */}
        <section className="py-12 sm:py-16 md:py-24 bg-navy-900 px-4 sm:px-6 lg:px-8 border-t border-gray-800">
          <div className="container mx-auto max-w-7xl">

            {/* Header */}
            <div className="text-center mb-8 sm:mb-12">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="inline-flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-full px-3 py-1.5 sm:px-4 sm:py-1.5 mb-4 sm:mb-6"
              >
                <Star className="text-red-500 w-3 h-3 sm:w-3.5 sm:h-3.5" fill="currentColor" />
                <span className="text-red-500 font-black text-[10px] sm:text-xs tracking-widest uppercase">Private Hitting Lessons — Long Island</span>
              </motion.div>
              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="text-2xl sm:text-3xl md:text-5xl font-black font-montserrat mb-4"
              >
                Choose Your <span className="text-red-500">Development Path</span>
              </motion.h2>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className="text-gray-400 max-w-2xl mx-auto text-sm sm:text-base md:text-lg font-light leading-relaxed"
              >
                Each session is 30 minutes. Most players combine two back-to-back into one-hour blocks — that's the most effective format. Every package is built around your player's goals, not a generic program.
              </motion.p>
            </div>

            {/* Package Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5 sm:gap-6 mb-12 sm:mb-16">
              {packages.map((pkg, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className={`relative bg-navy-950 border rounded-2xl p-6 sm:p-7 flex flex-col transition-all duration-300 ${pkg.color} ${pkg.highlight ? 'ring-2 ring-red-500/40' : ''}`}
                >
                  {/* Badge */}
                  {pkg.badge && (
                    <div className={`absolute -top-3.5 left-1/2 -translate-x-1/2 ${pkg.badgeBg} text-white text-[10px] sm:text-xs font-black uppercase tracking-wider py-1 px-3 sm:px-4 rounded-full whitespace-nowrap`}>
                      {pkg.badge}
                    </div>
                  )}

                  {/* Tier Label */}
                  <p className="text-red-500 font-black text-[10px] sm:text-xs tracking-[0.2em] uppercase mb-4 mt-1">{pkg.tier}</p>

                  {/* Session Count - UPDATED UI */}
                  <div className="mb-4">
                    <span className="text-3xl sm:text-4xl font-bold text-white block leading-none">{pkg.label}</span>
                  </div>

                  {/* Price */}
                  <div className="mb-1">
                    <span className="text-2xl sm:text-3xl font-black text-gray-100">${pkg.total.toLocaleString()}</span>
                  </div>
                  <p className="text-gray-400 text-xs sm:text-sm mb-1">
                    <span className="text-white font-bold">${pkg.perSession}/session</span>
                  </p>
                  {pkg.bonus && (
                    <p className="text-red-400 text-[10px] sm:text-xs font-bold mb-4">+ {pkg.bonus}</p>
                  )}
                  {!pkg.bonus && <div className="mb-4" />}

                  <p className="text-gray-300 text-xs sm:text-sm leading-relaxed mb-5 sm:mb-6 border-l-2 border-red-500/20 pl-3">
                    {pkg.description}
                  </p>

                  {/* Includes */}
                  <ul className="space-y-2.5 mb-6 sm:mb-8 flex-grow">
                    {pkg.includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-2 sm:gap-2.5 text-xs sm:text-sm text-gray-300">
                        <div className="flex-shrink-0 w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-red-500/20 border border-red-500/40 flex items-center justify-center mt-0.5">
                          <Check className="text-red-400 w-2 h-2 sm:w-2.5 sm:h-2.5" strokeWidth={3} />
                        </div>
                        {item}
                      </li>
                    ))}
                  </ul>

                  {/* Tagline */}
                  <p className="text-gray-500 text-[10px] sm:text-xs italic leading-relaxed">{pkg.tagline}</p>

                </motion.div>
              ))}
            </div>

            {/* What's Included In All Programs */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-navy-950 border border-gray-800 rounded-2xl p-6 sm:p-8 md:p-12"
            >
              <h3 className="text-lg sm:text-xl md:text-2xl font-black text-white mb-2 text-center">What Every Player Gets</h3>
              <p className="text-gray-400 text-center text-xs sm:text-sm mb-8 sm:mb-10">Regardless of package — every player receives a fully individualized experience.</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
                {includedInAll.map((item, idx) => (
                  <div key={idx} className="flex flex-col gap-2 sm:gap-3 text-center sm:text-left items-center sm:items-start">
                    <span className="text-2xl sm:text-3xl">{item.icon}</span>
                    <h4 className="text-white font-bold text-sm sm:text-base">{item.title}</h4>
                    <p className="text-gray-400 text-xs sm:text-sm leading-relaxed max-w-[250px] sm:max-w-none">{item.desc}</p>
                  </div>
                ))}
              </div>
            </motion.div>

          </div>
        </section>

        {/* COACH STEVE IN ACTION SECTION */}
        <section className="py-12 sm:py-16 md:py-24 bg-navy-900 border-t border-red-500/10">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-6xl">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-10 sm:mb-16"
            >
              <h2 className="text-2xl sm:text-3xl md:text-5xl font-black font-montserrat mb-3 sm:mb-4">Coach Steve <span className="text-red-500">In Action</span></h2>
              <p className="text-gray-400 max-w-2xl mx-auto text-sm sm:text-base md:text-lg mb-6 sm:mb-8">Experience the elite playing career that backs up the coaching. Real results on college baseball's biggest stages.</p>
              <div className="w-16 sm:w-24 h-1 bg-red-500 mx-auto rounded-full"></div>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8 lg:gap-12">
              <VideoCard
                url="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/Coach%20Steven%20Hits%20Go%20Ahead%20Homerun%20to%20Beat%20LSU%20and%20Send%20Stony%20Brook%20to%20the%20College%20World%20Series.mov"
                title="Go-Ahead Homerun vs LSU"
                caption="Coach Steven's go-ahead homerun vs LSU that sent Stony Brook to the College World Series"
                delay={0.1}
                poster="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/cs-hr-celebration.png"
              />
              <VideoCard
                url="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/Videos/Steven%20Goldstein%20RBI%20single%20in%20Super%20Regional.mp4"
                title="RBI Single in Super Regional"
                caption="Steven Goldstein RBI single in Super Regional"
                delay={0.2}
                poster="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/cs-hr-celebration.png"
              />
            </div>
          </div>
        </section>

        {/* SECTION 4: Frequently Asked Questions */}
        <section className="py-12 sm:py-16 md:py-24 bg-navy-900 px-4 sm:px-6 lg:px-8 border-t border-gray-800">
          <div className="container mx-auto max-w-3xl">
            <div className="text-center mb-8 sm:mb-12">
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-black mb-3 sm:mb-4 font-montserrat">Frequently Asked Questions</h2>
              <div className="w-12 sm:w-16 h-1 bg-red-500 mx-auto rounded-full"></div>
            </div>

            <Accordion type="single" collapsible className="w-full space-y-3 sm:space-y-4">

              <AccordionItem value="item-1" className="border border-gray-800 bg-navy-950 px-4 sm:px-6 rounded-xl data-[state=open]:border-red-500/50 transition-colors">
                <AccordionTrigger className="text-left font-bold text-sm sm:text-base md:text-lg py-3 sm:py-4 hover:no-underline hover:text-red-500 min-h-[44px]">
                  Where are lessons held?
                </AccordionTrigger>
                <AccordionContent className="text-gray-300 text-xs sm:text-sm md:text-base leading-relaxed pb-4">
                  Lessons are held at Baseball Plus in Hicksville, NY.
                  I work with players from across Long Island, including Roslyn, Syosset, Jericho, Glen Cove, Manhasset, and Great Neck.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-2" className="border border-gray-800 bg-navy-950 px-4 sm:px-6 rounded-xl data-[state=open]:border-red-500/50 transition-colors">
                <AccordionTrigger className="text-left font-bold text-sm sm:text-base md:text-lg py-3 sm:py-4 hover:no-underline hover:text-red-500 min-h-[44px]">
                  What ages do you train?
                </AccordionTrigger>
                <AccordionContent className="text-gray-300 text-xs sm:text-sm md:text-base leading-relaxed pb-4">
                  I typically work with players ages 10 and up.
                  Younger players focus on building awareness and fundamentals, while older players develop advanced approach, sequencing, and game strategy.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-3" className="border border-gray-800 bg-navy-950 px-4 sm:px-6 rounded-xl data-[state=open]:border-red-500/50 transition-colors">
                <AccordionTrigger className="text-left font-bold text-sm sm:text-base md:text-lg py-3 sm:py-4 hover:no-underline hover:text-red-500 min-h-[44px]">
                  How quickly will my player see results?
                </AccordionTrigger>
                <AccordionContent className="text-gray-300 text-xs sm:text-sm md:text-base leading-relaxed pb-4">
                  Most players feel improvement within the first 1–2 sessions — better timing, more solid contact, and a clearer approach.
                  <br /><br />
                  Real results typically show up within 3–6 weeks with consistent training.
                  <br /><br />
                  The difference here is we’re not just getting reps — we’re training mechanics, approach, and decision-making together so it actually shows up in games.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-4" className="border border-gray-800 bg-navy-950 px-4 sm:px-6 rounded-xl data-[state=open]:border-red-500/50 transition-colors">
                <AccordionTrigger className="text-left font-bold text-sm sm:text-base md:text-lg py-3 sm:py-4 hover:no-underline hover:text-red-500 min-h-[44px]">
                  How often should my player train?
                </AccordionTrigger>
                <AccordionContent className="text-gray-300 text-xs sm:text-sm md:text-base leading-relaxed pb-4">
                  For the best results, most players train 1–2 times per week.
                  <br /><br />
                  Consistency is what creates real development — one session helps, but consistent work is what leads to lasting improvement.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-5" className="border border-gray-800 bg-navy-950 px-4 sm:px-6 rounded-xl data-[state=open]:border-red-500/50 transition-colors">
                <AccordionTrigger className="text-left font-bold text-sm sm:text-base md:text-lg py-3 sm:py-4 hover:no-underline hover:text-red-500 min-h-[44px]">
                  What is the cancellation policy?
                </AccordionTrigger>
                <AccordionContent className="text-gray-300 text-xs sm:text-sm md:text-base leading-relaxed pb-4">
                  A 24-hour notice is required for cancellations or rescheduling.
                  <br /><br />
                  Sessions canceled within 24 hours may be forfeited.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-6" className="border border-gray-800 bg-navy-950 px-4 sm:px-6 rounded-xl data-[state=open]:border-red-500/50 transition-colors">
                <AccordionTrigger className="text-left font-bold text-sm sm:text-base md:text-lg py-3 sm:py-4 hover:no-underline hover:text-red-500 min-h-[44px]">
                  How long is each session?
                </AccordionTrigger>
                <AccordionContent className="text-gray-300 text-xs sm:text-sm md:text-base leading-relaxed pb-4">
                  Each session is 30 minutes.
                  <br /><br />
                  Most players combine two sessions into a one-hour block, which is typically the most effective format for development.
                  <br /><br />
                  All packages are structured around 30-minute sessions for flexibility.
                </AccordionContent>
              </AccordionItem>

            </Accordion>
          </div>
        </section>

      </div>
    </>
  );
};

export default HittingInstructorLongIsland;