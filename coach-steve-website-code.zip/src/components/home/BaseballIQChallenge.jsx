import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, XCircle, Brain, Target, ArrowRight } from 'lucide-react';

const BaseballIQChallenge = () => {
  const [answerState, setAnswerState] = useState(null);

  const handleAnswer = (isCorrect) => {
    setAnswerState(isCorrect ? 'correct' : 'incorrect');
  };

  const resetChallenge = () => {
    setAnswerState(null);
  };

  return (
    <section className="py-20 bg-navy-900 relative overflow-hidden border-t border-red-500/10">
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-red-500/5 rounded-full blur-[120px] pointer-events-none"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto"
        >
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 bg-navy-800 border border-red-500/30 px-4 py-1.5 rounded-full mb-4">
              <Brain className="w-4 h-4 text-red-500" />
              <span className="text-red-500 text-xs font-bold tracking-[0.2em] uppercase">Test Your IQ</span>
            </div>
            <h2 className="font-montserrat font-black text-3xl sm:text-4xl text-white mb-4">
              WHAT WOULD <span className="text-red-500">YOU DO?</span>
            </h2>
          </div>

          <div className="bg-navy-800 rounded-2xl overflow-hidden border border-red-500/20 shadow-2xl relative">
            <div className="bg-navy-950 border-b border-red-500/10 p-4 flex flex-wrap items-center justify-between gap-4 text-sm font-bold text-gray-300">
              <div className="flex items-center gap-6">
                <span className="flex items-center gap-2 text-red-500">
                   Bot 9th
                </span>
                <span className="w-1 h-1 bg-gray-600 rounded-full"></span>
                <span>Bases Loaded</span>
                <span className="w-1 h-1 bg-gray-600 rounded-full"></span>
                <span>Down 1</span>
                <span className="w-1 h-1 bg-gray-600 rounded-full"></span>
                <span className="text-white">Count 3-2</span>
              </div>
              <div className="flex gap-1">
                 <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                 <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse delay-75"></div>
              </div>
            </div>

            <div className="p-6 sm:p-10">
              <div className="flex flex-col md:flex-row gap-8 items-start">
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-white mb-3">The Scenario</h3>
                  <p className="text-gray-300 text-lg leading-relaxed mb-6">
                    The infield is playing in to cut down the run at home. The pitcher has been living on the <span className="text-white font-semibold">outer-half</span> all game.
                  </p>
                  <p className="text-red-500 font-bold text-lg mb-6">
                    What is your approach on the payoff pitch?
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <button
                      onClick={() => handleAnswer(true)}
                      disabled={answerState !== null}
                      className={`p-4 rounded-xl border-2 text-left transition-all relative overflow-hidden group min-h-[44px] ${
                        answerState === 'correct' 
                          ? 'bg-red-500/10 border-red-500 opacity-100'
                          : answerState === 'incorrect'
                          ? 'bg-navy-950 border-gray-700 opacity-50'
                          : 'bg-navy-900 border-gray-700 hover:border-red-500 hover:bg-red-500/5'
                      }`}
                    >
                      <div className="relative z-10">
                        <span className="block text-xs text-gray-400 uppercase tracking-widest mb-1 group-hover:text-red-500 transition-colors">Option A</span>
                        <span className="font-bold text-white text-lg">Drive it Gap-to-Gap</span>
                      </div>
                    </button>

                    <button
                      onClick={() => handleAnswer(false)}
                      disabled={answerState !== null}
                      className={`p-4 rounded-xl border-2 text-left transition-all relative overflow-hidden group min-h-[44px] ${
                        answerState === 'incorrect' 
                          ? 'bg-red-500/10 border-red-500 opacity-100'
                          : answerState === 'correct'
                          ? 'bg-navy-950 border-gray-700 opacity-50'
                          : 'bg-navy-900 border-gray-700 hover:border-red-500 hover:bg-red-500/5'
                      }`}
                    >
                      <div className="relative z-10">
                        <span className="block text-xs text-gray-400 uppercase tracking-widest mb-1 group-hover:text-red-400 transition-colors">Option B</span>
                        <span className="font-bold text-white text-lg">Pull for Power</span>
                      </div>
                    </button>
                  </div>
                </div>

                <div className="w-full md:w-[320px] min-h-[200px] flex items-center justify-center">
                  <AnimatePresence mode="wait">
                    {!answerState && (
                      <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="text-center p-6 border border-dashed border-gray-700 rounded-xl w-full"
                      >
                         <Target className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                         <p className="text-gray-500 font-medium">Select an option to see the breakdown</p>
                      </motion.div>
                    )}

                    {answerState === 'correct' && (
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="bg-green-500/10 border border-green-500/30 rounded-xl p-6 w-full"
                      >
                        <div className="flex items-center gap-3 mb-3">
                          <CheckCircle2 className="text-green-500 w-6 h-6" />
                          <h4 className="text-green-400 font-bold text-lg">Correct Call!</h4>
                        </div>
                        <p className="text-gray-300 text-sm leading-relaxed mb-4">
                          With the infield in, a hard ground ball is an out. Since he's working away, trying to pull will likely result in a rollover. Thinking gap-to-gap covers the outer pitch and lifts the ball over the drawn-in infield.
                        </p>
                        <button onClick={resetChallenge} className="text-xs font-bold text-green-500 uppercase hover:text-white transition-colors flex items-center gap-1">
                          Try Again <ArrowRight size={12} />
                        </button>
                      </motion.div>
                    )}

                    {answerState === 'incorrect' && (
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="bg-red-500/10 border border-red-500/30 rounded-xl p-6 w-full"
                      >
                         <div className="flex items-center gap-3 mb-3">
                          <XCircle className="text-red-500 w-6 h-6" />
                          <h4 className="text-red-400 font-bold text-lg">Swing & Miss</h4>
                        </div>
                        <p className="text-gray-300 text-sm leading-relaxed mb-4">
                          Pitcher is living away. Trying to pull an outer-half pitch usually results in a weak rollover to the pull side—exactly what the defense wants with the infield in.
                        </p>
                        <button onClick={resetChallenge} className="text-xs font-bold text-red-500 uppercase hover:text-white transition-colors flex items-center gap-1">
                          Try Again <ArrowRight size={12} />
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default BaseballIQChallenge;