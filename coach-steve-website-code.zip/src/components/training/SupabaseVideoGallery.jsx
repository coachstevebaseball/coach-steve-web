import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Play, RefreshCcw, AlertCircle, Video as VideoIcon } from 'lucide-react';
import { categories } from '@/data/trainingVideos';
import { supabase } from '@/lib/customSupabaseClient';
import { cn } from '@/lib/utils';

const SupabaseVideoGallery = () => {
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [videos, setVideos] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchVideos = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase
        .from('training_videos')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        throw new Error(error.message || 'Failed to fetch videos from database.');
      }
      
      setVideos(data || []);
    } catch (err) {
      console.error('Error fetching videos:', err);
      setError(err.message || 'An error occurred while loading videos.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchVideos();
  }, []);

  const filteredVideos = Array.isArray(videos) ? (
    selectedCategory === 'ALL' 
      ? videos 
      : videos.filter(video => video.category === selectedCategory)
  ) : [];

  return (
    <section className="py-16 md:py-24 bg-navy-950">
      <div className="container mx-auto px-4 md:px-8">
        
        <div className="flex flex-col md:flex-row items-end justify-between mb-12 gap-6">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-5xl font-black text-white mb-2 tracking-tight font-montserrat">
              TRAINING <span className="text-red-500">GALLERY</span>
            </h2>
            <p className="text-gray-400 max-w-xl text-lg font-light">
              Explore our comprehensive library of drills, mechanics breakdowns, and mental game insights.
            </p>
          </motion.div>
          
          <motion.div
             initial={{ opacity: 0, x: 20 }}
             whileInView={{ opacity: 1, x: 0 }}
             viewport={{ once: true }}
             className="hidden md:flex items-center gap-2 text-blue-600 font-bold text-sm"
          >
            <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
            <span>New Content Added Weekly</span>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12"
        >
          <div className="flex flex-wrap gap-3">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={cn(
                  'px-6 py-2 rounded-full text-xs font-bold tracking-widest uppercase transition-all duration-300',
                  selectedCategory === category 
                    ? 'bg-red-500 text-white shadow-lg shadow-red-500/20 border border-red-500' 
                    : 'bg-navy-900 text-gray-400 hover:bg-navy-800 hover:text-white border border-gray-800'
                )}
              >
                {category}
              </button>
            ))}
          </div>
        </motion.div>

        {isLoading ? (
          <div className="py-24 text-center">
            <div className="w-12 h-12 border-4 border-red-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-400 font-bold tracking-wider text-sm uppercase">Loading Library...</p>
          </div>
        ) : error ? (
          <div className="py-20 text-center bg-navy-900/50 rounded-2xl border border-red-500/20 max-w-2xl mx-auto">
            <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
            <p className="text-red-400 mb-6 text-lg">{error}</p>
            <button 
              onClick={fetchVideos} 
              className="inline-flex items-center gap-2 px-6 py-3 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors font-bold"
            >
              <RefreshCcw className="w-4 h-4" /> Try Again
            </button>
          </div>
        ) : (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
            >
              {filteredVideos.map((video, index) => (
                <Link
                  key={video.id}
                  to={`/videos/${video.id}`}
                  className="group"
                >
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: Math.min(index * 0.05, 0.5) }}
                    className="bg-navy-900 rounded-xl overflow-hidden border border-gray-800 hover:border-red-500/50 transition-all duration-300 h-full flex flex-col"
                  >
                    <div className="relative overflow-hidden aspect-video bg-black">
                      <img
                        src={video.thumbnail || 'https://placehold.co/640x360/1c2128/e4002b?text=Video'}
                        alt={video.title || "Video thumbnail"}
                        className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-transform duration-500 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-navy-950/90 via-navy-950/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center transform scale-0 group-hover:scale-100 transition-transform duration-300 shadow-xl">
                            <Play className="w-8 h-8 text-white ml-1" fill="currentColor" />
                          </div>
                        </div>
                      </div>
                      <div className="absolute top-3 right-3">
                        <span className="px-3 py-1 bg-red-500/90 backdrop-blur-sm text-white text-xs font-black rounded-full shadow-lg">
                          {(video.type || 'video').toUpperCase()}
                        </span>
                      </div>
                    </div>
                    <div className="p-5 flex-1 flex flex-col">
                      <h3 className="text-white font-bold text-lg mb-2 line-clamp-2 group-hover:text-red-500 transition-colors font-montserrat">
                        {video.title || 'Untitled Video'}
                      </h3>
                      <p className="text-gray-400 text-sm line-clamp-2 mb-4 font-light flex-1">
                        {video.description || 'No description available'}
                      </p>
                      <div className="flex items-center justify-between mt-auto border-t border-gray-800/50 pt-3">
                        <span className="text-blue-600 text-xs font-bold uppercase tracking-wider">
                          {video.category || 'Uncategorized'}
                        </span>
                      </div>
                    </div>
                  </motion.div>
                </Link>
              ))}
            </motion.div>

            {filteredVideos.length === 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-20 bg-navy-900/30 rounded-2xl border border-gray-800/50 mt-8"
              >
                <VideoIcon className="w-16 h-16 text-gray-700 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">No Content Available</h3>
                <p className="text-gray-400 text-lg max-w-md mx-auto">
                  {videos.length === 0
                    ? "The video gallery is currently empty."
                    : `No videos found matching the category "${selectedCategory}".`}
                </p>
              </motion.div>
            )}
          </>
        )}
      </div>
    </section>
  );
};

export default SupabaseVideoGallery;