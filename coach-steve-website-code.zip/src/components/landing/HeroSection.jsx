import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Mail, Phone } from 'lucide-react';

const HeroSection = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1, delayChildren: 0.3 } },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: "spring", stiffness: 100, damping: 10 } },
  };

  return (
    <section className="relative h-screen min-h-[700px] w-full flex items-center justify-center overflow-hidden bg-navy-950">
      <div className="absolute inset-0 z-0">
        <motion.div 
          initial={{ scale: 1.1 }}
          animate={{ scale: 1 }}
          transition={{ duration: 10, ease: "easeOut" }}
          className="w-full h-full"
        >
          <img 
            src="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/F25546AB-63AE-44C6-AF28-9D3038003419.png" 
            alt="College World Series Celebration" 
            className="w-full h-full object-cover opacity-60"
          />
        </motion.div>
        <div className="absolute inset-0 bg-gradient-to-b from-navy-950/90 via-navy-950/70 to-navy-950 z-10"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-navy-950/80 via-transparent to-navy-950/80 z-10"></div>
      </div>

      <motion.div 
        animate={{ y: [0, -20, 0], rotate: [0, 5, 0] }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-1/4 left-10 w-24 h-24 border-2 border-red-500/20 rounded-full z-10 hidden lg:block"
      />
      <motion.div 
        animate={{ y: [0, 20, 0], rotate: [0, -5, 0] }}
        transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 1 }}
        className="absolute bottom-1/4 right-10 w-32 h-32 border border-red-500/10 transform rotate-45 z-10 hidden lg:block"
      />

      <div className="container mx-auto px-4 z-20 relative flex flex-col items-center text-center">
        <motion.div variants={containerVariants} initial="hidden" animate="visible" className="max-w-5xl">
          <motion.div 
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="w-24 h-1 bg-red-500 mx-auto mb-8 rounded-full"
          />

          <motion.h2 variants={itemVariants} className="text-red-500 font-bold tracking-[0.2em] uppercase mb-4 text-sm sm:text-base">
            Elite Player Development
          </motion.h2>
          
          <motion.h1 variants={itemVariants} className="font-montserrat font-black text-5xl sm:text-6xl md:text-7xl lg:text-8xl text-white mb-6 leading-none tracking-tight">
            PRIVATE 1-ON-1 <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-red-300 to-red-500">LESSONS</span>
          </motion.h1>
          
          <motion.p variants={itemVariants} className="text-gray-300 text-lg sm:text-xl md:text-2xl mb-12 max-w-2xl mx-auto leading-relaxed font-light">
            Private baseball training built for players who want to hit better, think faster, and perform when the game speeds up.
          </motion.p>
          
          <motion.div variants={itemVariants} className="flex flex-col sm:flex-row gap-5 justify-center items-center mb-16">
            <motion.a 
              whileHover={{ scale: 1.05, boxShadow: "0 0 25px rgba(228, 0, 43, 0.4)" }}
              whileTap={{ scale: 0.95 }}
              href="mailto:coach@coachstevebaseball.com" 
              className="px-10 py-5 bg-gradient-to-r from-red-500 to-red-600 text-white font-black text-lg rounded-sm transition-all flex items-center gap-2 shadow-lg shadow-red-500/20 uppercase tracking-wide"
            >
              Start Training <ArrowRight size={20} className="stroke-[3px]" />
            </motion.a>
            <motion.a 
              whileHover={{ scale: 1.05, backgroundColor: "rgba(255,255,255,0.1)" }}
              whileTap={{ scale: 0.95 }}
              href="tel:5164288081" 
              className="px-10 py-5 border-2 border-white/30 backdrop-blur-sm text-white font-bold text-lg rounded-sm transition-all flex items-center gap-2 hover:border-white uppercase tracking-wide"
            >
              Book a Lesson
            </motion.a>
          </motion.div>

          <motion.div variants={itemVariants} className="flex flex-col sm:flex-row gap-6 justify-center text-gray-400 text-sm font-medium tracking-wide">
            <div className="flex items-center gap-2 hover:text-red-500 transition-colors cursor-pointer">
              <Mail size={16} className="text-red-500" />
              <span>coach@coachstevebaseball.com</span>
            </div>
            <div className="hidden sm:block text-red-500">•</div>
            <div className="flex items-center gap-2 hover:text-red-500 transition-colors cursor-pointer">
              <Phone size={16} className="text-red-500" />
              <span>516-428-8081</span>
            </div>
          </motion.div>
        </motion.div>
      </div>

      <motion.div 
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2 text-white/30 cursor-pointer"
        onClick={() => window.scrollTo({ top: window.innerHeight, behavior: 'smooth' })}
      >
        <div className="w-6 h-10 border-2 border-white/20 rounded-full flex justify-center p-1">
          <div className="w-1 h-2 bg-red-500 rounded-full"></div>
        </div>
      </motion.div>
    </section>
  );
};

export default HeroSection;