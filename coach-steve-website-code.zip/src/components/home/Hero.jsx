import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Mail, Phone } from 'lucide-react';

const HeroSection = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1, delayChildren: 0.3 } }
  };
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: "spring", stiffness: 100, damping: 10 } }
  };
  return (
    <section className="relative h-screen min-h-[600px] md:min-h-[700px] w-full flex items-center justify-center overflow-hidden bg-navy-950">
      <div className="absolute inset-0 z-0">
        <motion.div initial={{ scale: 1.1 }} animate={{ scale: 1 }} transition={{ duration: 10, ease: "easeOut" }} className="w-full h-full">
          <video 
            src="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/grok-video-dade37b4-3c6a-4a24-81ba-0198670f1e50.mp4" 
            autoPlay
            loop
            muted
            playsInline
            className="w-full h-full object-cover opacity-60 lg:opacity-75" 
          />
        </motion.div>
        {/* Adjusted gradient overlay opacity from 90/70 to 50/40 for better video visibility */}
        <div className="absolute inset-0 bg-gradient-to-b from-navy-950/50 via-navy-950/40 to-navy-950/60 z-10"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-navy-950/40 via-transparent to-navy-950/40 z-10"></div>
      </div>

      <motion.div animate={{ y: [0, -20, 0], rotate: [0, 5, 0] }} transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }} className="absolute top-1/4 left-10 w-24 h-24 border-2 border-red-500/20 rounded-full z-10 hidden lg:block" />
      <motion.div animate={{ y: [0, 20, 0], rotate: [0, -5, 0] }} transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 1 }} className="absolute bottom-1/4 right-10 w-32 h-32 border border-red-500/10 transform rotate-45 z-10 hidden lg:block" />

      <div className="container mx-auto px-4 z-20 relative flex flex-col items-center text-center py-16 md:py-32">
        <motion.div variants={containerVariants} initial="hidden" animate="visible" className="max-w-5xl w-full">
          <motion.div initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ duration: 1, delay: 0.5 }} className="w-16 h-1 md:w-24 bg-red-500 mx-auto mb-6 md:mb-8 rounded-full" />

          <motion.h2 variants={itemVariants} className="text-red-500 font-bold tracking-[0.2em] uppercase mb-4 text-xs sm:text-base"></motion.h2>

          <motion.h1 variants={itemVariants} className="font-montserrat font-black text-3xl sm:text-5xl md:text-7xl lg:text-8xl text-white mb-4 md:mb-6 leading-none tracking-tight drop-shadow-[0_2px_10px_rgba(0,0,0,0.5)]">
            PRIVATE 1-ON-1 <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-red-300 to-red-500">LESSONS</span>
          </motion.h1>

          <motion.p variants={itemVariants} className="text-white text-base sm:text-xl md:text-2xl mb-8 md:mb-12 max-w-2xl mx-auto leading-relaxed font-bold px-2 drop-shadow-md">
            Former D1 All-American at Stony Brook (2012 Louisville Slugger Freshman All-American, part of the legendary "Shock the World" College World Series run)
          </motion.p>

          <motion.div variants={itemVariants} className="flex flex-col sm:flex-row gap-4 sm:gap-5 justify-center items-center mb-12 md:mb-16 w-full sm:w-auto">
            <motion.a whileHover={{ scale: 1.05, boxShadow: "0 0 25px rgba(228, 0, 43, 0.4)" }} whileTap={{ scale: 0.95 }} href="mailto:coach@coachstevebaseball.com" className="w-full sm:w-auto px-8 py-4 md:px-10 md:py-5 bg-gradient-to-r from-red-500 to-red-600 text-white font-black text-base md:text-lg rounded-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-red-500/20 uppercase tracking-wide min-h-[44px]">
              Start Training <ArrowRight size={20} className="stroke-[3px]" />
            </motion.a>
            <motion.a whileHover={{ scale: 1.05, backgroundColor: "rgba(255,255,255,0.1)" }} whileTap={{ scale: 0.95 }} href="tel:5164288081" className="w-full sm:w-auto px-8 py-4 md:px-10 md:py-5 border-2 border-white/30 backdrop-blur-sm text-white font-bold text-base md:text-lg rounded-sm transition-all flex items-center justify-center gap-2 hover:border-white uppercase tracking-wide min-h-[44px]">
              Book a Lesson
            </motion.a>
          </motion.div>

          <motion.div variants={itemVariants} className="flex flex-col sm:flex-row gap-4 sm:gap-6 justify-center text-white/80 text-xs sm:text-sm font-bold tracking-wide">
            <div className="flex items-center justify-center gap-2 hover:text-red-500 transition-colors cursor-pointer min-h-[44px] sm:min-h-0 bg-navy-900/40 px-3 py-1 rounded-full backdrop-blur-sm">
              <Mail size={16} className="text-red-500" />
              <span>coach@coachstevebaseball.com</span>
            </div>
            <div className="hidden sm:block text-red-500 py-1">•</div>
            <div className="flex items-center justify-center gap-2 hover:text-red-500 transition-colors cursor-pointer min-h-[44px] sm:min-h-0 bg-navy-900/40 px-3 py-1 rounded-full backdrop-blur-sm">
              <Phone size={16} className="text-red-500" />
              <span>516-428-8081</span>
            </div>
          </motion.div>
        </motion.div>
      </div>

      <motion.div animate={{ y: [0, 10, 0] }} transition={{ duration: 2, repeat: Infinity }} className="absolute bottom-6 md:bottom-10 left-1/2 transform -translate-x-1/2 text-white/30 cursor-pointer" onClick={() => window.scrollTo({ top: window.innerHeight, behavior: 'smooth' })}>
        <div className="w-6 h-10 border-2 border-white/20 rounded-full flex justify-center p-1">
          <div className="w-1 h-2 bg-red-500 rounded-full"></div>
        </div>
      </motion.div>
    </section>
  );
};
export default HeroSection;