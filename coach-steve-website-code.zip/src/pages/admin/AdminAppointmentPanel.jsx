import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/hooks/use-toast';
import { Plus, Trash2, Calendar, Clock } from 'lucide-react';
import { Helmet } from 'react-helmet-async';

const AdminAppointmentPanel = () => {
  const [types, setTypes] = useState([]);
  const [slots, setSlots] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  // Form states
  const [newType, setNewType] = useState({ name: '', description: '', duration_options: '' });
  const [newSlot, setNewSlot] = useState({ appointment_type_id: '', date: '', start_time: '', duration_minutes: '', available_slots: 1 });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      const [typesRes, slotsRes] = await Promise.all([
        supabase.from('appointment_types').select('*').order('created_at', { ascending: false }),
        supabase.from('appointment_slots').select('*, appointment_types(name)').order('date').order('start_time')
      ]);
      if (typesRes.error) throw typesRes.error;
      if (slotsRes.error) throw slotsRes.error;
      
      setTypes(typesRes.data || []);
      setSlots(slotsRes.data || []);
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to fetch data', variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateType = async (e) => {
    e.preventDefault();
    try {
      const durationOptions = newType.duration_options.split(',').map(d => parseInt(d.trim())).filter(d => !isNaN(d));
      const { error } = await supabase.from('appointment_types').insert([{
        name: newType.name,
        description: newType.description,
        duration_options: durationOptions
      }]);
      if (error) throw error;
      toast({ title: 'Success', description: 'Appointment type created!' });
      setNewType({ name: '', description: '', duration_options: '' });
      fetchData();
    } catch (error) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  };

  const handleDeleteType = async (id) => {
    try {
      const { error } = await supabase.from('appointment_types').delete().eq('id', id);
      if (error) throw error;
      toast({ title: 'Success', description: 'Type deleted' });
      fetchData();
    } catch (error) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  };

  const handleCreateSlot = async (e) => {
    e.preventDefault();
    try {
      const { error } = await supabase.from('appointment_slots').insert([{
        appointment_type_id: newSlot.appointment_type_id,
        date: newSlot.date,
        start_time: newSlot.start_time,
        duration_minutes: parseInt(newSlot.duration_minutes),
        available_slots: parseInt(newSlot.available_slots)
      }]);
      if (error) throw error;
      toast({ title: 'Success', description: 'Slot created!' });
      setNewSlot({ appointment_type_id: '', date: '', start_time: '', duration_minutes: '', available_slots: 1 });
      fetchData();
    } catch (error) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  };

  const handleDeleteSlot = async (id) => {
    try {
      const { error } = await supabase.from('appointment_slots').delete().eq('id', id);
      if (error) throw error;
      toast({ title: 'Success', description: 'Slot deleted' });
      fetchData();
    } catch (error) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  };

  return (
    <div className="min-h-screen bg-navy-950 pt-24 pb-16 px-4">
      <Helmet>
        <title>Admin - Appointments | Coach Steve</title>
      </Helmet>
      
      <div className="container mx-auto max-w-7xl">
        <h1 className="text-3xl font-black text-white uppercase mb-8 border-b border-gray-800 pb-4">Manage Appointments</h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Appointment Types */}
          <div className="space-y-6">
            <div className="bg-navy-900 p-6 rounded-xl border border-gray-800">
              <h2 className="text-xl font-bold text-white mb-4 flex items-center">
                <Plus className="w-5 h-5 mr-2 text-red-500" /> Create Appointment Type
              </h2>
              <form onSubmit={handleCreateType} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">Name</label>
                  <input required type="text" value={newType.name} onChange={e => setNewType({...newType, name: e.target.value})} className="w-full bg-navy-950 border border-gray-700 rounded-lg p-2.5 text-white focus:border-red-500 outline-none" placeholder="e.g. 1-on-1 Hitting" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">Description</label>
                  <textarea value={newType.description} onChange={e => setNewType({...newType, description: e.target.value})} className="w-full bg-navy-950 border border-gray-700 rounded-lg p-2.5 text-white focus:border-red-500 outline-none h-24" placeholder="Brief description..." />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">Duration Options (minutes, comma separated)</label>
                  <input required type="text" value={newType.duration_options} onChange={e => setNewType({...newType, duration_options: e.target.value})} className="w-full bg-navy-950 border border-gray-700 rounded-lg p-2.5 text-white focus:border-red-500 outline-none" placeholder="e.g. 30, 60, 90" />
                </div>
                <button type="submit" className="w-full btn-red py-3">Create Type</button>
              </form>
            </div>

            <div className="bg-navy-900 p-6 rounded-xl border border-gray-800">
              <h2 className="text-xl font-bold text-white mb-4">Existing Types</h2>
              {isLoading ? <p className="text-gray-400">Loading...</p> : (
                <div className="space-y-3">
                  {types.map(t => (
                    <div key={t.id} className="flex justify-between items-center p-3 bg-navy-950 rounded-lg border border-gray-800">
                      <div>
                        <p className="text-white font-bold">{t.name}</p>
                        <p className="text-xs text-gray-400">{t.duration_options?.join(', ')} mins</p>
                      </div>
                      <button onClick={() => handleDeleteType(t.id)} className="text-gray-500 hover:text-red-500 p-2"><Trash2 size={16} /></button>
                    </div>
                  ))}
                  {types.length === 0 && <p className="text-gray-500 text-sm">No types created yet.</p>}
                </div>
              )}
            </div>
          </div>

          {/* Time Slots */}
          <div className="space-y-6">
            <div className="bg-navy-900 p-6 rounded-xl border border-gray-800">
              <h2 className="text-xl font-bold text-white mb-4 flex items-center">
                <Calendar className="w-5 h-5 mr-2 text-red-500" /> Create Time Slot
              </h2>
              <form onSubmit={handleCreateSlot} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">Appointment Type</label>
                  <select required value={newSlot.appointment_type_id} onChange={e => setNewSlot({...newSlot, appointment_type_id: e.target.value})} className="w-full bg-navy-950 border border-gray-700 rounded-lg p-2.5 text-white focus:border-red-500 outline-none">
                    <option value="">Select a type...</option>
                    {types.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-1">Date</label>
                    <input required type="date" value={newSlot.date} onChange={e => setNewSlot({...newSlot, date: e.target.value})} className="w-full bg-navy-950 border border-gray-700 rounded-lg p-2.5 text-white focus:border-red-500 outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-1">Start Time</label>
                    <input required type="time" value={newSlot.start_time} onChange={e => setNewSlot({...newSlot, start_time: e.target.value})} className="w-full bg-navy-950 border border-gray-700 rounded-lg p-2.5 text-white focus:border-red-500 outline-none" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-1">Duration (mins)</label>
                    <input required type="number" value={newSlot.duration_minutes} onChange={e => setNewSlot({...newSlot, duration_minutes: e.target.value})} className="w-full bg-navy-950 border border-gray-700 rounded-lg p-2.5 text-white focus:border-red-500 outline-none" min="1" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-1">Available Slots</label>
                    <input required type="number" value={newSlot.available_slots} onChange={e => setNewSlot({...newSlot, available_slots: e.target.value})} className="w-full bg-navy-950 border border-gray-700 rounded-lg p-2.5 text-white focus:border-red-500 outline-none" min="1" />
                  </div>
                </div>
                <button type="submit" className="w-full btn-red py-3">Create Slot</button>
              </form>
            </div>

            <div className="bg-navy-900 p-6 rounded-xl border border-gray-800 overflow-hidden">
              <h2 className="text-xl font-bold text-white mb-4">Upcoming Slots</h2>
              {isLoading ? <p className="text-gray-400">Loading...</p> : (
                <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                  {slots.map(s => (
                    <div key={s.id} className="flex justify-between items-center p-3 bg-navy-950 rounded-lg border border-gray-800">
                      <div>
                        <p className="text-white font-bold text-sm">{s.appointment_types?.name}</p>
                        <p className="text-xs text-gray-400">{s.date} @ {s.start_time} ({s.duration_minutes}m)</p>
                        <p className="text-xs text-red-400 mt-1">{s.available_slots - s.booked_slots} spots left</p>
                      </div>
                      <button onClick={() => handleDeleteSlot(s.id)} className="text-gray-500 hover:text-red-500 p-2"><Trash2 size={16} /></button>
                    </div>
                  ))}
                  {slots.length === 0 && <p className="text-gray-500 text-sm">No slots created yet.</p>}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminAppointmentPanel;