import React, { useState, useRef } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Target, Activity, Brain, LineChart, Star, ChevronRight, CheckCircle2, MapPin, Mail, Phone, Play } from 'lucide-react';
import { Link } from 'react-router-dom';

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.2 } }
};

// Video Card Component for Coach Steve Action Section
const VideoCard = ({ url, title, caption, delay, poster }) => {
  const videoRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const handlePlay = () => {
    if (videoRef.current) {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay }}
      className="bg-navy-950 rounded-2xl overflow-hidden border border-gray-800 shadow-2xl hover:border-red-500/30 hover:shadow-red-500/10 transition-all duration-300 group flex flex-col"
    >
      <div className="relative aspect-video bg-black flex items-center justify-center overflow-hidden w-full">
        <video
          ref={videoRef}
          className="w-full h-full object-contain"
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
          controls={isPlaying}
          playsInline
          muted={!isPlaying}
          preload="metadata"
          poster={poster}
        >
          <source src={url} type="video/mp4" />
          Your browser does not support the video tag.
        </video>
        {!isPlaying && (
          <div
            className="absolute inset-0 bg-black/40 flex items-center justify-center cursor-pointer group-hover:bg-black/20 transition-all duration-300 min-h-[44px] min-w-[44px]"
            onClick={handlePlay}
            aria-label={`Play ${title}`}
          >
            <div className="w-16 h-16 bg-red-500/90 rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(239,68,68,0.5)] transform group-hover:scale-110 transition-transform duration-300 backdrop-blur-sm">
              <Play className="text-white ml-1.5" size={32} fill="currentColor" />
            </div>
          </div>
        )}
      </div>
      <div className="p-6 md:p-8 flex-grow flex flex-col justify-center">
        <h3 className="text-xl md:text-2xl font-black text-white mb-3 tracking-tight group-hover:text-red-500 transition-colors">{title}</h3>
        <p className="text-gray-400 text-sm md:text-base leading-relaxed">{caption}</p>
      </div>
    </motion.div>
  );
};

const CoachSteveLandingPage = () => {
  const scrollToBooking = () => {
    document.getElementById('booking-section').scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="bg-navy-950 text-white min-h-screen font-sans">
      <Helmet>
        <title>Coach Steve Goldstein | Elite Baseball Hitting Coach Long Island</title>
        <meta name="description" content="Meet Coach Steve, an elite baseball hitting instructor specializing in swing mechanics and player development on Long Island." />
        <link rel="canonical" href="https://www.coachstevebaseball.com/coach-steve" />
        <meta property="og:title" content="Coach Steve Goldstein | Elite Baseball Hitting Coach Long Island" />
        <meta property="og:description" content="Meet Coach Steve, an elite baseball hitting instructor specializing in swing mechanics and player development on Long Island." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.coachstevebaseball.com/coach-steve" />
        <meta property="og:image" content="https://images.unsplash.com/photo-1521220023479-f7417d9a3465" />
        <meta property="og:image:alt" content="Coach Steve Baseball Training" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Coach Steve Goldstein | Elite Baseball Hitting Coach Long Island" />
      </Helmet>

      {/* Header */}
      <header className="absolute top-0 left-0 w-full z-50 py-6 px-4 md:px-8 border-b border-white/10">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 md:w-12 h-12 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center shadow-lg border border-red-400/30">
              <span className="text-white font-black text-lg md:text-xl">CS</span>
            </div>
            <div className="flex flex-col">
              <span className="text-white font-black text-base md:text-lg tracking-tight leading-none">COACH STEVE</span>
              <span className="text-red-500 text-[10px] md:text-xs font-bold tracking-wider">BASEBALL</span>
            </div>
          </div>
        </div>
      </header>

      {/* HERO SECTION */}
      <section className="relative min-h-screen flex items-center justify-center pt-24 pb-16 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1521220023479-f7417d9a3465?auto=format&fit=crop&q=80" 
            alt="Baseball field at night" 
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-navy-950/80 via-navy-950/90 to-navy-950"></div>
        </div>

        <div className="container mx-auto px-4 relative z-10 text-center max-w-4xl mt-12">
          <motion.div initial="hidden" animate="visible" variants={staggerContainer} className="space-y-6">
            <motion.div variants={fadeIn} className="inline-block mb-2">
              <span className="text-red-400 font-bold tracking-widest uppercase text-sm border border-red-500/30 px-4 py-1.5 rounded-full bg-red-500/10">
                Long Island's Premier Hitting Coach
              </span>
            </motion.div>
            <motion.h1 variants={fadeIn} className="text-4xl md:text-6xl lg:text-7xl font-black text-white leading-tight font-montserrat">
              Unlock Your Power: <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-red-600">Elite 1-on-1 Hitting</span> Instruction
            </motion.h1>
            <motion.p variants={fadeIn} className="text-lg md:text-xl text-gray-300 leading-relaxed max-w-2xl mx-auto">
              Train with former Freshman All-American and College World Series standout Steve Goldstein. We transform dedicated players into dominant hitters.
            </motion.p>
            <motion.div variants={fadeIn} className="pt-8">
              <button onClick={scrollToBooking} className="inline-flex items-center justify-center bg-gradient-to-r from-red-500 to-red-600 text-white font-black uppercase tracking-wider rounded-lg hover:scale-105 transition-transform duration-300 shadow-lg hover:shadow-red-500/20 px-8 py-4 text-lg group min-h-[44px]">
                Book Your First Session
                <ChevronRight className="ml-2 group-hover:translate-x-1 transition-transform" />
              </button>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* CREDIBILITY BAR */}
      <section className="py-8 bg-navy-900 border-y border-red-500/10 relative z-20">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center items-center gap-6 md:gap-12 text-center">
            {['Louisville Slugger Freshman All-American', 'College World Series', 'ESPN Featured', 'Big 12 Conference', 'Cape Cod League'].map((badge, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="flex items-center gap-2"
              >
                <Star className="text-red-500" size={16} fill="currentColor" />
                <span className="font-bold text-gray-300 tracking-wide text-sm md:text-base uppercase">{badge}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ABOUT COACH STEVE SECTION */}
      <section className="py-24 bg-navy-950 relative">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-black font-montserrat mb-4">From the College World Series <br className="hidden md:block"/>to <span className="text-red-500">Your Player's Swing</span></h2>
            <div className="w-24 h-1 bg-red-500 mx-auto rounded-full"></div>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative rounded-2xl overflow-hidden shadow-2xl border border-red-500/20 group"
            >
              <img 
                src="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/cs-dogpile.png" 
                alt="Coach Steve College Days" 
                className="w-full h-auto object-cover transform group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-navy-950/50 to-transparent opacity-90"></div>
              <div className="absolute bottom-6 left-6 right-6">
                 <p className="text-red-500 font-black text-xl tracking-widest uppercase mb-1 drop-shadow-md">Coach Steve Goldstein</p>
                 <p className="text-white font-medium">Former D1 All-American</p>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              <p className="text-gray-300 text-lg leading-relaxed">
                Steve Goldstein brings top-tier collegiate and elite summer league experience directly to Long Island's rising stars. He knows what it takes to succeed at the highest levels.
              </p>
              
              <ul className="space-y-4 mt-8">
                {[
                  "St. Dominic High School star & #1 Prospect on Long Island (2011)",
                  "Louisville Slugger Freshman All-American at Stony Brook University",
                  "Hit the game-winning HR vs. LSU to reach the College World Series",
                  "Competed in the prestigious Big 12 at University of Kansas",
                  "Played alongside MLB stars Aaron Judge and Kyle Schwarber in elite summer leagues"
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <CheckCircle2 className="text-red-500 shrink-0 mt-1" size={20} />
                    <span className="text-gray-200">{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          </div>
        </div>
      </section>

      {/* COACH STEVE IN ACTION SECTION */}
      <section className="py-24 bg-navy-900 border-t border-red-500/10">
        <div className="container mx-auto px-4 lg:px-8 max-w-6xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-black font-montserrat mb-4">Coach Steve <span className="text-red-500">In Action</span></h2>
            <p className="text-gray-400 max-w-2xl mx-auto text-lg mb-8">Experience the elite playing career that backs up the coaching. Real results on college baseball's biggest stages.</p>
            <div className="w-24 h-1 bg-red-500 mx-auto rounded-full"></div>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
            <VideoCard
              url="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/Videos/77248F6A-2015-428B-BA53-18DABEE74F5D.mp4"
              title="Go-Ahead Homerun vs LSU"
              caption="Coach Steven's go-ahead homerun vs LSU that sent Stony Brook to the College World Series"
              delay={0.1}
              poster="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/cs-hr-celebration.png"
            />
            <VideoCard
              url="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/Videos/Steven%20Goldstein%20RBI%20single%20in%20Super%20Regional.mp4"
              title="RBI Single in Super Regional"
              caption="Steven Goldstein RBI single in Super Regional"
              delay={0.2}
              poster="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/cs-hr-celebration.png"
            />
          </div>
        </div>
      </section>

      {/* HITTING PHILOSOPHY SECTION */}
      <section className="py-24 bg-gradient-to-b from-navy-900 to-navy-950 border-y border-red-500/10">
        <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-black font-montserrat mb-4">More Than Mechanics. <br/><span className="text-red-500">We Build Complete Hitters.</span></h2>
            <p className="text-gray-400 max-w-2xl mx-auto text-lg">Our proven four-pillar approach develops a swing that performs in games, not just in the cage.</p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Target, title: "Bat Speed & Power", desc: "Develop explosive power through proven swing mechanics and optimized hip rotation." },
              { icon: Activity, title: "Launch Angle & Consistency", desc: "Optimize your swing path to drive the ball for extra-base hits consistently." },
              { icon: Brain, title: "Plate Discipline & IQ", desc: "Learn to think like a pro, understand situational hitting, and dominate at-bats." },
              { icon: LineChart, title: "Measurable Progress", desc: "Utilize video analysis and performance metrics to track your real improvement." }
            ].map((pillar, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-navy-900 p-8 rounded-xl border border-gray-800 hover:border-red-500/50 shadow-lg hover:shadow-red-500/10 transition-all duration-300 group"
              >
                <div className="w-14 h-14 bg-gradient-to-br from-red-500 to-red-600 rounded-lg flex items-center justify-center mb-6 shadow-lg group-hover:scale-110 transition-transform duration-300">
                  <pillar.icon className="text-white" size={28} />
                </div>
                <h3 className="text-xl font-bold text-white mb-3 tracking-tight group-hover:text-red-500 transition-colors">{pillar.title}</h3>
                <p className="text-gray-400 leading-relaxed text-sm">{pillar.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* SUCCESS STORIES SECTION */}
      <section className="py-24 bg-navy-950 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-red-500/5 rounded-full blur-[120px] pointer-events-none"></div>
        <div className="container mx-auto px-4 max-w-6xl relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-black font-montserrat mb-4">Real Parents, <span className="text-red-500">Real Results</span></h2>
            <div className="w-24 h-1 bg-red-500 mx-auto rounded-full"></div>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-navy-900 p-8 md:p-10 rounded-2xl border border-gray-800 relative group hover:border-red-500/30 transition-colors"
            >
              <div className="text-red-500/20 text-6xl font-serif absolute top-4 left-6 group-hover:text-red-500/30 transition-colors">"</div>
              <p className="text-gray-300 text-lg leading-relaxed italic relative z-10 mb-6 mt-4">
                Steve entirely transformed my son's approach at the plate. Before, he was just swinging. Now, he has a plan, explosive power, and the confidence of a true hitter. The video analysis is next level.
              </p>
              <div className="flex items-center gap-4 border-t border-gray-800 pt-6">
                <div>
                  <p className="text-white font-bold">Mark T.</p>
                  <p className="text-red-500 text-sm font-medium tracking-wide">Parent of 14U Player</p>
                </div>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="bg-navy-900 p-8 md:p-10 rounded-2xl border border-gray-800 relative group hover:border-red-500/30 transition-colors"
            >
              <div className="text-red-500/20 text-6xl font-serif absolute top-4 left-6 group-hover:text-red-500/30 transition-colors">"</div>
              <p className="text-gray-300 text-lg leading-relaxed italic relative z-10 mb-6 mt-4">
                We've been to a dozen coaches on Long Island. Steve is the first one who actually played at an elite level and knows how to teach it. My son's bat speed increased by 12mph in just two months.
              </p>
              <div className="flex items-center gap-4 border-t border-gray-800 pt-6">
                <div>
                  <p className="text-white font-bold">Sarah L.</p>
                  <p className="text-red-500 text-sm font-medium tracking-wide">Parent of High School Varsity Player</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* BOOKING SECTION */}
      <section id="booking-section" className="py-24 bg-navy-900 border-t border-red-500/10">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="grid lg:grid-cols-5 gap-12">
            <div className="lg:col-span-2 space-y-8">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
              >
                <h2 className="text-3xl md:text-4xl font-black font-montserrat mb-4">Schedule a Call <span className="text-red-500">to Set Up Your FREE Asessment</span></h2>
                <p className="text-gray-400">Take the first step towards a dominant swing. Spots are limited as I work closely with a select group of dedicated athletes.</p>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="bg-navy-950 rounded-xl p-6 border border-gray-800"
              >
                <h3 className="text-white font-bold mb-4 uppercase tracking-widest text-sm border-b border-gray-800 pb-2">What's Included</h3>
                <ul className="space-y-3">
                  {[
                    "Initial Phone Call",
                    "Learn About Your Goals",
                    "Schedule Free Session",
                    "60-Minute Private Instruction",
                    "Personalized Swing Analysis",
                    "Video Breakdown of Mechanics",
                    "Custom Drills for At-Home Practice",
                    "Initial Player Assessment"
                  ].map((item, i) => (
                    <li key={i} className="flex items-center gap-3 text-sm text-gray-300">
                      <div className="w-1.5 h-1.5 rounded-full bg-red-500"></div>
                      {item}
                    </li>
                  ))}
                </ul>
              </motion.div>
            </div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="lg:col-span-3 bg-white rounded-2xl overflow-hidden shadow-2xl h-[700px] border-4 border-navy-950"
            >
              <iframe 
                src="https://calendly.com/coachstevebaseball/30min?hide_event_type_details=1&hide_gdpr_banner=1" 
                width="100%" 
                height="100%" 
                frameBorder="0" 
                title="Book Session"
                className="w-full h-full"
              ></iframe>
            </motion.div>
          </div>
        </div>
      </section>

      {/* FINAL CTA SECTION */}
      <section className="py-24 relative bg-navy-950 overflow-hidden text-center border-t border-red-500/10">
        <div className="absolute inset-0 bg-red-500/5"></div>
        <div className="container mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto space-y-8"
          >
            <h2 className="text-4xl md:text-5xl font-black font-montserrat text-white">Ready to Stop Seeing Your Son Struggle at the Plate?</h2>
            <p className="text-xl text-gray-300 leading-relaxed">
              Stop leaving your performance on the practice field. Let's build a swing that translates to success when it matters most.
            </p>
            <button onClick={scrollToBooking} className="inline-flex items-center justify-center bg-gradient-to-r from-red-500 to-red-600 text-white font-black uppercase tracking-wider rounded-lg hover:scale-105 transition-transform duration-300 shadow-lg hover:shadow-red-500/20 px-8 py-4 text-lg group mt-4 min-h-[44px]">
              Book an Assessment Now
              <ChevronRight className="ml-2 group-hover:translate-x-1 transition-transform" />
            </button>
          </motion.div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-navy-950 border-t border-red-500/10 pt-16 pb-8 relative z-10">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center shadow-lg border border-red-400/30">
                  <span className="text-white font-black text-xl">CS</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-white font-black tracking-tight leading-none text-xl">COACH STEVE</span>
                  <span className="text-red-500 text-[10px] font-bold tracking-wider">BASEBALL</span>
                </div>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed max-w-sm">
                Elite baseball training for dedicated athletes. Transform your game with college-level instruction.
              </p>
            </div>

            <div>
              <h4 className="text-white font-black mb-6 uppercase tracking-widest text-sm border-b-2 border-red-500/30 pb-2 inline-block">Contact Info</h4>
              <ul className="space-y-4">
                <li className="flex items-start gap-3 text-gray-400 text-sm group">
                  <div className="p-2 bg-navy-800 rounded-lg group-hover:bg-red-500/10 transition-colors border border-gray-800 group-hover:border-red-500/30">
                    <Mail size={16} className="text-red-500" />
                  </div>
                  <div className="flex flex-col justify-center min-h-[32px]">
                    <a href="mailto:coach@coachstevebaseball.com" className="hover:text-red-500 transition-colors">coach@coachstevebaseball.com</a>
                  </div>
                </li>
                <li className="flex items-start gap-3 text-gray-400 text-sm group">
                  <div className="p-2 bg-navy-800 rounded-lg group-hover:bg-red-500/10 transition-colors border border-gray-800 group-hover:border-red-500/30">
                    <Phone size={16} className="text-red-500" />
                  </div>
                  <div className="flex flex-col justify-center min-h-[32px]">
                    <a href="tel:5164288081" className="hover:text-red-500 transition-colors">516.428.8081</a>
                  </div>
                </li>
                <li className="flex items-start gap-3 text-gray-400 text-sm group">
                  <div className="p-2 bg-navy-800 rounded-lg group-hover:bg-red-500/10 transition-colors border border-gray-800 group-hover:border-red-500/30">
                    <MapPin size={16} className="text-red-500" />
                  </div>
                  <div className="flex flex-col justify-center min-h-[32px]">
                    <span>Baseball Plus, Hicksville, NY</span>
                  </div>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-black mb-6 uppercase tracking-widest text-sm border-b-2 border-red-500/30 pb-2 inline-block">Explore More</h4>
              <Link to="/" className="text-gray-400 hover:text-red-500 text-sm flex items-center gap-2 group transition-colors min-h-[44px]">
                <ChevronRight size={16} className="text-red-500 group-hover:translate-x-1 transition-transform" />
                Visit Main Website
              </Link>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 text-center md:flex md:justify-between md:text-left text-sm text-gray-500">
            <p>© {new Date().getFullYear()} Coach Steve Baseball. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default CoachSteveLandingPage;