import React, { useState, useEffect } from 'react';
import { X, Save } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { categories } from '@/data/trainingVideos';

const EditVideoModal = ({ isOpen, onClose, onSuccess, video }) => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    url: '',
    category: 'TRAINING',
    thumbnailUrl: ''
  });

  useEffect(() => {
    if (video) {
      setFormData({
        title: video.title || '',
        description: video.description || '',
        url: video.url || (video.video_id && video.type === 'youtube' ? `https://www.youtube.com/watch?v=${video.video_id}` : ''),
        category: video.category || 'TRAINING',
        thumbnailUrl: video.thumbnail || ''
      });
    }
  }, [video]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.title || !formData.url) {
      toast({
        title: "Validation Error",
        description: "Title and Video URL are required.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    try {
      let videoId = video.video_id;
      if (formData.url.includes('youtube.com/watch?v=')) {
        videoId = new URL(formData.url).searchParams.get('v');
      } else if (formData.url.includes('youtu.be/')) {
        videoId = formData.url.split('youtu.be/')[1].split('?')[0];
      }

      const { error } = await supabase
        .from('training_videos')
        .update({
          title: formData.title,
          description: formData.description,
          url: formData.url,
          video_id: videoId || formData.url,
          category: formData.category,
          thumbnail: formData.thumbnailUrl || (videoId ? `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg` : video.thumbnail)
        })
        .eq('id', video.id);

      if (error) throw error;

      toast({
        title: "Success!",
        description: "Video updated successfully",
      });
      
      onSuccess();
    } catch (error) {
      console.error('Error updating video:', error);
      toast({
        title: "Error",
        description: "Failed to update video. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen || !video) return null;

  const availableCategories = categories && categories.length > 0 
    ? categories.filter(c => c !== 'ALL') 
    : ['TRAINING', 'HITTING', 'FIELDING', 'PITCHING', 'MINDSET'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-navy-950/80 backdrop-blur-sm">
      <div className="bg-navy-900 rounded-xl border border-gray-800 w-full max-w-2xl overflow-hidden shadow-2xl">
        <div className="flex justify-between items-center p-6 border-b border-gray-800">
          <h2 className="text-xl font-black text-white">Edit Video</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-bold text-gray-300 mb-1">Title <span className="text-red-500">*</span></label>
            <input
              required
              type="text"
              name="title"
              value={formData.title}
              onChange={handleChange}
              className="w-full bg-navy-950 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-gold-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-300 mb-1">Description</label>
            <textarea
              name="description"
              rows="3"
              value={formData.description}
              onChange={handleChange}
              className="w-full bg-navy-950 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-gold-500 focus:outline-none resize-none"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-bold text-gray-300 mb-1">Video URL <span className="text-red-500">*</span></label>
              <input
                required
                type="url"
                name="url"
                value={formData.url}
                onChange={handleChange}
                className="w-full bg-navy-950 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-gold-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-300 mb-1">Category</label>
              <select
                name="category"
                value={formData.category}
                onChange={handleChange}
                className="w-full bg-navy-950 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-gold-500 focus:outline-none"
              >
                {availableCategories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-300 mb-1">Thumbnail URL</label>
            <input
              type="url"
              name="thumbnailUrl"
              value={formData.thumbnailUrl}
              onChange={handleChange}
              className="w-full bg-navy-950 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-gold-500 focus:outline-none"
            />
          </div>

          {/* Action Buttons Section */}
          <div className="flex justify-end items-center gap-4 mt-8 pt-6 border-t border-gray-800">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2.5 rounded-lg font-bold text-gray-400 hover:text-white hover:bg-white/5 transition-all border border-gray-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex items-center gap-2 px-8 py-2.5 bg-gradient-to-r from-gold-500 to-gold-600 text-navy-950 font-black rounded-lg hover:scale-105 active:scale-95 transition-all shadow-lg shadow-gold-500/10 disabled:opacity-50 disabled:hover:scale-100"
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-navy-950 border-t-transparent rounded-full animate-spin"></div>
                  Saving...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  Save
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditVideoModal;