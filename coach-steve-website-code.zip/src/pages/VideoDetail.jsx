import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { ArrowLeft, Play, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';

const VideoDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  const [video, setVideo] = useState(null);
  const [relatedVideos, setRelatedVideos] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchVideoData = async () => {
      setIsLoading(true);
      setError(null);
      try {
        // Use maybeSingle() to gracefully handle cases where the video ID doesn't exist
        const { data: mainVideo, error: mainError } = await supabase
          .from('training_videos')
          .select('*')
          .eq('id', id)
          .maybeSingle();

        if (mainError) {
          throw new Error(mainError.message || 'Failed to fetch video details.');
        }

        setVideo(mainVideo);

        // Fetch related videos if the main video was found
        if (mainVideo) {
          try {
            const { data: relatedData, error: relatedError } = await supabase
              .from('training_videos')
              .select('*')
              .eq('category', mainVideo.category)
              .neq('id', id)
              .limit(4);
              
            if (!relatedError && relatedData) {
              setRelatedVideos(relatedData);
            }
          } catch (relatedErr) {
            console.error('Failed to fetch related videos, non-fatal error:', relatedErr);
            // Non-fatal error, just leave related videos empty
            setRelatedVideos([]);
          }
        }
      } catch (err) {
        console.error('Error fetching video:', err);
        setError(err.message || 'An unexpected error occurred while loading the video.');
      } finally {
        setIsLoading(false);
      }
    };

    if (id) {
      fetchVideoData();
    }
  }, [id]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-navy-950 pt-24 pb-16 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-red-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle fatal error or video not found
  if (error || !video) {
    return (
      <div className="min-h-screen bg-navy-950 pt-24 pb-16 flex flex-col items-center justify-center">
        <div className="container mx-auto px-4 text-center max-w-2xl">
          <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <AlertCircle className="w-10 h-10 text-red-500" />
          </div>
          <h1 className="text-4xl font-black text-white mb-4">
            {error ? 'Error Loading Video' : 'Video Not Found'}
          </h1>
          <p className="text-gray-400 mb-8 text-lg">
            {error ? error : "The training video you're looking for doesn't exist or may have been removed."}
          </p>
          <Link
            to="/videos"
            className="inline-flex items-center gap-2 px-8 py-4 bg-red-500 text-white font-black rounded-lg hover:bg-red-600 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Video Library
          </Link>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>{video.title || 'Video Details'} - Coach Steve Baseball Training Videos</title>
        <meta name="description" content={video.description || 'Watch training video by Coach Steve'} />
      </Helmet>

      <div className="min-h-screen bg-navy-950 pt-24 pb-16">
        <div className="container mx-auto px-4 max-w-7xl">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4 }}
            className="mb-6"
          >
            <button
              onClick={() => navigate('/videos')}
              className="inline-flex items-center gap-2 text-gray-300 hover:text-red-500 transition-colors font-bold min-h-[44px] px-4"
            >
              <ArrowLeft className="w-5 h-5" />
              Back to Videos
            </button>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <div className="relative bg-navy-900 rounded-xl overflow-hidden border border-gray-800 mb-6 shadow-xl">
                  {video.video_id ? (
                    <div className="relative w-full" style={{ paddingBottom: '56.25%' }}>
                      <iframe
                        className="absolute top-0 left-0 w-full h-full"
                        src={`https://www.youtube.com/embed/${video.video_id}?autoplay=0&rel=0`}
                        title={video.title || "YouTube Video"}
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                      />
                    </div>
                  ) : video.url ? (
                    <video
                      className="w-full h-auto bg-black max-h-[70vh] object-contain"
                      controls
                      poster={video.thumbnail}
                    >
                      <source src={video.url} type="video/mp4" />
                      Your browser does not support the video tag.
                    </video>
                  ) : (
                    <div className="aspect-video flex flex-col items-center justify-center bg-black/50 text-gray-400">
                      <AlertCircle className="w-12 h-12 mb-4 opacity-50" />
                      <p className="font-medium">Video media is currently unavailable</p>
                    </div>
                  )}
                </div>

                <div className="bg-navy-900 rounded-xl px-4 py-6 md:px-8 md:py-8 border border-gray-800 shadow-lg">
                  <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-4">
                    <h1 className="text-2xl md:text-4xl font-black text-white leading-tight md:leading-snug">
                      {video.title}
                    </h1>
                    <span className="inline-block px-4 py-2 bg-red-500 text-white text-xs font-bold rounded-lg whitespace-nowrap self-start md:self-auto">
                      {(video.type || 'video').toUpperCase()}
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-3 mb-6">
                    <span className="px-4 py-1.5 bg-navy-950 text-red-500 text-sm font-bold rounded-full border border-red-500/30">
                      {video.category || 'Uncategorized'}
                    </span>
                  </div>

                  <p className="text-gray-300 text-lg leading-relaxed">
                    {video.description || 'No description provided for this video.'}
                  </p>
                </div>
              </motion.div>
            </div>

            <div className="lg:col-span-1">
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <h2 className="text-2xl font-black text-white mb-6">
                  Related Videos
                </h2>

                <div className="space-y-4">
                  {relatedVideos && relatedVideos.length > 0 ? (
                    relatedVideos.map((relatedVideo) => (
                      <Link
                        key={relatedVideo.id}
                        to={`/videos/${relatedVideo.id}`}
                        className="block group"
                      >
                        <div className="bg-navy-900 rounded-lg overflow-hidden border border-gray-800 hover:border-red-500/50 transition-all duration-300">
                          <div className="relative overflow-hidden bg-black">
                            <img
                              src={relatedVideo.thumbnail || 'https://placehold.co/320x180/1c2128/e4002b?text=Video'}
                              alt={relatedVideo.title || "Related video thumbnail"}
                              className="w-full aspect-video object-cover transition-transform duration-500 group-hover:scale-105 opacity-80 group-hover:opacity-100"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-navy-950/90 via-navy-950/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                              <div className="absolute inset-0 flex items-center justify-center">
                                <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center transform scale-0 group-hover:scale-100 transition-transform duration-300 shadow-xl">
                                  <Play className="w-6 h-6 text-white ml-0.5" fill="currentColor" />
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="p-4">
                            <h3 className="text-white font-bold text-sm mb-1 line-clamp-2 group-hover:text-red-500 transition-colors">
                              {relatedVideo.title}
                            </h3>
                            <p className="text-gray-400 text-xs line-clamp-2">
                              {relatedVideo.description}
                            </p>
                          </div>
                        </div>
                      </Link>
                    ))
                  ) : (
                    <div className="bg-navy-900 rounded-lg p-8 border border-gray-800 text-center">
                      <p className="text-gray-400 text-sm">
                        No related videos available in this category.
                      </p>
                    </div>
                  )}
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default VideoDetail;