import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Zap, Shield, Brain } from 'lucide-react';
import MagneticButton from '@/components/MagneticButton';
import TextRevealAnimation from '@/components/TextRevealAnimation';

const ServicesPreview = () => {
  const services = [
    {
      icon: <Zap className="w-8 h-8" />,
      title: 'HITTING',
      description: 'Develop power, consistency, and elite bat-to-ball skills with proven swing mechanics used by pros.',
      features: ['Bat Speed', 'Launch Angle', 'Plate Discipline']
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: 'DEFENSE',
      description: 'Master footwork, hands, and positioning to become a reliable defensive asset at any position.',
      features: ['Footwork', 'Glove Work', 'Quick Release']
    },
    {
      icon: <Brain className="w-8 h-8" />,
      title: 'BASEBALL IQ',
      description: 'Learn to think the game like a pro with situational awareness training and mental preparation.',
      features: ['Game Situations', 'Strategy', 'Anticipation']
    }
  ];

  return (
    <section className="py-24 bg-navy-950 relative overflow-hidden">
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl sm:text-5xl md:text-7xl font-black text-white mb-6 tracking-tighter leading-none">
            <TextRevealAnimation>
              COMPLETE PLAYER <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-red-600">DEVELOPMENT</span>
            </TextRevealAnimation>
          </h2>
          <div className="w-24 h-1.5 bg-gradient-to-r from-red-500 to-red-600 mx-auto mb-8 rounded-full"></div>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto font-light leading-relaxed">
            Every aspect of your game, elevated through personalized, data-driven training programs.
          </p>
        </motion.div>

        <div className="flex flex-col lg:flex-row-reverse items-center gap-16 max-w-7xl mx-auto">
          
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="w-full lg:w-5/12 space-y-6"
          >
             <div className="relative rounded-2xl overflow-hidden border border-red-500/30 shadow-2xl group bg-navy-900">
              <img 
                src="https://horizons-cdn.hostinger.com/643121a3-01b2-4510-8f0f-dff98ee493ee/a254cc502f094a58c5dc1028140425a9.png" 
                alt="INDIVIDUALIZED ATTENTION PERSONALIZED COACHING" 
                className="w-full h-auto object-cover transform group-hover:scale-105 transition-transform duration-700 ease-out"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-transparent to-transparent opacity-40"></div>
            </div>

            <div className="bg-navy-900/50 border border-red-500/20 p-6 rounded-xl text-center md:text-left">
              <h4 className="text-red-500 font-black text-sm uppercase tracking-[0.2em] mb-2">The Philosophy</h4>
              <p className="text-white text-lg font-medium italic">
                "Training built around how you move and think."
              </p>
            </div>

            <div className="relative rounded-2xl overflow-hidden border border-red-500/10 shadow-xl group bg-navy-900">
              <img 
                src="https://assets.zyrosite.com/OjCX9JtYPPwxfpnW/summer-league-zd1oc-5AUVqhZtxCDNUi3V.png" 
                alt="Northwoods League At-Bat" 
                className="w-full h-auto object-cover transform grayscale group-hover:grayscale-0 transition-all duration-700 ease-out aspect-[4/5] lg:aspect-auto"
                loading="lazy"
              />
            </div>
          </motion.div>

          <div className="w-full lg:w-7/12">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {services.map((service, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  whileHover={{ y: -5, scale: 1.02 }}
                  className={`bg-gradient-to-br from-navy-900 to-navy-950 border border-red-500/10 rounded-xl p-8 hover:border-red-500/50 transition-all duration-300 group shadow-lg ${index === 2 ? 'sm:col-span-2' : ''}`}
                >
                  <div className="w-14 h-14 rounded-lg bg-red-500/10 flex items-center justify-center mb-6 text-red-500 group-hover:bg-red-500 group-hover:text-white transition-colors duration-300">
                    {service.icon}
                  </div>
                  
                  <h3 className="text-xl font-black text-white mb-3 tracking-tight group-hover:text-red-500 transition-colors uppercase">
                    {service.title}
                  </h3>
                  
                  <p className="text-gray-400 text-sm mb-6 leading-relaxed font-medium">
                    {service.description}
                  </p>
                  
                  <div className="space-y-3 pt-4 border-t border-red-500/10">
                    {service.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center text-blue-600 text-xs font-bold uppercase tracking-widest">
                        <span className="w-1.5 h-1.5 bg-blue-600 rounded-full mr-3"></span>
                        {feature}
                      </div>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.6 }}
              className="mt-12 text-center lg:text-left"
            >
              <MagneticButton asChild className="h-auto p-0 border-none bg-transparent hover:bg-transparent w-full sm:w-auto">
                <a
                  href="/training"
                  className="inline-flex items-center justify-center bg-gradient-to-r from-red-500 to-red-600 text-white px-8 py-4 rounded-lg font-black text-lg tracking-widest hover:scale-105 transition-transform duration-300 shadow-xl shadow-red-500/20 uppercase w-full sm:w-auto"
                >
                  Explore Training Programs
                  <ArrowRight className="ml-3 stroke-[3px]" size={20} />
                </a>
              </MagneticButton>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServicesPreview;