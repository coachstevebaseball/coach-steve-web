import React from 'react';
import { Link } from 'react-router-dom';
import { Mail, Phone, Instagram, Twitter, Facebook, ArrowRight } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-navy-950 border-t border-red-500/10 pt-20 pb-10">
      <div className="container mx-auto px-4">
        <div className="relative overflow-hidden bg-navy-900 border border-gray-800 rounded-2xl p-10 mb-16 text-center shadow-2xl">
          <div className="absolute top-0 right-0 w-64 h-64 bg-red-500/5 rounded-full blur-3xl -mr-32 -mt-32 pointer-events-none"></div>
          
          <h4 className="text-white font-montserrat font-black text-3xl md:text-4xl mb-4 relative z-10">
            Ready to Elevate Your Game?
          </h4>
          <p className="text-gray-400 text-lg mb-8 max-w-2xl mx-auto font-light relative z-10">
            Join the ranks of elite players. Start your personalized training journey today with a plan built for you.
          </p>
          <Link 
            to="/training" 
            className="group relative inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-red-500 to-red-600 text-white font-black text-lg uppercase tracking-wider rounded-lg overflow-hidden transition-all duration-300 transform hover:scale-105 shadow-xl hover:shadow-red-500/20 z-10"
          >
            <span className="relative z-10 flex items-center gap-2">
              Get Started <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform stroke-[3px]" />
            </span>
            <div className="absolute inset-0 bg-white/20 transform -skew-x-12 translate-x-full group-hover:translate-x-0 transition-transform duration-500 ease-out"></div>
          </Link>
        </div>

        <div className="grid md:grid-cols-4 gap-12 mb-16">
          <div className="md:col-span-2 space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center shadow-lg border border-red-400/30">
                <span className="text-white font-black text-xl">CS</span>
              </div>
              <div className="flex flex-col">
                <span className="text-white font-black text-xl tracking-tight leading-none">COACH STEVE</span>
                <span className="text-red-500 text-xs font-bold tracking-widest">BASEBALL</span>
              </div>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed max-w-sm font-light">
              Developing the next generation of elite baseball players through professional instruction, mental conditioning, and advanced mechanics.
            </p>
            <div className="flex gap-4 pt-2">
              <a href="#" className="w-10 h-10 rounded-full bg-navy-900 flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-navy-800 transition-all border border-gray-800 hover:border-red-500/30">
                <Instagram size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-navy-900 flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-navy-800 transition-all border border-gray-800 hover:border-red-500/30">
                <Twitter size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-navy-900 flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-navy-800 transition-all border border-gray-800 hover:border-red-500/30">
                <Facebook size={18} />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-white font-black tracking-widest text-sm mb-6 uppercase border-b-2 border-red-500/30 pb-2 inline-block">Quick Links</h3>
            <ul className="space-y-3">
              {[
                { to: "/", label: "Home" },
                { to: "/about", label: "About Coach Steve" },
                { to: "/training", label: "Training Programs" },
                { to: "/training-gallery", label: "Gallery" },
                { to: "/testimonials", label: "Success Stories" },
                { to: "/blog", label: "Baseball Blog" }
              ].map((link) => (
                <li key={link.to}>
                  <Link to={link.to} className="text-gray-400 hover:text-red-500 transition-colors text-sm flex items-center gap-2 group">
                    <span className="w-1 h-1 rounded-full bg-red-500 opacity-0 group-hover:opacity-100 transition-opacity"></span>
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-white font-black tracking-widest text-sm mb-6 uppercase border-b-2 border-red-500/30 pb-2 inline-block">Contact</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-gray-400 text-sm group">
                <div className="p-2 bg-navy-800 rounded-lg group-hover:bg-red-500/10 transition-colors border border-gray-800 group-hover:border-red-500/30">
                  <Mail size={16} className="text-red-500" />
                </div>
                <div>
                  <span className="block text-white font-bold text-xs uppercase mb-1 tracking-wide">Email Us</span>
                  <a href="mailto:coach@coachstevebaseball.com" className="hover:text-red-500 transition-colors">coach@coachstevebaseball.com</a>
                </div>
              </li>
              <li className="flex items-start gap-3 text-gray-400 text-sm group">
                <div className="p-2 bg-navy-800 rounded-lg group-hover:bg-red-500/10 transition-colors border border-gray-800 group-hover:border-red-500/30">
                  <Phone size={16} className="text-red-500" />
                </div>
                <div>
                  <span className="block text-white font-bold text-xs uppercase mb-1 tracking-wide">Call / Text</span>
                  <a href="tel:5164288081" className="hover:text-red-500 transition-colors">516.428.8081</a>
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-center md:text-left">
          <p className="text-gray-600 text-xs">
            © {new Date().getFullYear()} Coach Steve Baseball. All rights reserved.
          </p>
          <div className="flex gap-6">
             <a href="#" className="text-gray-600 hover:text-white text-xs transition-colors">Privacy Policy</a>
             <a href="#" className="text-gray-600 hover:text-white text-xs transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;