import React from 'react';
import { motion } from 'framer-motion';
import { Star } from 'lucide-react';

const MLBStars = () => {
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: "spring", stiffness: 100, damping: 10 } }
  };

  const stars = [
    { name: 'AARON JUDGE', team: 'New York Yankees', achievement: 'AL MVP, Home Run Champion', image: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/Aaron%20Judge.jpeg' },
    { name: 'KYLE SCHWARBER', team: 'Philadelphia Phillies', achievement: 'All-Star, Power Hitter', image: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/MLB%20All-Star%20Kyle%20Schwarber.jpeg' },
    { name: 'ALEX BREGMAN', team: 'Houston Astros', achievement: 'World Series Champion', image: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/Alex%20Bregman.jpeg' },
    { name: 'AARON NOLA', team: 'Philadelphia Phillies', achievement: 'All-Star Pitcher', image: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/Aaron%20Nola.jpeg' },
    { name: 'JEFF MCNEIL', team: 'New York Mets', achievement: 'Batting Champion', image: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/Jeff%20McNeil%20.webp' }
  ];

  return (
    <section className="py-12 md:py-24 bg-navy-950 relative overflow-hidden">
      <div className="absolute inset-0 opacity-[0.03]" style={{backgroundImage: 'radial-gradient(#e4002b 1px, transparent 1px)', backgroundSize: '40px 40px'}}></div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={{
            hidden: { opacity: 0, y: 30 },
            visible: { opacity: 1, y: 0, transition: { duration: 0.6, staggerChildren: 0.1 } }
          }}
          className="text-center mb-10 md:mb-16"
        >
          <div className="inline-flex items-center gap-2 bg-red-500/10 border border-red-500 rounded-full px-5 py-2 mb-4 md:mb-6">
            <Star className="text-red-500" size={14} fill="#e4002b" />
            <span className="text-red-500 font-black text-xs tracking-[0.2em] uppercase">Top Tier Network</span>
          </div>
          
          <motion.h1 
            variants={itemVariants} 
            className="font-montserrat font-black text-3xl sm:text-5xl md:text-7xl lg:text-8xl text-white mb-4 md:mb-6 leading-none tracking-tight"
          >
            COMPETED ALONGSIDE <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-red-300 to-red-500">
              MLB STARS
            </span>
          </motion.h1>

          <div className="w-16 md:w-24 h-1.5 bg-gradient-to-r from-red-500 to-red-600 mx-auto mb-6 md:mb-8 rounded-full"></div>
          <p className="text-base md:text-xl text-gray-300 max-w-3xl mx-auto font-light leading-relaxed px-2">
            From the Cape Cod League to the Big 12 Conference, Coach Steve played with and against the best in the world.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6 max-w-7xl mx-auto">
          {stars.map((star, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -15, scale: 1.02 }}
              className="relative overflow-hidden rounded-2xl border border-red-500/30 shadow-2xl group h-[400px] md:h-[480px] bg-navy-900"
            >
              <img 
                src={star.image} 
                alt={`${star.name} - ${star.team}`}
                className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700 ease-out grayscale group-hover:grayscale-0"
                loading="lazy"
              />
              
              <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-navy-950/60 to-transparent opacity-90 transition-opacity duration-300 group-hover:opacity-80"></div>
              <div className="absolute inset-0 border-2 border-transparent group-hover:border-red-500 rounded-2xl transition-colors duration-300 pointer-events-none"></div>

              <div className="absolute bottom-0 left-0 right-0 p-6 z-20 flex flex-col justify-end h-full">
                 <div className="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                   <h3 className="text-xl md:text-2xl font-black text-white mb-1 tracking-tight leading-none uppercase drop-shadow-lg">
                     {star.name}
                   </h3>
                   <p className="text-blue-600 font-bold text-xs uppercase tracking-widest mb-3">
                      {star.team}
                    </p>
                   <div className="w-12 h-1 bg-red-500 mb-3 group-hover:w-full transition-all duration-500"></div>
                   <p className="text-gray-300 text-xs font-medium tracking-wide opacity-100 md:opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                     {star.achievement}
                   </p>
                 </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default MLBStars;