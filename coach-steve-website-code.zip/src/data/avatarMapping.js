export const avatarMapping = {
  'peter': {
    url: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/IMG_4038.png',
    playerId: 'peter-y'
  },
  'omar': {
    url: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/IMG_4062.jpeg',
    playerId: 'omar-g'
  },
  'mina': {
    url: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/IMG_4050.png',
    playerId: 'mina'
  },
  'adam': {
    url: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/IMG_4051.png',
    playerId: 'adam-goldstein'
  },
  'michelle': {
    url: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/IMG_4040.png',
    playerId: 'michelle-c'
  },
  'carlos': {
    url: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/IMG_4063.jpeg',
    playerId: 'carlos-vargas'
  },
  'mark': {
    url: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/IMG_4053.png',
    playerId: 'mark-w'
  },
  'kristina': {
    url: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/IMG_4052.png',
    playerId: 'kristina-g'
  },
  'kritstina': {
    url: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/IMG_4052.png',
    playerId: 'kristina-g'
  },
  'joseph': {
    url: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/IMG_4057.jpeg',
    playerId: 'joseph-hale'
  },
  'julia': {
    url: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/IMG_4061.jpeg',
    playerId: 'julia-zenger'
  },
  'mike': {
    url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200&h=200',
    playerId: 'mike-j'
  },
  'joe': {
    url: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=200&h=200',
    playerId: 'joe-m'
  }
};

export const getAvatarData = (fullName) => {
  if (!fullName) return {};
  const normalizedName = fullName.toLowerCase().trim();
  
  // Find a matching key in our robust mapping
  const matchKey = Object.keys(avatarMapping).find(key => normalizedName.includes(key));
  return matchKey ? avatarMapping[matchKey] : {};
};