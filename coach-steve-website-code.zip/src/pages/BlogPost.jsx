import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Clock, Calendar, ChevronLeft, Share2, ArrowRight, AlertTriangle } from 'lucide-react';
import { blogPosts } from '@/data/blogPosts';
import Footer from '@/components/Footer';
import { useToast } from '@/components/ui/use-toast';

const BlogPost = () => {
  const { slug } = useParams();
  const post = blogPosts.find(p => p.slug === slug);
  const { toast } = useToast();

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast({
      title: "Link Copied!",
      description: "Article link copied to clipboard.",
    });
  };

  if (!post) {
    return (
      <div className="bg-navy-950 min-h-screen pt-32 pb-12 flex flex-col items-center justify-center text-center">
        <h1 className="text-white text-3xl font-bold">Post Not Found</h1>
        <Link to="/blog" className="text-gold-500 mt-4 underline">Back to Blog</Link>
      </div>
    );
  }

  const authorName = post.author || "Coach Steve Goldstein";
  const displayImage = post.featured_image_url || post.coverImage || post.image;

  return (
    <>
      <Helmet>
        <title>{post.title} | Coach Steve Blog</title>
      </Helmet>

      <div className="bg-navy-950 min-h-screen font-sans text-slate-100 pt-24 pb-12">
        <article>
          {/* Header */}
          <div className="container mx-auto px-4 sm:px-6 mb-12">
            <Link 
              to="/blog" 
              className="inline-flex items-center text-gray-400 hover:text-gold-500 transition-colors mb-8 group font-bold text-sm uppercase tracking-wide"
            >
              <ChevronLeft className="w-5 h-5 mr-1 group-hover:-translate-x-1 transition-transform" />
              Back to Blog
            </Link>

            {displayImage && (
               <motion.div
                 initial={{ opacity: 0, y: 20 }}
                 animate={{ opacity: 1, y: 0 }}
                 transition={{ duration: 0.8 }}
                 className="mb-10 w-full group relative rounded-2xl overflow-hidden shadow-2xl border border-gray-800"
               >
                 <img 
                   src={displayImage} 
                   alt={post.title}
                   loading="lazy"
                   className="w-full max-h-[600px] object-cover"
                 />
                 <div className="absolute inset-0 bg-gradient-to-t from-navy-950 to-transparent opacity-40"></div>
               </motion.div>
            )}

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-4xl mx-auto text-center"
            >
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-sm bg-blue-accent/10 text-blue-accent text-xs font-black border border-blue-accent/20 mb-6 uppercase tracking-widest">
                {post.category}
              </div>
              
              <h1 className="text-3xl md:text-5xl lg:text-6xl font-black text-white mb-6 leading-tight tracking-tight font-montserrat">
                {post.title}
              </h1>

              <div className="flex items-center justify-center gap-6 text-gray-400 text-sm font-bold uppercase tracking-wide mt-6">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-gold-500" />
                  <span>{post.date}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-gold-500" />
                  <span>{post.readTime}</span>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Content Body */}
          <div className="container mx-auto px-4 sm:px-6">
            <div className="max-w-3xl mx-auto">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3, duration: 0.6 }}
                className="prose prose-lg prose-invert max-w-none text-gray-300 leading-relaxed mb-16 font-light
                  prose-headings:font-montserrat prose-headings:font-black prose-headings:text-white prose-headings:uppercase
                  prose-a:text-blue-accent prose-a:no-underline hover:prose-a:underline
                  prose-strong:text-white prose-strong:font-bold
                  prose-li:marker:text-gold-500
                  prose-img:rounded-xl prose-img:shadow-xl prose-img:border prose-img:border-gray-800"
                dangerouslySetInnerHTML={{ __html: post.content }}
              />

              <div className="border-t border-gray-800 pt-8 pb-12 flex items-center justify-between">
                <span className="text-gray-400 font-bold text-sm uppercase tracking-wide">Share this article:</span>
                <button 
                  onClick={handleShare}
                  className="flex items-center gap-2 px-6 py-3 bg-navy-900 hover:bg-navy-800 text-white rounded-lg transition-colors border border-gray-800 group"
                >
                  <Share2 className="w-4 h-4 text-gold-500 group-hover:scale-110 transition-transform" />
                  <span className="text-sm font-bold uppercase tracking-wide">Copy Link</span>
                </button>
              </div>
            </div>
          </div>
        </article>
        <Footer />
      </div>
    </>
  );
};

export default BlogPost;