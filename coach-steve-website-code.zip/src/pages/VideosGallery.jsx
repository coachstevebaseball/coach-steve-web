import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Play, RefreshCcw, AlertCircle, Video as VideoIcon } from 'lucide-react';
import { categories } from '@/data/trainingVideos';
import { supabase } from '@/lib/customSupabaseClient';
import { cn } from '@/lib/utils';

const VideosGallery = () => {
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [videos, setVideos] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchVideos = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase
        .from('training_videos')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        throw new Error(error.message || 'Failed to fetch videos from the database.');
      }
      
      setVideos(data || []);
    } catch (err) {
      console.error('Error fetching videos:', err);
      setError(err.message || 'Unable to load videos at this time. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchVideos();
  }, []);

  const filteredVideos = Array.isArray(videos) ? (
    selectedCategory === 'ALL' 
      ? videos 
      : videos.filter(video => video.category === selectedCategory)
  ) : [];

  return (
    <>
      <Helmet>
        <title>Training Videos | Coach Steve Baseball</title>
        <link rel="canonical" href="https://www.coachstevebaseball.com/videos" />
        <meta property="og:title" content="Training Videos | Coach Steve Baseball" />
        <meta property="og:url" content="https://www.coachstevebaseball.com/videos" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Training Videos | Coach Steve Baseball" />
        <meta property="og:image:alt" content="Baseball Training Videos" />
      </Helmet>

      <div className="min-h-screen bg-navy-950 pt-24 pb-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-black text-white mb-4">
              Training Videos
            </h1>
            <p className="text-lg text-gray-300 max-w-3xl mx-auto">
              Master elite baseball skills with our comprehensive video library. Learn from proven techniques and drills used by top athletes.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="mb-12"
          >
            <div className="flex flex-wrap gap-3 justify-center">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={cn(
                    'category-filter-btn px-6 py-2 rounded-full text-sm font-bold tracking-wider uppercase transition-all duration-300 border',
                    selectedCategory === category 
                      ? 'bg-red-500 text-white border-red-500 shadow-lg shadow-red-500/20' 
                      : 'bg-navy-900 text-gray-400 border-gray-800 hover:bg-navy-800 hover:text-white'
                  )}
                >
                  {category}
                </button>
              ))}
            </div>
          </motion.div>

          {isLoading ? (
            <div className="py-24 flex flex-col items-center justify-center">
              <div className="w-12 h-12 border-4 border-red-500 border-t-transparent rounded-full animate-spin mb-4"></div>
              <p className="text-gray-400 font-bold tracking-wider uppercase text-sm">Loading Library...</p>
            </div>
          ) : error ? (
            <div className="py-24 text-center max-w-lg mx-auto bg-navy-900/50 rounded-2xl border border-red-500/20 p-8">
              <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
              <p className="text-red-400 mb-6 text-lg">{error}</p>
              <button 
                onClick={fetchVideos} 
                className="inline-flex items-center gap-2 px-6 py-3 bg-red-500 text-white rounded-lg font-bold hover:bg-red-600 transition-colors"
              >
                <RefreshCcw className="w-4 h-4" /> 
                Retry Loading
              </button>
            </div>
          ) : (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              >
                {filteredVideos.map((video, index) => (
                  <Link
                    key={video.id}
                    to={`/videos/${video.id}`}
                    className="group flex flex-col h-full bg-navy-900 rounded-xl overflow-hidden border border-gray-800 hover:border-red-500/50 transition-all duration-300"
                  >
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4, delay: Math.min(index * 0.05, 0.5) }}
                      className="flex-1 flex flex-col"
                    >
                      <div className="relative overflow-hidden aspect-video bg-black">
                        <img
                          src={video.thumbnail || 'https://placehold.co/640x360/1c2128/d4af37?text=Video'}
                          alt={video.title || "Video Thumbnail"}
                          className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity duration-300 group-hover:scale-105"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-navy-950/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center transform scale-0 group-hover:scale-100 transition-transform duration-300 shadow-xl">
                              <Play className="w-8 h-8 text-white ml-1" fill="currentColor" />
                            </div>
                          </div>
                        </div>
                        <div className="absolute top-3 right-3">
                          <span className="px-3 py-1 bg-red-500/90 backdrop-blur-sm text-white text-xs font-bold rounded-full shadow-lg">
                            {(video.type || 'video').toUpperCase()}
                          </span>
                        </div>
                      </div>
                      <div className="p-5 flex flex-col flex-1">
                        <h3 className="text-white font-bold text-lg mb-2 line-clamp-2 group-hover:text-red-500 transition-colors">
                          {video.title || 'Untitled Video'}
                        </h3>
                        <p className="text-gray-400 text-sm line-clamp-2 mb-4 flex-1">
                          {video.description || 'No description available.'}
                        </p>
                        <div className="flex items-center justify-between mt-auto pt-2 border-t border-gray-800/50">
                          <span className="text-red-500 text-xs font-black uppercase tracking-widest">
                            {video.category || 'Uncategorized'}
                          </span>
                        </div>
                      </div>
                    </motion.div>
                  </Link>
                ))}
              </motion.div>

              {filteredVideos.length === 0 && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center py-20 bg-navy-900/30 rounded-2xl border border-gray-800/50 mt-8"
                >
                  <VideoIcon className="w-16 h-16 text-gray-700 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-white mb-2">No videos found</h3>
                  <p className="text-gray-400 text-lg max-w-md mx-auto">
                    {videos.length === 0 
                      ? "Our video library is currently empty. Check back soon for new content!" 
                      : `We couldn't find any videos in the "${selectedCategory}" category.`}
                  </p>
                  {selectedCategory !== 'ALL' && (
                    <button 
                      onClick={() => setSelectedCategory('ALL')}
                      className="mt-6 px-6 py-2 bg-navy-800 hover:bg-navy-700 text-white rounded-lg transition-colors text-sm font-bold"
                    >
                      View All Categories
                    </button>
                  )}
                </motion.div>
              )}
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default VideosGallery;