import React from 'react';
import { motion } from 'framer-motion';

const CredibilityBadges = () => {
  const badges = [
    {
      type: 'video',
      src: "https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/CHAMPIONSHIP%20TEAM.mp4",
      title: 'CHAMPIONSHIP COACH',
      subtitle: 'DEVELOPING WINNERS'
    },
    {
      type: 'video',
      src: "https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/_users_f01d1fdd-ee86-4372-bb2f-a2b2db4f4d3f_generated_a974b699-b2de-40c6-8a64-e77a52520d99_generated_video_hd.mp4",
      title: "COLLEGE WORLD SERIES '12",
      subtitle: 'Game-Winning HR vs LSU'
    },
    {
      type: 'video',
      src: "https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/_users_f01d1fdd-ee86-4372-bb2f-a2b2db4f4d3f_generated_1ec91edd-c51f-4a68-8054-ddb628138e87_generated_video_hd.mp4",
      title: '5-TOOL OUTFIELDER',
      subtitle: 'Long Island\'s #1 Prospect'
    },
    {
      type: 'image',
      image: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/BIG%2012%20KANSAS%20AT%20BAT%20VS%20TEXAS.png',
      title: 'University of Kansas (BIG 12)',
    },
    {
      type: 'video',
      src: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/_users_f01d1fdd-ee86-4372-bb2f-a2b2db4f4d3f_generated_fa89a2cb-4cd3-47e9-9220-6f801f99bb43_generated_video.mov', 
      title: '100+ ATHLETES TRAINED',
      subtitle: 'Proven Track Record'
    }
  ];

  return (
    <section className="py-12 md:py-16 bg-navy-950 border-b border-red-500/10 relative overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[200px] bg-red-500/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 md:gap-6 max-w-7xl mx-auto">
          {badges.map((badge, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -5, scale: 1.02 }}
              className="relative h-56 md:h-64 rounded-xl overflow-hidden border border-red-500/20 shadow-xl group cursor-pointer bg-navy-900"
            >
              {badge.type === 'video' ? (
                <video
                  src={badge.src}
                  autoPlay
                  loop
                  muted
                  playsInline
                  className="absolute inset-0 w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700 ease-out"
                />
              ) : (
                <img 
                  src={badge.image} 
                  alt={badge.title || badge.subtitle} 
                  className="absolute inset-0 w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700 ease-out" 
                  loading="lazy"
                />
              )}

              <div className="absolute inset-0 bg-gradient-to-t from-navy-900 via-navy-900/60 to-transparent opacity-90 transition-opacity duration-300 group-hover:opacity-80"></div>
              <div className="absolute inset-0 bg-gradient-to-t from-red-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <div className="absolute inset-0 border-2 border-transparent group-hover:border-red-500/30 transition-colors duration-300 rounded-xl pointer-events-none"></div>

              <div className="absolute bottom-0 left-0 right-0 p-4 text-center z-10 flex flex-col justify-end h-full pb-6">
                <div className="transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                  {badge.title && (
                    <h3 className="text-white font-montserrat font-black text-sm md:text-base leading-tight uppercase tracking-tight mb-2 drop-shadow-md">
                      {badge.title}
                    </h3>
                  )}
                  <div className="w-8 h-0.5 bg-red-500 mx-auto mb-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 hidden sm:block"></div>
                  {badge.subtitle && (
                    <p className="text-red-500 font-medium text-[10px] sm:text-xs tracking-widest uppercase opacity-90">
                      {badge.subtitle}
                    </p>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CredibilityBadges;