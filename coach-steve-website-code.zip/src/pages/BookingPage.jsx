import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { CheckCircle2, Calendar, User, Mail, Phone, Target, MapPin, Loader2, Send } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';

const BookingPage = () => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState('form'); // 'form' or 'calendly'

  const [formData, setFormData] = useState({
    parent_name: '',
    email: '',
    phone: '',
    player_name: '',
    player_age: '',
    date: '',
    location_preference: 'Batting Cages',
    primary_focus: 'Hitting Mechanics',
    experience_level: 'Intermediate',
    goals: '',
    notes: ''
  });

  // Calendly effect
  useEffect(() => {
    if (activeTab === 'calendly') {
      const script = document.createElement('script');
      script.src = 'https://assets.calendly.com/assets/external/widget.js';
      script.async = true;
      
      script.onload = () => {
        if (window.Calendly) {
          window.Calendly.initInlineWidget({
            url: 'https://calendly.com/coachstevebaseball/30min',
            parentElement: document.getElementById('calendly-embed'),
            prefill: {},
            utm: {}
          });
        }
      };

      document.body.appendChild(script);

      return () => {
        if (document.body.contains(script)) {
          document.body.removeChild(script);
        }
      };
    }
  }, [activeTab]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // 1. Save to database (optional but recommended for records)
      const { error: dbError } = await supabase
        .from('bookings')
        .insert([{
          parent_name: formData.parent_name,
          email: formData.email,
          phone: formData.phone,
          player_name: formData.player_name,
          player_age: parseInt(formData.player_age) || null,
          date: formData.date ? new Date(formData.date).toISOString() : null,
          location_preference: formData.location_preference,
          primary_focus: formData.primary_focus,
          experience_level: formData.experience_level,
          goals: formData.goals,
          notes: formData.notes
        }]);

      if (dbError) {
        console.error('Database save error:', dbError);
        // Continue to send email even if DB fails, or handle appropriately
      }

      // 2. Trigger Edge Function to send email
      const { error: functionError } = await supabase.functions.invoke('send-booking-email', {
        body: formData
      });

      if (functionError) throw functionError;

      toast({
        title: "Booking Request Sent!",
        description: "Coach Steve will get back to you shortly to confirm your session.",
        variant: "default",
      });

      // Reset form
      setFormData({
        parent_name: '',
        email: '',
        phone: '',
        player_name: '',
        player_age: '',
        date: '',
        location_preference: 'Batting Cages',
        primary_focus: 'Hitting Mechanics',
        experience_level: 'Intermediate',
        goals: '',
        notes: ''
      });

    } catch (error) {
      console.error('Booking submission error:', error);
      toast({
        title: "Submission Failed",
        description: "There was an error sending your request. Please try again or contact us directly.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const benefits = [
    "Personalized Swing Analysis & Correction",
    "Advanced Drill Progression & Repetition",
    "Mental Approach & Plate Discipline",
    "In-Game Strategy & Situational Hitting",
    "Recruiting & Next-Level Guidance"
  ];

  return (
    <div className="min-h-screen bg-navy-950 pt-24 pb-16 px-4">
      <Helmet>
        <title>Book a Lesson | Coach Steve Baseball</title>
        <meta name="description" content="Schedule your private baseball hitting lesson with Coach Steve on Long Island. Easy online booking for individual sessions and training packages." />
        <link rel="canonical" href="https://www.coachstevebaseball.com/booking" />
        <meta property="og:title" content="Book a Lesson | Coach Steve Baseball" />
        <meta property="og:url" content="https://www.coachstevebaseball.com/booking" />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="https://images.unsplash.com/photo-1490326149782-dd42fa59bd9f" />
        <meta property="og:image:alt" content="Baseball Training Session Booking" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Book a Lesson | Coach Steve Baseball" />
      </Helmet>
      
      <div className="container mx-auto max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-black text-white uppercase mb-4 tracking-tight">
            Book a Session
          </h1>
          <p className="text-gray-400 text-lg md:text-xl max-w-2xl mx-auto font-light">
            Take the next step in your baseball journey. Schedule your elite training session today.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          {/* LEFT COLUMN: Description and Benefits */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="lg:col-span-5 flex flex-col justify-center space-y-8"
          >
            <div>
              <h2 className="text-3xl font-black text-white mb-4 uppercase tracking-tight">
                Elevate Your <span className="text-red-500">Game</span>
              </h2>
              <p className="text-gray-300 leading-relaxed text-lg font-light">
                Working 1-on-1 ensures every swing, every rep, and every mechanical adjustment is tailored specifically to your body and your goals. We don't just build better swings; we build smarter, more dangerous hitters.
              </p>
            </div>

            <div className="bg-navy-900/50 p-6 rounded-2xl border border-gray-800/50">
              <h3 className="text-xl font-bold text-white mb-4 uppercase tracking-wide">What to Expect</h3>
              <ul className="space-y-4">
                {benefits.map((benefit, index) => (
                  <motion.li 
                    key={index}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: 0.4 + (index * 0.1) }}
                    className="flex items-start gap-3"
                  >
                    <CheckCircle2 className="w-6 h-6 text-yellow-500 shrink-0 mt-0.5" />
                    <span className="text-gray-200">{benefit}</span>
                  </motion.li>
                ))}
              </ul>
            </div>
          </motion.div>

          {/* RIGHT COLUMN: Booking Form or Calendly */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="lg:col-span-7"
            id="booking-calendar"
          >
            <div className="bg-navy-900 border border-gray-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
              
              {/* Tab Selector */}
              <div className="flex border-b border-gray-800 bg-navy-950">
                <button
                  onClick={() => setActiveTab('form')}
                  className={`flex-1 py-4 text-sm font-bold uppercase tracking-wider transition-colors ${
                    activeTab === 'form' 
                      ? 'bg-navy-900 text-red-500 border-t-2 border-red-500' 
                      : 'text-gray-500 hover:text-gray-300 hover:bg-navy-900/50 border-t-2 border-transparent'
                  }`}
                >
                  Request a Session
                </button>
                <button
                  onClick={() => setActiveTab('calendly')}
                  className={`flex-1 py-4 text-sm font-bold uppercase tracking-wider transition-colors ${
                    activeTab === 'calendly' 
                      ? 'bg-navy-900 text-red-500 border-t-2 border-red-500' 
                      : 'text-gray-500 hover:text-gray-300 hover:bg-navy-900/50 border-t-2 border-transparent'
                  }`}
                >
                  Book via Calendly
                </button>
              </div>

              {activeTab === 'form' ? (
                <div className="p-6 md:p-8">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    
                    {/* Parent/Contact Info */}
                    <div className="space-y-4">
                      <h4 className="text-white font-bold border-b border-gray-800 pb-2 flex items-center gap-2">
                        <User className="w-5 h-5 text-red-500" />
                        Contact Information
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Parent/Contact Name *</label>
                          <input 
                            type="text" 
                            name="parent_name"
                            required
                            value={formData.parent_name}
                            onChange={handleInputChange}
                            className="w-full bg-navy-950 border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-red-500 transition-colors"
                            placeholder="John Doe"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Email Address *</label>
                          <input 
                            type="email" 
                            name="email"
                            required
                            value={formData.email}
                            onChange={handleInputChange}
                            className="w-full bg-navy-950 border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-red-500 transition-colors"
                            placeholder="john@example.com"
                          />
                        </div>
                        <div className="space-y-2 md:col-span-2">
                          <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Phone Number *</label>
                          <input 
                            type="tel" 
                            name="phone"
                            required
                            value={formData.phone}
                            onChange={handleInputChange}
                            className="w-full bg-navy-950 border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-red-500 transition-colors"
                            placeholder="(555) 123-4567"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Player Info */}
                    <div className="space-y-4">
                      <h4 className="text-white font-bold border-b border-gray-800 pb-2 flex items-center gap-2 mt-6">
                        <Target className="w-5 h-5 text-red-500" />
                        Player Details
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Player Name *</label>
                          <input 
                            type="text" 
                            name="player_name"
                            required
                            value={formData.player_name}
                            onChange={handleInputChange}
                            className="w-full bg-navy-950 border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-red-500 transition-colors"
                            placeholder="Jimmy Doe"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Player Age *</label>
                          <input 
                            type="number" 
                            name="player_age"
                            required
                            min="5" max="30"
                            value={formData.player_age}
                            onChange={handleInputChange}
                            className="w-full bg-navy-950 border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-red-500 transition-colors"
                            placeholder="14"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Experience Level</label>
                          <select 
                            name="experience_level"
                            value={formData.experience_level}
                            onChange={handleInputChange}
                            className="w-full bg-navy-950 border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-red-500 transition-colors appearance-none"
                          >
                            <option value="Beginner">Beginner (Little League)</option>
                            <option value="Intermediate">Intermediate (Travel/JV)</option>
                            <option value="Advanced">Advanced (Varsity)</option>
                            <option value="Elite">Elite (College/Pro)</option>
                          </select>
                        </div>
                        <div className="space-y-2">
                          <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Primary Focus</label>
                          <select 
                            name="primary_focus"
                            value={formData.primary_focus}
                            onChange={handleInputChange}
                            className="w-full bg-navy-950 border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-red-500 transition-colors appearance-none"
                          >
                            <option value="Hitting Mechanics">Hitting Mechanics</option>
                            <option value="Power/Exit Velocity">Power & Exit Velocity</option>
                            <option value="Plate Discipline">Plate Discipline</option>
                            <option value="Fielding">Fielding/Defense</option>
                            <option value="Overall Development">Overall Development</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    {/* Session Logistics */}
                    <div className="space-y-4">
                      <h4 className="text-white font-bold border-b border-gray-800 pb-2 flex items-center gap-2 mt-6">
                        <Calendar className="w-5 h-5 text-red-500" />
                        Session Logistics
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Preferred Date (Optional)</label>
                          <input 
                            type="date" 
                            name="date"
                            value={formData.date}
                            onChange={handleInputChange}
                            className="w-full bg-navy-950 border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-red-500 transition-colors [color-scheme:dark]"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Location Preference</label>
                          <select 
                            name="location_preference"
                            value={formData.location_preference}
                            onChange={handleInputChange}
                            className="w-full bg-navy-950 border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-red-500 transition-colors appearance-none"
                          >
                            <option value="Batting Cages">Local Batting Cages</option>
                            <option value="Local Field">Local Field</option>
                            <option value="Virtual/Online">Virtual Analysis</option>
                            <option value="Other">Other (Specify in notes)</option>
                          </select>
                        </div>
                        <div className="space-y-2 md:col-span-2">
                          <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Specific Goals / Areas to Improve</label>
                          <textarea 
                            name="goals"
                            rows="2"
                            value={formData.goals}
                            onChange={handleInputChange}
                            className="w-full bg-navy-950 border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-red-500 transition-colors resize-none"
                            placeholder="E.g., struggling with outside pitches, wants more power..."
                          ></textarea>
                        </div>
                        <div className="space-y-2 md:col-span-2">
                          <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Additional Notes</label>
                          <textarea 
                            name="notes"
                            rows="2"
                            value={formData.notes}
                            onChange={handleInputChange}
                            className="w-full bg-navy-950 border border-gray-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-red-500 transition-colors resize-none"
                            placeholder="Any injuries, past coaching, or schedule constraints..."
                          ></textarea>
                        </div>
                      </div>
                    </div>

                    <button 
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-4 bg-gradient-to-r from-red-600 to-yellow-500 hover:from-red-500 hover:to-yellow-400 text-white font-black text-lg uppercase tracking-widest rounded-xl shadow-lg shadow-red-500/25 hover:shadow-red-500/40 transform hover:-translate-y-1 transition-all duration-300 flex items-center justify-center disabled:opacity-70 disabled:cursor-not-allowed disabled:transform-none mt-8"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                          Submitting Request...
                        </>
                      ) : (
                        <>
                          <Send className="w-5 h-5 mr-2" />
                          Send Booking Request
                        </>
                      )}
                    </button>
                  </form>
                </div>
              ) : (
                <div className="relative w-full bg-white h-[650px] sm:h-[700px]">
                  {/* Loading placeholder */}
                  <div className="absolute inset-0 flex items-center justify-center bg-gray-50 z-0">
                    <div className="flex flex-col items-center">
                      <div className="w-10 h-10 border-4 border-red-500 border-t-transparent rounded-full animate-spin mb-4"></div>
                      <p className="text-gray-500 font-medium">Loading Booking Calendar...</p>
                    </div>
                  </div>

                  <div 
                    id="calendly-embed" 
                    className="w-full h-full relative z-10"
                  ></div>
                </div>
              )}

            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default BookingPage;