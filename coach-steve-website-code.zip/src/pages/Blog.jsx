import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Clock, Calendar, ChevronRight, Search, User } from 'lucide-react';
import { blogPosts } from '@/data/blogPosts';
import Footer from '@/components/Footer';
import MagneticButton from '@/components/MagneticButton';
import TextRevealAnimation from '@/components/TextRevealAnimation';

const Blog = () => {
  const sortedPosts = [...blogPosts].sort((a, b) => {
    return new Date(b.date) - new Date(a.date);
  });

  return (
    <>
      <Helmet>
        <title>Baseball Hitting Tips & Training Blog | Coach Steve</title>
        <meta name="description" content="Read expert baseball training tips, hitting techniques, and coaching insights from Coach Steve to improve your game." />
        <link rel="canonical" href="https://www.coachstevebaseball.com/blog" />
        <meta property="og:title" content="Baseball Hitting Tips & Training Blog | Coach Steve" />
        <meta property="og:description" content="Read expert baseball training tips, hitting techniques, and coaching insights from Coach Steve to improve your game." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.coachstevebaseball.com/blog" />
        <meta property="og:image" content="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/stonybrook-swing.png" />
        <meta property="og:image:alt" content="Baseball Training Blog" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Baseball Hitting Tips & Training Blog | Coach Steve" />
      </Helmet>

      <div className="bg-navy-950 min-h-screen font-sans text-slate-100 pt-20 md:pt-24 pb-12">
        {/* Header Section */}
        <div className="container mx-auto px-4 md:px-6 lg:px-8 mb-10 md:mb-16">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-7xl font-black text-white mb-4 md:mb-6 tracking-tight font-montserrat">
              <TextRevealAnimation>
                BASEBALL <span className="text-red-500">INSIGHTS</span>
              </TextRevealAnimation>
            </h1>
            <p className="text-base md:text-lg lg:text-xl text-gray-300 leading-relaxed mb-6 md:mb-8 font-light px-2">
              Deep dives into hitting mechanics, mental approach, and player development strategies.
            </p>
            
            <div className="relative max-w-md mx-auto">
              <input 
                type="text" 
                placeholder="Search articles..." 
                className="w-full bg-navy-900 border border-gray-800 rounded-full py-3 px-6 pl-12 md:py-4 text-white text-sm md:text-base placeholder-gray-500 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition-all shadow-lg min-h-[44px]"
              />
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500 w-5 h-5" />
            </div>
          </motion.div>
        </div>

        {/* Blog Grid */}
        <div className="container mx-auto px-4 md:px-6 lg:px-8 mb-12 md:mb-20">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {sortedPosts.map((post, index) => (
              <motion.article
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                className="bg-navy-900 rounded-2xl overflow-hidden border border-gray-800 hover:border-red-500/50 transition-all duration-300 group hover:shadow-2xl hover:shadow-red-500/10 flex flex-col h-full"
              >
                {/* Image Container */}
                <div className="relative h-48 md:h-56 overflow-hidden">
                  <div className="absolute top-4 left-4 z-10 bg-navy-950/90 backdrop-blur-sm text-red-500 text-xs font-bold px-3 py-1 rounded-sm border border-red-500/20 uppercase tracking-wider">
                    {post.category}
                  </div>
                  <img 
                    src={post.featured_image_url || post.coverImage || post.image} 
                    alt={post.title} 
                    className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-900 via-transparent to-transparent opacity-90"></div>
                </div>

                {/* Content */}
                <div className="p-5 md:p-6 lg:p-8 flex flex-col flex-grow">
                  <div className="flex items-center gap-4 flex-wrap text-[10px] md:text-xs text-gray-400 mb-3 md:mb-4 font-bold uppercase tracking-wide">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-red-500" />
                      <span>{post.date}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-red-500" />
                      <span>{post.readTime || post.readingTime}</span>
                    </div>
                    {post.author && (
                      <div className="flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-red-500" />
                        <span>{post.author}</span>
                      </div>
                    )}
                  </div>

                  <Link to={`/blog/${post.slug}`} className="block mb-3">
                    <h2 className="text-lg md:text-xl font-bold text-white leading-tight group-hover:text-red-500 transition-colors line-clamp-2 font-montserrat">
                      {post.title}
                    </h2>
                  </Link>
                  
                  <p className="text-gray-400 text-sm leading-relaxed mb-6 line-clamp-3 flex-grow font-light">
                    {post.excerpt}
                  </p>

                  <Link 
                    to={`/blog/${post.slug}`}
                    className="flex items-center gap-2 text-red-500 font-bold text-sm hover:gap-3 transition-all duration-300 mt-auto uppercase tracking-wide min-h-[44px]"
                  >
                    Read Article 
                    <ChevronRight className="w-4 h-4" />
                  </Link>
                </div>
              </motion.article>
            ))}
          </div>
        </div>

        {/* Newsletter / CTA Section */}
        <section className="container mx-auto px-4 md:px-6 lg:px-8">
          <div className="bg-navy-900 rounded-3xl p-6 md:p-12 lg:p-16 border border-gray-800 text-center relative overflow-hidden shadow-2xl">
             <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-red-500/10 rounded-full blur-3xl"></div>
             <div className="absolute bottom-0 left-0 -ml-16 -mb-16 w-64 h-64 bg-red-500/10 rounded-full blur-3xl"></div>

            <div className="relative z-10 max-w-2xl mx-auto">
              <h2 className="text-2xl md:text-3xl font-black text-white mb-4 font-montserrat">Never Miss a Tip</h2>
              <p className="text-gray-300 mb-6 md:mb-8 font-light text-sm md:text-base">
                Join our newsletter to get the latest hitting drills, mental game strategies, and exclusive training content delivered straight to your inbox.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-3">
                <input 
                  type="email" 
                  placeholder="Enter your email address" 
                  className="flex-grow bg-navy-950 border border-gray-800 rounded-lg py-3 px-4 md:py-4 md:px-6 text-white text-sm md:text-base placeholder-gray-500 focus:outline-none focus:border-red-500 transition-all min-h-[44px] md:min-h-[50px]"
                />
                <MagneticButton className="h-auto p-0 border-none bg-transparent hover:bg-transparent w-full sm:w-auto">
                  <span className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-500 text-white font-black py-3 md:py-4 px-8 rounded-lg transition-colors shadow-lg hover:shadow-red-500/20 whitespace-nowrap block uppercase tracking-wider min-h-[44px] md:min-h-[50px] flex items-center justify-center text-sm md:text-base">
                    Subscribe Now
                  </span>
                </MagneticButton>
              </div>
            </div>
          </div>
        </section>

        <div className="mt-12 md:mt-20">
          <Footer />
        </div>
      </div>
    </>
  );
};

export default Blog;