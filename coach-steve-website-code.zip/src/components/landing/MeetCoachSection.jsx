import React from 'react';
import { motion } from 'framer-motion';
import { Check, Award, Trophy } from 'lucide-react';

const MeetCoachSection = () => {
  const credentials = [
    "Louisville Slugger Division One All-American", 
    "College World Series Outfielder", 
    "Former Long Island #1 Prospect", 
    "Game-Winning Home Run vs LSU on ESPN", 
    "10+ years coaching experience", 
    "100+ athletes trained & developed"
  ];

  return (
    <section className="py-12 md:py-24 bg-[#0a0e12] relative overflow-hidden">
      {/* Background Decorative Elements */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#e4002b]/5 rounded-full blur-[100px] pointer-events-none" />
      
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center gap-10 lg:gap-24">
          
          {/* Image Side - Premium Card Style */}
          <motion.div 
            initial={{ opacity: 0, x: -50 }} 
            whileInView={{ opacity: 1, x: 0 }} 
            viewport={{ once: true, margin: "-100px" }} 
            transition={{ duration: 0.8 }} 
            className="w-full lg:w-1/2 relative group"
          >
            {/* Animated Border Gradient - Updated to Red */}
            <div className="absolute -inset-1 bg-gradient-to-tr from-[#e4002b] to-transparent rounded-lg opacity-30 group-hover:opacity-60 transition-opacity duration-500 blur-sm"></div>
            
            <div className="relative rounded-lg overflow-hidden shadow-2xl bg-[#0f1419] max-h-[500px] lg:max-h-none">
              {/* Badge Background Updated to Red */}
              <div className="absolute top-4 left-4 z-20 bg-[#e4002b] text-white font-bold px-4 py-1 text-xs uppercase tracking-widest rounded-sm shadow-lg">
                COACH STEVE
              </div>
              <img 
                src="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/cs-hr-celebration.png" 
                alt="Coach Steve Goldstein" 
                className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 transform group-hover:scale-105" 
              />
              
              {/* Overlay Content */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black via-black/80 to-transparent p-6 md:p-8 pt-20">
                <h3 className="text-white font-montserrat font-bold text-xl md:text-2xl mb-1">Steve Goldstein</h3>
                {/* Text Color Updated to Red */}
                <p className="text-[#e4002b] font-medium tracking-wide text-sm md:text-base">D1 ALL-AMERICAN</p>
              </div>
            </div>

            {/* Floating Badge - Updated to Red */}
            <motion.div 
              initial={{ y: 20, opacity: 0 }} 
              whileInView={{ y: 0, opacity: 1 }} 
              transition={{ delay: 0.5 }} 
              className="absolute -bottom-6 -right-6 bg-[#0f1419] border border-[#e4002b]/30 p-4 rounded-lg shadow-xl hidden md:flex items-center gap-3 z-30"
            >
              <div className="bg-[#e4002b]/10 p-2 rounded-full">
                <Trophy className="text-[#e4002b] w-6 h-6" />
              </div>
              <div>
                <p className="text-white font-bold text-sm">D1 All-American</p>
                <p className="text-gray-400 text-xs">Top Tier Experience</p>
              </div>
            </motion.div>
          </motion.div>
          
          {/* Content Side */}
          <motion.div 
            initial={{ opacity: 0, x: 50 }} 
            whileInView={{ opacity: 1, x: 0 }} 
            viewport={{ once: true, margin: "-100px" }} 
            transition={{ duration: 0.8 }} 
            className="w-full lg:w-1/2"
          >
            {/* Badge Accents Updated to Red */}
            <div className="inline-flex items-center gap-2 mb-4 md:mb-6 bg-[#e4002b]/10 px-4 py-1.5 rounded-full border border-[#e4002b]/20">
              <Award size={14} className="text-[#e4002b]" />
              <span className="text-[#e4002b] text-xs font-bold tracking-[0.2em] uppercase">
                Elite Player Development
              </span>
            </div>

            {/* Heading Gradient Updated to Red */}
            <h2 className="font-montserrat font-black text-2xl sm:text-4xl lg:text-5xl text-white mb-6 md:mb-8 leading-tight md:leading-[1.1]">
              Learn From a Coach Who’s <br className="hidden lg:block" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#e4002b] to-[#fff]">
                Played the Game for Real
              </span>
            </h2>

            {/* Left Border Accent Updated to Red */}
            <p className="text-gray-300 text-base md:text-lg mb-8 md:mb-10 leading-relaxed font-light border-l-2 border-[#e4002b]/30 pl-4 md:pl-6">
              This isn’t random reps or copying someone else’s swing.
              Every session is built around <span className="text-white font-medium">how you move, how you think, and how the game actually plays out.</span>
              We train mechanics, mindset, and game awareness so your work shows up when it matters — in real at-bats, under real pressure.
            </p>

            <ul className="space-y-3 md:space-y-4">
              {credentials.map((cred, index) => (
                <motion.li 
                  key={index} 
                  initial={{ opacity: 0, x: 20 }} 
                  whileInView={{ opacity: 1, x: 0 }} 
                  viewport={{ once: true }} 
                  transition={{ delay: index * 0.1 }} 
                  className="flex items-start md:items-center gap-3 md:gap-4 group p-2 rounded-lg hover:bg-white/5 transition-colors"
                >
                  {/* Checkmark Circle Updated to Red */}
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-[#e4002b]/20 flex items-center justify-center border border-[#e4002b]/50 group-hover:bg-[#e4002b] transition-all mt-1 md:mt-0">
                    <Check className="text-[#e4002b] w-3.5 h-3.5 group-hover:text-white transition-colors" strokeWidth={3} />
                  </div>
                  {/* Hover Color Updated to Red */}
                  <span className="text-white font-medium text-sm md:text-lg group-hover:text-[#e4002b] transition-colors leading-tight">
                    {cred}
                  </span>
                </motion.li>
              ))}
            </ul>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default MeetCoachSection;