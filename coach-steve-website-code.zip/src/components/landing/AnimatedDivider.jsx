import React from 'react';
import { motion } from 'framer-motion';

const AnimatedDivider = () => {
  return (
    <div className="relative w-full h-24 flex items-center justify-center overflow-hidden py-10">
      {/* Left Line */}
      <motion.div 
        initial={{ width: 0, opacity: 0 }}
        whileInView={{ width: "40%", opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1, ease: "easeOut" }}
        className="h-[1px] bg-gradient-to-r from-transparent via-[#d4af37] to-[#d4af37]"
      />

      {/* Center Diamond Icon */}
      <motion.div 
        initial={{ scale: 0, rotate: -45, opacity: 0 }}
        whileInView={{ scale: 1, rotate: 0, opacity: 1 }}
        viewport={{ once: true }}
        transition={{ delay: 0.5, type: "spring", stiffness: 200 }}
        className="mx-4 relative"
      >
        <div className="w-4 h-4 bg-[#d4af37] transform rotate-45 shadow-[0_0_15px_rgba(212,175,55,0.6)]"></div>
        <div className="absolute inset-0 w-4 h-4 border border-[#d4af37] transform rotate-45 scale-150 opacity-50"></div>
      </motion.div>

      {/* Right Line */}
      <motion.div 
        initial={{ width: 0, opacity: 0 }}
        whileInView={{ width: "40%", opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1, ease: "easeOut" }}
        className="h-[1px] bg-gradient-to-l from-transparent via-[#d4af37] to-[#d4af37]"
      />
    </div>
  );
};

export default AnimatedDivider;