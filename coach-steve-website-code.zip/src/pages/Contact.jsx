import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { CalendarCheck, Send, CheckCircle2, Loader2, AlertCircle, ArrowRight } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import Footer from '@/components/Footer';
import MagneticButton from '@/components/MagneticButton';
import TextRevealAnimation from '@/components/TextRevealAnimation';

const Contact = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    player_name: '',
    player_age: '',
    primary_focus: 'Hitting',
    message: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase
        .from('contact_submissions')
        .insert([{ ...formData, subject: 'Session Inquiry', created_at: new Date().toISOString() }]);

      if (error) throw error;
      setSubmitted(true);
      toast({ title: "Request Received!", description: "We'll be in touch shortly." });
    } catch (error) {
      toast({ variant: "destructive", title: "Submission Failed", description: "Please try again." });
    } finally {
      setLoading(false);
    }
  };

  const inputClasses = "w-full bg-navy-900 border border-gray-800 rounded-lg px-4 py-3 md:py-4 text-white text-sm md:text-base placeholder-gray-500 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition-all shadow-inner min-h-[44px]";
  const labelClasses = "block text-xs md:text-sm font-black text-gray-400 mb-2 uppercase tracking-wider";

  return (
    <>
      <Helmet>
        <title>Contact Coach Steve | Book Baseball Lessons on Long Island</title>
        <meta name="description" content="Contact Coach Steve to book private baseball hitting lessons on Long Island, NY. Serving Westbury, Garden City, Mineola, and surrounding areas." />
        <link rel="canonical" href="https://www.coachstevebaseball.com/contact" />
        <meta property="og:title" content="Contact Coach Steve | Book Baseball Lessons Long Island" />
        <meta property="og:description" content="Ready to take your game to the next level? Contact Coach Steve to schedule your first session." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.coachstevebaseball.com/contact" />
        <meta property="og:image" content="https://images.unsplash.com/photo-1521220023479-f7417d9a3465" />
        <meta property="og:image:alt" content="Baseball Training Field" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Contact Coach Steve | Book Baseball Lessons Long Island" />
      </Helmet>

      <div className="pt-20 md:pt-24 min-h-screen flex flex-col bg-navy-950 font-sans text-white">
        <div className="flex-grow container mx-auto px-4 md:px-6 lg:px-8 py-12 md:py-16 lg:py-20">
            
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-10 md:mb-16"
            >
                <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-7xl font-black text-white mb-4 md:mb-6 tracking-tighter font-montserrat">
                    <TextRevealAnimation>
                      BOOK YOUR <span className="text-red-500">SESSION</span>
                    </TextRevealAnimation>
                </h1>
                <p className="text-base md:text-xl text-gray-300 max-w-2xl mx-auto font-light px-2">
                    Ready to take your game to the next level? Fill out the form below or use the direct scheduling link.
                </p>
            </motion.div>

            <div className="grid lg:grid-cols-2 gap-8 md:gap-12 max-w-6xl mx-auto">
                {/* Contact Form */}
                <motion.div 
                    initial={{ opacity: 0, x: -30 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 }}
                    className="bg-navy-900/50 border border-gray-800 rounded-2xl p-6 md:p-8 lg:p-10 backdrop-blur-sm shadow-2xl"
                >
                    <div className="flex items-center gap-3 mb-6 md:mb-8 border-b border-gray-800 pb-4 md:pb-6">
                        <div className="p-3 rounded-full bg-red-500/10 text-red-500">
                            <Send size={24} />
                        </div>
                        <h2 className="text-xl md:text-2xl font-black text-white uppercase tracking-tight">Session Inquiry</h2>
                    </div>

                    {submitted ? (
                        <div className="text-center py-16 md:py-20 bg-navy-900 rounded-xl border border-red-500/30">
                            <motion.div 
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                className="inline-block p-4 rounded-full bg-green-500/10 text-green-500 mb-4"
                            >
                                <CheckCircle2 size={48} />
                            </motion.div>
                            <h3 className="text-xl md:text-2xl font-bold text-white mb-2">Request Sent!</h3>
                            <p className="text-gray-400 text-sm md:text-base px-4">Coach Steve will review your info and contact you shortly.</p>
                            <button 
                                onClick={() => { setSubmitted(false); setFormData({name: '', email: '', phone: '', player_name: '', player_age: '', primary_focus: 'Hitting', message: ''})}}
                                className="mt-6 text-red-500 hover:text-white font-bold uppercase tracking-wide transition-colors min-h-[44px] flex items-center justify-center mx-auto"
                            >
                                Send another request
                            </button>
                        </div>
                    ) : (
                        <form onSubmit={handleSubmit} className="space-y-5 md:space-y-6">
                            <div className="grid md:grid-cols-2 gap-5 md:gap-6">
                                <div><label className={labelClasses}>Parent Name</label><input type="text" name="name" required value={formData.name} onChange={handleChange} className={inputClasses} placeholder="John Doe" /></div>
                                <div><label className={labelClasses}>Player Name</label><input type="text" name="player_name" required value={formData.player_name} onChange={handleChange} className={inputClasses} placeholder="Future Star" /></div>
                            </div>
                            <div className="grid md:grid-cols-2 gap-5 md:gap-6">
                                <div><label className={labelClasses}>Email</label><input type="email" name="email" required value={formData.email} onChange={handleChange} className={inputClasses} placeholder="john@example.com" /></div>
                                <div><label className={labelClasses}>Phone</label><input type="tel" name="phone" value={formData.phone} onChange={handleChange} className={inputClasses} placeholder="(555) 123-4567" /></div>
                            </div>
                            <div className="grid md:grid-cols-2 gap-5 md:gap-6">
                                <div><label className={labelClasses}>Player Age</label><input type="text" name="player_age" value={formData.player_age} onChange={handleChange} className={inputClasses} placeholder="e.g. 14" /></div>
                                <div>
                                    <label className={labelClasses}>Primary Focus</label>
                                    <select name="primary_focus" value={formData.primary_focus} onChange={handleChange} className={inputClasses}>
                                        <option value="Hitting">Hitting</option>
                                        <option value="Fielding">Fielding</option>
                                        <option value="Pitching">Pitching</option>
                                    </select>
                                </div>
                            </div>
                            <div>
                                <label className={labelClasses}>Message / Goals</label>
                                <textarea name="message" required rows="4" value={formData.message} onChange={handleChange} className={inputClasses} placeholder="Tell us about the player's current level and goals..."></textarea>
                            </div>
                            <MagneticButton 
                                type="submit" disabled={loading}
                                className="w-full bg-gradient-to-r from-red-500 to-red-600 text-white font-black uppercase tracking-wider py-4 md:py-5 h-auto rounded-lg hover:shadow-lg hover:scale-[1.02] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 border-none shadow-red-500/20 min-h-[48px] md:min-h-[50px] text-sm md:text-base"
                            >
                                {loading ? <Loader2 className="animate-spin" /> : <>SUBMIT REQUEST <ArrowRight size={20} /></>}
                            </MagneticButton>
                        </form>
                    )}
                </motion.div>

                {/* Direct Scheduling Option */}
                <motion.div 
                    initial={{ opacity: 0, x: 30 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.4 }}
                    className="flex flex-col gap-6 md:gap-8"
                >
                    <div className="bg-navy-900 rounded-2xl p-6 md:p-8 lg:p-10 border border-gray-800 relative overflow-hidden group hover:border-red-500/30 transition-colors shadow-xl">
                        <div className="absolute top-0 right-0 p-3 bg-red-500/10 rounded-bl-2xl">
                            <CalendarCheck className="text-red-500 w-8 h-8" />
                        </div>
                        <h3 className="text-xl md:text-2xl font-black text-white mb-3 md:mb-4 uppercase tracking-tight">Initial Assessment</h3>
                        <p className="text-gray-400 mb-6 md:mb-8 font-light leading-relaxed text-sm md:text-base">
                            Prefer to lock in a time right now? Book a 1-hour initial assessment directly through Calendly to evaluate hitting mechanics and develop a customized training plan.
                        </p>
                        <a
                            href="https://calendly.com/coachstevengoldstein/free-inital-1-hour-session"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="block w-full text-center bg-transparent border-2 border-blue-600 text-blue-600 font-black py-4 rounded-lg hover:bg-blue-600 hover:text-white transition-all uppercase tracking-wider min-h-[44px] flex items-center justify-center text-sm md:text-base"
                        >
                            Open Calendly
                        </a>
                    </div>
                </motion.div>
            </div>
        </div>
        <Footer />
      </div>
    </>
  );
};

export default Contact;