import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Calendar } from 'lucide-react';
import MagneticButton from '@/components/MagneticButton';
import TextRevealAnimation from '@/components/TextRevealAnimation';

const FinalCTA = () => {
  return (
    <section className="py-24 bg-navy-950 relative overflow-hidden">
      <div className="absolute inset-0 opacity-20">
        <div className="absolute -top-1/2 -left-1/2 w-full h-full bg-gradient-to-br from-red-500/20 to-transparent blur-[120px] rounded-full"></div>
        <div className="absolute -bottom-1/2 -right-1/2 w-full h-full bg-gradient-to-tl from-blue-600/20 to-transparent blur-[120px] rounded-full"></div>
      </div>
      
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-5xl mx-auto"
        >
          <div className="bg-gradient-to-br from-navy-900 to-navy-950 border border-red-500 rounded-3xl p-8 sm:p-16 shadow-2xl relative overflow-hidden group">
            
            <div className="absolute top-0 left-0 w-full h-1/2 bg-gradient-to-b from-white/5 to-transparent pointer-events-none"></div>

            <div className="relative z-10 text-center">
              <motion.div 
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="w-20 h-20 bg-gradient-to-br from-red-500 to-red-600 rounded-2xl flex items-center justify-center mx-auto mb-8 shadow-xl shadow-red-500/20 transform rotate-3 group-hover:rotate-0 transition-transform duration-500"
              >
                <Calendar className="text-white w-10 h-10" strokeWidth={2.5} />
              </motion.div>
              
              <h2 className="text-4xl sm:text-5xl md:text-7xl font-black text-white mb-6 tracking-tighter leading-none">
                <TextRevealAnimation>
                  READY TO <span className="text-red-500">DOMINATE</span>?
                </TextRevealAnimation>
              </h2>

              <p className="text-lg sm:text-xl text-gray-300 mb-10 leading-relaxed max-w-3xl mx-auto font-light">
                Stop leaving performance on the practice field. Let's build a customized training plan that translates directly to success when it matters most—between the lines.
              </p>

              <div className="flex flex-col sm:flex-row gap-6 justify-center items-center w-full mb-12">
                <MagneticButton asChild className="h-auto p-0 border-none bg-transparent hover:bg-transparent w-full sm:w-auto">
                  <a
                    href="/contact"
                    className="inline-flex items-center justify-center bg-gradient-to-r from-red-500 to-red-600 text-white px-10 py-5 rounded-xl font-black text-lg tracking-widest hover:scale-105 transition-transform duration-300 shadow-xl shadow-red-500/20 uppercase w-full sm:w-auto"
                  >
                    Book Your Session
                    <ArrowRight className="ml-2 stroke-[3px]" size={20} />
                  </a>
                </MagneticButton>
                
                <a
                  href="/training"
                  className="inline-flex items-center justify-center bg-transparent border-2 border-blue-600 text-blue-600 px-10 py-5 rounded-xl font-black text-lg tracking-widest hover:bg-blue-600/10 hover:text-white hover:border-white transition-all duration-300 uppercase w-full sm:w-auto"
                >
                  Explore Programs
                </a>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 pt-10 border-t border-red-500/20">
                <div className="flex flex-col items-center">
                  <span className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-b from-red-500 to-red-600 mb-1">100+</span>
                  <span className="text-xs text-gray-400 font-bold tracking-[0.2em] uppercase">Athletes Trained</span>
                </div>
                <div className="flex flex-col items-center">
                  <span className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-b from-red-500 to-red-600 mb-1">10+</span>
                  <span className="text-xs text-gray-400 font-bold tracking-[0.2em] uppercase">Years Experience</span>
                </div>
                <div className="flex flex-col items-center">
                  <span className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-b from-red-500 to-red-600 mb-1">D1</span>
                  <span className="text-xs text-gray-400 font-bold tracking-[0.2em] uppercase">All-American</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default FinalCTA;