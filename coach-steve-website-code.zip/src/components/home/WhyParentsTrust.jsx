import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2, Quote, Star, Trophy } from 'lucide-react';
import TextRevealAnimation from '@/components/TextRevealAnimation';

const WhyParentsTrust = () => {
  const reasons = [
    'Proven track record with 100+ athletes developed', 
    'D1 All-American and College World Series experience', 
    'Personalized attention and customized training plans', 
    'Regular progress updates and transparent communication', 
    'Focus on long-term development, not quick fixes', 
    'Emphasis on both physical skills and mental game', 
    'Safe, professional training environment', 
    'Flexible scheduling to accommodate busy families', 
    'Connections to college and showcase opportunities', 
    'Genuine care for each athlete\'s success'
  ];

  return (
    <section className="py-24 bg-[#0A1628] relative overflow-hidden">
      {/* Premium Background Glows */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-[#e4002b]/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-[#1153d8]/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid md:grid-cols-2 gap-16 lg:gap-24 items-center max-w-7xl mx-auto">
          {/* Left Column */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }} 
            whileInView={{ opacity: 1, x: 0 }} 
            viewport={{ once: true }} 
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black text-white mb-8 tracking-tighter font-montserrat leading-none">
              <TextRevealAnimation>
                WHY PARENTS
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-[#1153d8] via-[#e4002b] to-[#e4002b]">
                  TRUST COACH STEVE
                </span>
              </TextRevealAnimation>
            </h2>
            <div className="w-32 h-2 bg-gradient-to-r from-[#e4002b] to-[#1153d8] mb-10 rounded-full"></div>
            <p className="text-xl text-gray-300 leading-relaxed mb-12 font-light">
              When you invest in your child's baseball development, you deserve a coach who understands the commitment, values open communication, and delivers real results.
            </p>
            
            <div className="space-y-5">
              {reasons.map((reason, index) => (
                <motion.div 
                  key={index} 
                  initial={{ opacity: 0, x: -20 }} 
                  whileInView={{ opacity: 1, x: 0 }} 
                  viewport={{ once: true }} 
                  transition={{ duration: 0.4, delay: index * 0.05 }} 
                  className="flex items-start gap-4 group"
                >
                  <div className="mt-1 flex-shrink-0 w-6 h-6 rounded-full bg-[#e4002b]/10 flex items-center justify-center border border-[#e4002b]/30 group-hover:bg-[#e4002b] group-hover:border-[#e4002b] transition-all duration-300 shadow-[0_0_10px_rgba(228,0,43,0.2)]">
                     <CheckCircle2 className="text-[#e4002b] w-3.5 h-3.5 group-hover:text-[#0A1628] transition-colors stroke-[3px]" />
                  </div>
                  <span className="text-gray-300 font-medium text-base group-hover:text-white transition-colors">{reason}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right Column - Premium Design System Update */}
          <motion.div 
            initial={{ opacity: 0, x: 30 }} 
            whileInView={{ opacity: 1, x: 0 }} 
            viewport={{ once: true }} 
            transition={{ duration: 0.8 }} 
            className="flex flex-col gap-8 mt-12 md:mt-0"
          >
            {/* Main Image with Premium Container */}
            <motion.div 
              className="relative group rounded-3xl overflow-hidden shadow-2xl border border-[#e4002b]/20 bg-[#0F1F3A]" 
              whileHover={{ scale: 1.02 }} 
              transition={{ duration: 0.5 }}
            >
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A1628] via-transparent to-transparent opacity-80 z-10 transition-opacity duration-300 group-hover:opacity-60" />
                <img className="w-full h-72 sm:h-96 object-cover transform transition-transform duration-700 group-hover:scale-110" alt="Coach working with young baseball player" src="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/Sam%20Training%20with%20Coach%20Steve.png" />
                
                {/* Floating Badge on Image */}
                <div className="absolute top-6 right-6 z-20">
                     <div className="bg-[#0A1628]/90 backdrop-blur-md border border-[#e4002b]/50 p-4 rounded-2xl shadow-xl flex flex-col items-center">
                         <span className="text-[#e4002b] font-black text-3xl leading-none mb-1">100+</span>
                         <span className="text-white text-[10px] uppercase tracking-[0.2em] font-bold">Athletes</span>
                     </div>
                </div>

                <div className="absolute bottom-6 left-6 z-20">
                    <div className="bg-[#e4002b] text-[#0A1628] text-xs font-black px-4 py-2 rounded-lg uppercase tracking-widest shadow-lg shadow-[#e4002b]/20">
                    Real Development
                    </div>
                </div>
            </motion.div>
            
            {/* Feedback Card 1 */}
            <motion.div 
              whileHover={{ y: -8, borderColor: 'rgba(228, 0, 43, 0.5)' }} 
              className="bg-[#0F1F3A] p-8 rounded-2xl border border-[#e4002b]/10 shadow-xl relative overflow-hidden group transition-all duration-300"
            >
                <div className="absolute top-0 right-0 p-4 opacity-[0.03] group-hover:opacity-10 transition-opacity duration-300 transform group-hover:rotate-12">
                     <Quote size={100} />
                </div>
                
                <div className="flex gap-1 mb-4">
                     {[...Array(5)].map((_, i) => <Star key={i} size={16} className="fill-[#e4002b] text-[#e4002b]" />)}
                </div>

                <h3 className="text-white font-black text-sm uppercase tracking-widest mb-4 flex items-center gap-4">
                    Parent Feedback
                    <div className="h-px bg-[#e4002b]/30 flex-grow"></div>
                </h3>

                <p className="text-gray-300 italic leading-relaxed mb-6 text-base relative z-10 font-light">
                    "Before working with Coach Steve, Gavin would just step in the box and swing. Over the season, he learned how to <span className="text-[#e4002b] font-medium">actually think through at-bats</span>. The growth wasn't just physical—it was mental."
                </p>
                <div className="flex items-center gap-3">
                     <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#e4002b] to-[#cc0026] flex items-center justify-center text-[#0A1628] text-xs font-black">
                         P
                     </div>
                     <p className="text-[#1153d8] font-bold text-xs uppercase tracking-widest">— Adam Goldstein - Parent of Gavin Goldstein 16U</p>
                </div>
            </motion.div>

            {/* Feedback Card 2 */}
            <motion.div 
              whileHover={{ y: -8, borderColor: 'rgba(228, 0, 43, 0.5)' }} 
              className="bg-[#0F1F3A] p-8 rounded-2xl border border-[#e4002b]/10 shadow-xl relative overflow-hidden group transition-all duration-300"
            >
                 <div className="absolute top-0 right-0 p-4 opacity-[0.03] group-hover:opacity-10 transition-opacity duration-300 transform group-hover:rotate-12">
                     <Trophy size={100} />
                </div>

                <div className="flex gap-1 mb-4">
                     {[...Array(5)].map((_, i) => <Star key={i} size={16} className="fill-[#e4002b] text-[#e4002b]" />)}
                </div>

                <h3 className="text-white font-black text-sm uppercase tracking-widest mb-4 flex items-center gap-4">
                    Player Results
                    <div className="h-px bg-[#e4002b]/30 flex-grow"></div>
                </h3>

                <p className="text-gray-300 italic leading-relaxed mb-6 text-base relative z-10 font-light">
                    "Exit velocity jumped from 61 mph to 73 mph in just 4 weeks—and that's just the start. Coach Steve completely transformed my approach at the plate."
                </p>
                <div className="flex items-center gap-3">
                     <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#e4002b] to-[#cc0026] flex items-center justify-center text-[#0A1628] text-xs font-black">
                         NO
                     </div>
                     <p className="text-[#1153d8] font-bold text-xs uppercase tracking-widest">— Nathan Ocampo</p>
                </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default WhyParentsTrust;