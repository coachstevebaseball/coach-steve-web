import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import PlayButtonOverlay from './PlayButtonOverlay';

const VideoCardBento = ({ video, className, onPlay }) => {
  return (
    <motion.div
      whileHover={{ y: -5 }}
      onClick={() => onPlay(video)}
      className={cn(
        "group relative bg-navy-800 rounded-xl overflow-hidden border border-gray-700/50 cursor-pointer shadow-lg hover:shadow-2xl hover:shadow-red-500/10 transition-all duration-300 flex flex-col h-full",
        className
      )}
    >
      <div className="relative w-full h-full overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={video.thumbnail || video.coverImage}
            alt={video.title}
            className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
            loading="lazy"
          />
          
          <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors duration-300" />
          
          <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
             <PlayButtonOverlay />
          </div>

          <div className="absolute top-4 left-4 z-20">
            <span className="inline-block bg-red-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow-md">
              {video.category}
            </span>
          </div>

          <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-navy-950 via-navy-950/80 to-transparent z-20">
            <h3 className="text-white font-bold text-lg leading-tight group-hover:text-blue-600 transition-colors line-clamp-2">
              {video.title}
            </h3>
            {video.duration && (
               <span className="text-gray-400 text-xs mt-1 block font-medium">{video.duration}</span>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default VideoCardBento;