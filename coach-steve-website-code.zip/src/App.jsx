import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { Toaster } from '@/components/ui/toaster';
import Navigation from '@/components/Navigation';
import ScrollToTop from '@/components/ScrollToTop';
import useLenis from '@/hooks/useLenis';
import { AdminAuthProvider } from '@/contexts/AdminAuthContext.jsx';

// Pages
import Home from '@/pages/Home';
import About from '@/pages/About';
import Training from '@/pages/Training';
import Testimonials from '@/pages/Testimonials';
import Contact from '@/pages/Contact';
import Blog from '@/pages/Blog';
import BlogPost from '@/pages/BlogPost';
import TrainingGallery from '@/pages/TrainingGallery';
import CoachSteveLandingPage from '@/pages/CoachSteveLandingPage';
import VideosGallery from '@/pages/VideosGallery';
import VideoDetail from '@/pages/VideoDetail';
import HittingInstructorLongIsland from '@/pages/HittingInstructorLongIsland';
import HittersLab from '@/pages/HittersLab';
import BookingPage from '@/pages/BookingPage';

// Admin Pages
import AdminLoginPage from '@/pages/admin/AdminLoginPage';
import AdminVideosPage from '@/pages/admin/AdminVideosPage';
import AdminAppointmentPanel from '@/pages/admin/AdminAppointmentPanel';
import ProtectedAdminRoute from '@/components/admin/ProtectedAdminRoute';

function AppContent() {
  // Initialize Lenis smooth scrolling globally
  useLenis();
  const location = useLocation();

  // Check if we are on the landing page
  const isLandingPage = location.pathname === '/youth-baseball-training';
  // Hide navigation on admin login
  const isAdminLogin = location.pathname.startsWith('/admin/login');

  return (
    <div className="min-h-screen bg-[#0A1628] flex flex-col font-sans">
      {/* Conditionally render Navigation */}
      {!isLandingPage && !isAdminLogin && <Navigation />}
      
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/training" element={<Training />} />
          <Route path="/hitters-lab" element={<HittersLab />} />
          <Route path="/booking" element={<BookingPage />} />
          <Route path="/training-gallery" element={<TrainingGallery />} />
          <Route path="/videos" element={<VideosGallery />} />
          <Route path="/videos/:id" element={<VideoDetail />} />
          <Route path="/testimonials" element={<Testimonials />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/:slug" element={<BlogPost />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/hitting-instructor-long-island" element={<HittingInstructorLongIsland />} />
          
          {/* Admin Routes */}
          <Route path="/admin/login" element={<AdminLoginPage />} />
          <Route 
            path="/admin/videos" 
            element={
              <ProtectedAdminRoute>
                <AdminVideosPage />
              </ProtectedAdminRoute>
            } 
          />
          <Route 
            path="/admin/appointments" 
            element={
              <ProtectedAdminRoute>
                <AdminAppointmentPanel />
              </ProtectedAdminRoute>
            } 
          />

          {/* Hidden Landing Page Route */}
          <Route path="/youth-baseball-training" element={<CoachSteveLandingPage />} />
        </Routes>
      </main>
      <Toaster />
    </div>
  );
}

function App() {
  return (
    <AdminAuthProvider>
      <Router>
        <ScrollToTop />
        <Helmet>
          <title>Coach Steve Baseball - Elite Baseball Training & Development</title>
          <meta name="description" content="D1 All-American Steven Goldstein offers elite baseball training for hitting, pitching, defense, and mental game. Trusted by 100+ athletes and MLB stars." />
        </Helmet>
        <AppContent />
      </Router>
    </AdminAuthProvider>
  );
}

export default App;