import React from 'react';
import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';
import { getAvatarData } from '@/data/avatarMapping';

const ResultsSection = () => {
  const testimonials = [
    {
      name: "Michelle C.",
      role: "From Hitting Last to Hitting 2nd!",
      quote: "Good morning Jordan had two games on Saturday and just meeting with you one time he improved so much. He hit a double and two singles, I took some videos in case you wanted to see how he performs up at the plate.",
    },
    {
      name: "Adam G",
      role: "Stats do not lie — .308 to .418",
      quote: "I've been coaching youth sports for 25 years and have encountered only a handful of extraordinary teachers. Steve is one of them. He played and continues to play an integral part in Gavin's development as a player.",
    },
    {
      name: "Mike J.",
      role: "From Struggling to Hit to Getting Awarded the Game Ball for Best Performance",
      quote: "Jack had a great game this past weekend. He hit a double over head and had a lot of other big hits. He was proud to get the game ball. Alex also pulled me aside to tell me how great Jack was hitting in the simulator cage today. Looks like we are really making progress with your work",
    },
    {
      name: "Joe M.",
      role: "Parent of 14U Player with Huge Upside Potential",
      quote: "Steve, I'll be honest with you about your style of coaching. I found that you got the best out of Joe you know. I went in and told him, you know I said listen Steve was really good for Joe.",
    },
    {
      name: "Mark W",
      role: "From Thoughts of Quitting to Real Success",
      quote: "Ethan was struggling to make the travel team. Steve worked on his mental game and swing. He made the A-team and is batting cleanup.",
    }
  ];

  return (
    <section className="py-24 bg-[#0a0e12] relative">
      {/* Background Texture */}
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-montserrat font-black text-4xl sm:text-5xl text-white mb-4"
          >
            Real Players. <span className="text-[#e4002b]">Real Results.</span>
          </motion.h2>
          <motion.div 
            initial={{ width: 0 }}
            whileInView={{ width: "100px" }}
            viewport={{ once: true }}
            className="h-1 bg-[#e4002b] mx-auto rounded-full"
          ></motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {testimonials.map((t, index) => {
            const avatarData = getAvatarData(t.name);
            
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                whileHover={{ y: -8, boxShadow: "0 20px 40px -15px rgba(228,0,43,0.1)" }}
                className="bg-[#0f1419] p-8 rounded-2xl border border-gray-800 hover:border-[#e4002b]/50 transition-all duration-300 group relative flex flex-col"
              >
                {/* Quote Icon Background */}
                <Quote className="absolute top-6 right-6 text-[#e4002b]/5 w-20 h-20 rotate-12 group-hover:text-[#e4002b]/10 transition-colors" />
                
                {/* Stars */}
                <div className="flex gap-1 mb-6">
                  {[...Array(5)].map((_, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, scale: 0 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.2 + (i * 0.1) }}
                    >
                      <Star size={16} className="fill-[#e4002b] text-[#e4002b]" />
                    </motion.div>
                  ))}
                </div>

                {/* Quote */}
                <p className="text-gray-300 text-lg mb-8 italic relative z-10 leading-relaxed group-hover:text-white transition-colors">
                  "{t.quote}"
                </p>

                {/* Author Info */}
                <div className="mt-auto flex items-center gap-6 pt-6 border-t border-gray-800 group-hover:border-[#e4002b]/20 transition-colors">
                  {avatarData.url ? (
                    <img 
                      src={avatarData.url} 
                      alt={t.name} 
                      className="w-24 h-24 rounded-full object-cover border-2 border-[#e4002b]/50 shadow-lg shrink-0"
                    />
                  ) : (
                    <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#e4002b] to-[#cc0026] flex items-center justify-center text-white font-bold text-3xl shadow-lg border-2 border-[#e4002b]/50 shrink-0">
                      {t.name.charAt(0)}
                    </div>
                  )}
                  <div>
                    <p className="text-white font-black text-xl tracking-tight">{t.name}</p>
                    <p className="text-[#e4002b] text-sm font-bold tracking-wide mt-1">{t.role}</p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default ResultsSection;