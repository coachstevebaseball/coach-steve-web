import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Trophy, Target, Award, MapPin, Users, Star, Quote, ArrowRight, Play } from 'lucide-react';
import Footer from '@/components/Footer';
import TextRevealAnimation from '@/components/TextRevealAnimation';
import VideoPlayer from '@/components/training/VideoPlayer';

const About = () => {
  const fadeInUp = {
    initial: {
      opacity: 0,
      y: 30
    },
    whileInView: {
      opacity: 1,
      y: 0
    },
    viewport: {
      once: true,
      margin: "-50px"
    },
    transition: {
      duration: 0.6,
      ease: "easeOut"
    }
  };

  const imageHover = {
    rest: {
      scale: 1
    },
    hover: {
      scale: 1.02
    }
  };

  const espnVideo = {
    type: 'mp4',
    url: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/Videos/Steven%20Goldstein%20RBI%20single%20in%20Super%20Regional.mp4',
    title: 'Steven Goldstein RBI single in Super Regional'
  };

  return (
    <>
      <Helmet>
        <title>About Coach Steve | D1 Player, 2012 College World Series, Long Island Hitting Coach</title>
        <meta name="description" content="Meet Coach Steve — D1 All-American at Stony Brook, 2012 College World Series participant. Now coaching hitters on Long Island with proven development methods." />
        <link rel="canonical" href="https://www.coachstevebaseball.com/about" />
        <meta property="og:title" content="About Coach Steve | D1 Player & Elite Hitting Instructor" />
        <meta property="og:description" content="D1 All-American, Stony Brook University, 2012 CWS. Private hitting coach developing youth & travel ball players on Long Island, NY." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.coachstevebaseball.com/about" />
        <meta property="og:image" content="https://horizons-cdn.hostinger.com/643121a3-01b2-4510-8f0f-dff98ee493ee/coach-steve-sliding-into-home-plate-for-the-born-braves-in-the-cape-cod-league.-K4fPQ.png" />
        <meta property="og:image:alt" content="Coach Steve sliding into home plate" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="About Coach Steve | D1 Player & Elite Hitting Instructor" />
      </Helmet>

      <div className="min-h-screen bg-navy-950 text-gray-100 overflow-x-hidden font-sans">
       
        <section className="relative min-h-[60vh] md:min-h-[70vh] lg:min-h-screen flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 z-0">
             <img src="https://horizons-cdn.hostinger.com/643121a3-01b2-4510-8f0f-dff98ee493ee/coach-steve-sliding-into-home-plate-for-the-born-braves-in-the-cape-cod-league.-K4fPQ.png" alt="Steven Goldstein Baseball" className="w-full h-full object-cover" loading="eager" />
             <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-navy-950/70 to-transparent"></div>
             <div className="absolute inset-0 bg-black/40"></div>
          </div>

          <div className="container mx-auto px-4 md:px-6 lg:px-8 relative z-10 pt-20">
            <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="max-w-4xl mx-auto text-center">
              <div className="inline-flex items-center gap-2 bg-red-500/10 border border-red-500/30 backdrop-blur-sm rounded-full px-4 py-1.5 mb-6 md:mb-8">
                <span className="text-red-500 font-black text-xs md:text-sm tracking-widest uppercase">THE JOURNEY</span>
              </div>
              <h1 className="text-3xl sm:text-5xl md:text-6xl lg:text-8xl font-black tracking-tighter text-white mb-6 md:mb-8 leading-tight md:leading-none drop-shadow-2xl font-montserrat">
                <TextRevealAnimation>
                  MORE THAN JUST <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-white">
                    A COACH
                  </span>
                </TextRevealAnimation>
              </h1>
              <p className="text-base md:text-xl lg:text-2xl text-gray-300 font-light leading-relaxed max-w-3xl mx-auto drop-shadow-md px-2">
                You can't teach what you haven't lived. Coach Steve knows the reality of elite baseball because he's survived the trenches.
              </p>
            </motion.div>
          </div>
        </section>

        <div className="bg-navy-950 relative">
          {/* ESPN Recognition Section */}
          <section className="py-8 md:py-24 px-0 md:px-6 lg:px-8 bg-navy-900 border-t border-b border-gray-800/50 overflow-hidden relative">
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-5"></div>
            <div className="container mx-auto max-w-5xl relative z-10">
              <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-8 md:mb-12 px-4">
                <div className="flex items-center justify-center gap-3 mb-4">
                  <Star className="text-red-500 w-5 h-5 md:w-6 md:h-6" />
                  <span className="text-red-500 font-black tracking-widest text-xs md:text-sm uppercase">ESPN Recognition</span>
                  <Star className="text-red-500 w-5 h-5 md:w-6 md:h-6" />
                </div>
                <h2 className="text-2xl sm:text-4xl md:text-5xl font-black text-white mb-4 leading-tight font-montserrat">
                  Coach Steve was called the <span className="text-red-500">pride of Long Island</span> on ESPN
                </h2>
                <p className="text-gray-300 text-base md:text-xl font-light max-w-3xl mx-auto">
                  Delivering a clutch RBI single in the NCAA Super Regionals on the national stage.
                </p>
              </motion.div>

              {/* VIDEO — full bleed on mobile, rounded on md+ */}
              <motion.div initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ duration: 0.6 }} className="relative md:rounded-3xl md:rounded-3xl overflow-hidden shadow-[0_0_40px_rgba(239,68,68,0.15)] md:border border-gray-700/50 bg-black group w-full">
                <VideoPlayer video={espnVideo} />
              </motion.div>
             
              <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ delay: 0.3 }} className="text-center mt-6 px-4">
                <p className="text-gray-400 font-light text-sm md:text-base italic flex items-center justify-center gap-2">
                  <Trophy className="w-4 h-4 text-gray-500" />
                  Featured on national television during the 2012 NCAA Super Regionals against LSU.
                </p>
              </motion.div>
            </div>
          </section>

          <section className="py-16 md:py-24 px-0 md:px-6 lg:px-8 overflow-hidden bg-navy-950">
            <div className="container mx-auto max-w-7xl">
              <div className="flex flex-col md:flex-row items-center gap-0 md:gap-10 lg:gap-16">
                {/* Premium Animated Image Section for St. Dominic */}
                <div className="w-full md:w-1/2">
                  <motion.div
                    initial={{ opacity: 0, x: -50 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
                    className="relative group rounded-2xl shadow-2xl p-[2px] bg-gradient-to-br from-[#e4002b]/30 to-transparent hover:from-[#e4002b]/80 transition-colors duration-500 overflow-hidden"
                  >
                    <div className="relative rounded-2xl overflow-hidden bg-navy-900 shadow-[0_0_15px_rgba(228,0,43,0.3)] group-hover:shadow-[0_0_30px_rgba(228,0,43,0.6)] transition-shadow duration-500 h-full w-full">
                      <motion.img 
                        src="https://assets.zyrosite.com/OjCX9JtYPPwxfpnW/chatgpt-image-jan-3-2026-10_35_31-am-etjh1-34j5wUKerC9yKw6C.png" 
                        alt="Steven Goldstein St. Dominic"
                        className="w-full h-auto object-cover aspect-[16/10] md:aspect-auto group-hover:scale-105 transition-transform duration-700 ease-[cubic-bezier(0.25,0.46,0.45,0.94)]"
                        loading="lazy"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-navy-950/90 via-transparent to-transparent opacity-80 group-hover:opacity-60 transition-opacity duration-500"></div>
                      <div className="absolute bottom-4 left-4 md:bottom-6 md:left-6">
                        <span className="bg-red-500 text-white text-[10px] md:text-xs font-black px-3 py-1 rounded-sm uppercase tracking-wider mb-2 inline-block">High School</span>
                      </div>
                    </div>
                  </motion.div>
                </div>

                <div className="w-full md:w-1/2 space-y-4 md:space-y-6 px-4 md:px-0 pt-8 md:pt-0">
                   <div className="flex items-center gap-3 mb-2">
                     <MapPin className="text-red-500" size={20} />
                     <span className="text-red-500 font-bold tracking-widest text-xs md:text-sm uppercase">The Foundation</span>
                   </div>
                   <h2 className="text-2xl sm:text-4xl md:text-5xl font-black text-white leading-tight font-montserrat">
                     FROM ST. DOMINIC TO <br className="hidden md:block" />
                     <span className="text-red-500">#1 PROSPECT</span>
                   </h2>
                   <p className="text-gray-300 text-base md:text-lg font-light leading-relaxed max-w-2xl">
                     Before the national stage, Steven built his foundation right here on Long Island. As a standout at St. Dominic High School, he dominated the local circuit, earning <strong className="text-white font-bold">All-Conference honors three times</strong>.
                   </p>
                   <div className="flex flex-wrap gap-2 md:gap-3 pt-2 md:pt-4">
                     <span className="px-3 py-1.5 md:px-4 md:py-2 bg-navy-950 text-white text-xs md:text-sm font-bold rounded-lg border border-red-500/20 shadow-lg">
                       3x All-Conference
                     </span>
                     <span className="px-3 py-1.5 md:px-4 md:py-2 bg-navy-950 text-white text-xs md:text-sm font-bold rounded-lg border border-red-500/20 shadow-lg">
                       #1 Ranked Prospect (2011)
                     </span>
                   </div>
                </div>
              </div>
            </div>
          </section>

          {/* Premium Animated Image Section */}
          <div className="w-full lg:w-1/2 mx-auto px-4 md:px-6 lg:px-8 py-8 md:py-16">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="relative group rounded-2xl shadow-2xl p-[2px] bg-gradient-to-br from-[#e4002b]/30 to-transparent hover:from-[#e4002b]/60 transition-colors duration-700 overflow-hidden"
            >
              <div className="relative rounded-2xl overflow-hidden bg-navy-900 h-full w-full">
                {/* Image with Grayscale & Scale transitions */}
                <img 
                  src="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/Steven%20didn't%20just%20give%20him%20swing%20cues%20he%20helped%20Derek%20understand%20why%20the%20swing%20works%20and%20how%20it%20translates%20in%20real%20game%20situations.%20That%20connection%20made%20everything%20click..png" 
                  alt="Coach Steve insight on Derek's swing mechanics and game translation"
                  className="w-full h-auto object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700 ease-[cubic-bezier(.16,1,.3,1)]"
                  loading="lazy"
                />
              </div>
            </motion.div>
          </div>

          {/* Stony Brook / CWS Section */}
          <section className="py-16 md:py-24 px-0 md:px-6 lg:px-8 bg-navy-900 overflow-hidden relative">
             <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-red-500/5 to-transparent pointer-events-none"></div>

            <div className="container mx-auto max-w-7xl relative z-10">
              <motion.div {...fadeInUp} className="flex flex-col md:flex-row-reverse items-center gap-0 md:gap-10 lg:gap-16">
                 {/* IMAGE — full bleed on mobile */}
                 <div className="w-full md:w-1/2">
                  <motion.div className="relative md:rounded-2xl overflow-hidden shadow-2xl md:border border-gray-800 hover:border-red-500/30 transition-all duration-300 group" whileHover="hover" initial="rest">
                    <motion.img src="https://assets.zyrosite.com/OjCX9JtYPPwxfpnW/3e38bf3e-0145-4857-b017-0897225cc64f-TJroGgENZRzGsGFM.png" alt="Steven Goldstein Stony Brook" className="w-full h-auto object-cover aspect-[16/10] md:aspect-auto" variants={imageHover} transition={{ duration: 0.5 }} />
                    <div className="absolute inset-0 bg-gradient-to-t from-navy-950/90 via-transparent to-transparent opacity-80"></div>
                     <div className="absolute bottom-4 left-4 md:bottom-6 md:left-6">
                      <span className="bg-red-500 text-white text-[10px] md:text-xs font-black px-3 py-1 rounded-sm uppercase tracking-wider mb-2 inline-block">NCAA Division I</span>
                    </div>
                  </motion.div>
                </div>

                <div className="w-full md:w-1/2 space-y-4 md:space-y-6 px-4 md:px-0 pt-8 md:pt-0">
                   <div className="flex items-center gap-3 mb-2">
                     <Award className="text-red-500" size={20} />
                     <span className="text-blue-600 font-bold tracking-widest text-xs md:text-sm uppercase">The Breakout</span>
                   </div>
                   <h2 className="text-2xl sm:text-4xl md:text-5xl font-black text-white leading-tight font-montserrat">
                     FRESHMAN ALL-AMERICAN & <br className="hidden md:block" />
                     <span className="text-red-500">COLLEGE WORLD SERIES</span>
                   </h2>
                   <p className="text-gray-300 text-base md:text-lg font-light leading-relaxed max-w-2xl">
                     Steven's freshman campaign at Stony Brook was historic: a <strong className="text-white font-bold">.337 batting average</strong> and <strong className="text-red-500 font-bold">Louisville Slugger Freshman All-American</strong> honors.
                   </p>
                   <div className="bg-navy-950 p-5 md:p-6 rounded-xl border-l-4 border-red-500 shadow-xl max-w-2xl">
                     <p className="text-gray-300 italic text-base md:text-lg font-medium">
                       "In the 2012 Super Regionals against LSU, on national ESPN television, Steven delivered a clutch 10th-inning home run that silenced the crowd."
                     </p>
                   </div>
                </div>
              </motion.div>
            </div>
          </section>

          {/* Giving Back / Coaching Section */}
          <section className="py-16 md:py-24 px-0 md:px-6 lg:px-8 overflow-hidden bg-navy-950">
            <div className="container mx-auto max-w-7xl">
              <motion.div {...fadeInUp} className="flex flex-col md:flex-row items-center gap-0 md:gap-10 lg:gap-16">
                {/* IMAGE — full bleed on mobile */}
                <div className="w-full md:w-1/2">
                  <motion.div className="relative md:rounded-2xl overflow-hidden shadow-2xl md:border border-gray-800 hover:border-red-500/30 transition-all duration-300 group" whileHover="hover" initial="rest">
                    <motion.img src="https://assets.zyrosite.com/OjCX9JtYPPwxfpnW/05891dc8-a661-490f-b464-1565d6a2904c-1tFUw2Y1yjglvwYl.png" alt="Steven Goldstein Coaching" className="w-full h-auto object-cover aspect-[16/10] md:aspect-auto" variants={imageHover} transition={{ duration: 0.5 }} />
                     <div className="absolute inset-0 bg-gradient-to-t from-navy-950/90 via-transparent to-transparent opacity-80"></div>
                     <div className="absolute bottom-4 left-4 md:bottom-6 md:left-6">
                      <span className="bg-red-500 text-white text-[10px] md:text-xs font-black px-3 py-1 rounded-sm uppercase tracking-wider mb-2 inline-block">Next Generation</span>
                    </div>
                  </motion.div>
                </div>

                <div className="w-full md:w-1/2 space-y-4 md:space-y-6 px-4 md:px-0 pt-8 md:pt-0">
                   <div className="flex items-center gap-3 mb-2">
                     <Users className="text-red-500" size={20} />
                     <span className="text-blue-600 font-bold tracking-widest text-xs md:text-sm uppercase">Giving Back</span>
                   </div>
                   <h2 className="text-2xl sm:text-4xl md:text-5xl font-black text-white leading-tight font-montserrat">
                     BRINGING IT BACK TO <br className="hidden md:block" />
                     <span className="text-red-500">LONG ISLAND</span>
                   </h2>
                   <p className="text-gray-300 text-base md:text-lg font-light leading-relaxed mb-6 max-w-2xl">
                     Today, Steven is dedicated to developing the next generation of Long Island talent. Coaching at <strong className="text-white">Common Sense Baseball</strong>, he has trained over <strong className="text-red-500 font-bold">100+ athletes</strong>.
                   </p>
                   <a href="/contact" className="inline-flex items-center justify-center bg-gradient-to-r from-red-500 to-red-600 text-white px-6 md:px-8 py-3 md:py-4 rounded-lg font-black text-sm md:text-lg tracking-wider hover:scale-105 transition-transform duration-300 shadow-xl shadow-red-500/20 uppercase w-full sm:w-auto min-h-[44px]">
                     Train with Steven
                     <ArrowRight className="ml-2 stroke-[3px]" size={20} />
                   </a>
                </div>
              </motion.div>
            </div>
          </section>

          {/* Quote Section */}
          <section className="py-16 md:py-24 px-4 md:px-6 lg:px-8 bg-navy-900 relative">
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
            <div className="container mx-auto max-w-5xl relative z-10">
              <motion.div initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ duration: 0.8 }} className="relative p-8 md:p-12 lg:p-16 text-center overflow-hidden rounded-2xl md:rounded-3xl bg-gradient-to-br from-navy-800 to-navy-950 border border-gray-700/50 shadow-2xl">
                <div className="absolute top-0 right-0 p-4 opacity-5">
                   <Quote size={200} />
                </div>
               
                <Quote className="text-red-500 w-10 h-10 md:w-16 md:h-16 mx-auto mb-6 md:mb-8" />
               
                <h3 className="text-lg sm:text-2xl md:text-3xl lg:text-4xl font-bold text-white leading-snug mb-6 md:mb-8 relative z-10 font-montserrat italic max-w-4xl mx-auto">
                  "I've walked the path these kids dream about—from local fields to Omaha. My goal isn't just to teach them how to swing or throw, but how to think, compete, and carry themselves like champions."
                </h3>
               
                <div className="flex flex-col items-center justify-center">
                  <div className="w-16 md:w-24 h-1.5 bg-red-500 mb-4 md:mb-6 rounded-full"></div>
                  <p className="text-red-500 font-black tracking-[0.2em] text-sm md:text-lg uppercase">
                    Steven Goldstein
                  </p>
                  <p className="text-gray-400 text-xs md:text-sm mt-2 uppercase tracking-wide font-bold">
                    Elite Baseball Coach
                  </p>
                </div>
              </motion.div>
            </div>
          </section>
        </div>
       
        <Footer />
      </div>
    </>
  );
};

export default About;