import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2 } from 'lucide-react';
import Footer from '@/components/Footer';

const HittersLab = () => {
  const [isLoading, setIsLoading] = useState(true);

  return (
    <>
      <Helmet>
        <title>Hitter's Lab | Advanced Hitting Training | Coach Steve</title>
        <meta name="description" content="Experience advanced baseball training at Hitters Lab. State-of-the-art facility with expert coaching and swing analysis technology." />
        <link rel="canonical" href="https://www.coachstevebaseball.com/hitters-lab" />
        <meta property="og:title" content="Hitter's Lab | Advanced Hitting Training | Coach Steve" />
        <meta property="og:description" content="Experience advanced baseball training at Hitters Lab. State-of-the-art facility with expert coaching and swing analysis technology." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.coachstevebaseball.com/hitters-lab" />
        <meta property="og:image" content="https://images.unsplash.com/photo-1490326149782-dd42fa59bd9f" />
        <meta property="og:image:alt" content="Hitter's Lab Training" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Hitter's Lab | Advanced Hitting Training | Coach Steve" />
      </Helmet>

      <div className="bg-navy-950 min-h-screen font-sans flex flex-col pt-20 md:pt-24">
        {/* Header Section */}
        <div className="container mx-auto px-4 mb-8">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="text-3xl md:text-5xl font-black font-montserrat tracking-tight text-white uppercase mb-2">
              COACH STEVE'S{' '}<span className="text-red-500">HITTERS LAB</span>
            </h1>
            <p className="text-gray-400 font-light max-w-2xl mx-auto">
              Cape Cod League. College World Series. Real results.{' '}
              <span className="text-white">225+ drills</span> across{' '}
              <span className="text-white">8 skill categories</span> and{' '}
              <span className="text-white">3 levels</span> — built by someone who's been in the box when it matters most.
            </p>
          </motion.div>
        </div>

        {/* Iframe Container — full width, no container constraints */}
        <div className="flex-grow w-full pb-16">
          <div className="relative w-full rounded-2xl overflow-hidden bg-navy-900 border border-gray-800 shadow-2xl">

            <AnimatePresence>
              {isLoading && (
                <motion.div
                  initial={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 flex items-center justify-center bg-navy-950 z-10"
                >
                  <div className="text-center">
                    <Loader2 className="w-12 h-12 text-red-500 animate-spin mx-auto mb-4" />
                    <h2 className="text-white text-xl font-black font-montserrat tracking-wider uppercase">
                      Loading{' '}<span className="text-red-500">Hitters Lab</span>
                    </h2>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="relative w-full overflow-hidden" style={{ minHeight: '100vh' }}>
              <iframe
                src="https://coachstevemobilecoach.com"
                width="100%"
                height="100%"
                frameBorder="0"
                allowFullScreen
                className="w-full border-none"
                style={{ minHeight: '100vh' }}
                title="Hitters Lab Mobile Coach"
                onLoad={() => setIsLoading(false)}
                allow="camera; microphone; fullscreen; display-capture"
              />
            </div>
          </div>

          <div className="mt-8 text-center">
            <p className="text-gray-500 text-sm">
              Powered by Coach Steve Baseball — Player Development Platform
            </p>
          </div>
        </div>

        <Footer />
      </div>
    </>
  );
};

export default HittersLab;