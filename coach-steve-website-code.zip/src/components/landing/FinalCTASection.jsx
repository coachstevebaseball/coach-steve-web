import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, Phone, Mail, ArrowRight } from 'lucide-react';

const FinalCTASection = () => {
  return (
    <section className="py-32 bg-[#0a0e12] relative overflow-hidden">
      {/* Decorative Gradients */}
      <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-[#0f1419] to-[#0a0e12]"></div>
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-[#d4af37]/10 rounded-full blur-[100px] pointer-events-none"></div>
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-[#4FC3F7]/5 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="container mx-auto px-4 relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          <motion.span 
            initial={{ opacity: 0 }} 
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="text-[#d4af37] font-bold tracking-[0.2em] uppercase mb-6 block"
          >
            Don't Wait for the Season to Start
          </motion.span>

          <h2 className="font-montserrat font-black text-5xl sm:text-7xl md:text-8xl text-white mb-10 leading-none">
            READY TO <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#d4af37] via-[#fff] to-[#d4af37]">GET BETTER?</span>
          </h2>
          
          <p className="text-xl sm:text-2xl text-gray-300 mb-16 leading-relaxed font-light max-w-3xl mx-auto">
            If you're serious about improving — not just showing up — this is where the work gets done.
          </p>

          <div className="flex flex-col items-center gap-10">
            <motion.a 
              whileHover={{ scale: 1.05, boxShadow: "0 0 40px rgba(212, 175, 55, 0.3)" }}
              whileTap={{ scale: 0.95 }}
              href="tel:5164288081"
              className="group relative inline-flex items-center gap-4 px-12 py-6 bg-gradient-to-r from-[#d4af37] to-[#b5952f] text-black font-black text-xl uppercase tracking-widest rounded-sm overflow-hidden shadow-2xl"
            >
              <span className="relative z-10 flex items-center gap-3">
                <Calendar className="w-6 h-6" strokeWidth={2.5} />
                Schedule Private Lesson
              </span>
              <div className="absolute inset-0 bg-white/30 transform -skew-x-12 translate-x-full group-hover:translate-x-0 transition-transform duration-500 ease-out"></div>
            </motion.a>

            <div className="flex flex-col sm:flex-row gap-8 sm:gap-16 mt-4">
              <a href="mailto:coach@coachstevebaseball.com" className="group flex items-center gap-3 text-gray-400 hover:text-white transition-colors">
                <div className="w-10 h-10 rounded-full bg-[#1a1f26] flex items-center justify-center group-hover:bg-[#d4af37] transition-colors duration-300">
                  <Mail size={18} className="group-hover:text-black transition-colors" />
                </div>
                <span className="text-lg">coach@coachstevebaseball.com</span>
              </a>
              <a href="tel:5164288081" className="group flex items-center gap-3 text-gray-400 hover:text-white transition-colors">
                <div className="w-10 h-10 rounded-full bg-[#1a1f26] flex items-center justify-center group-hover:bg-[#d4af37] transition-colors duration-300">
                  <Phone size={18} className="group-hover:text-black transition-colors" />
                </div>
                <span className="text-lg">516-428-8081</span>
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default FinalCTASection;