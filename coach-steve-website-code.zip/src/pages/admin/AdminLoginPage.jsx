import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { Shield, Loader2 } from 'lucide-react';
import { useAdminAuth } from '@/contexts/AdminAuthContext';
import { useToast } from '@/hooks/use-toast';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';

const AdminLoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  
  const { login } = useAdminAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();

  const from = location.state?.from?.pathname || '/admin/videos';

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Form validation preventing empty submissions
    if (!email.trim() || !password.trim()) {
      setErrorMsg('Please enter both email and password.');
      return;
    }

    setErrorMsg('');
    setIsSubmitting(true);

    try {
      const result = await login(email, password);
      
      if (result.success) {
        toast({
          title: "Login Successful",
          description: "Welcome back to the admin dashboard.",
        });
        navigate(from, { replace: true });
      } else {
        // Clear error messages for failed login attempts
        setErrorMsg(result.error || 'Invalid email or password');
        // Clear password field on failure
        setPassword('');
      }
    } catch (err) {
      setErrorMsg('An unexpected error occurred. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleForgotPassword = (e) => {
    e.preventDefault();
    toast({
      title: "Password Recovery",
      description: "Please contact the system administrator to reset your password.",
      variant: "destructive"
    });
  };

  return (
    <>
      <Helmet>
        <title>Admin Login - Coach Steve</title>
        <meta name="robots" content="noindex, nofollow" />
      </Helmet>

      <div className="min-h-screen bg-[#0A1628] flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-8 shadow-2xl">
          <div className="flex flex-col items-center mb-8">
            <div className="w-16 h-16 bg-[#EF4444]/20 rounded-full flex items-center justify-center mb-4 border border-[#EF4444]/50">
              <Shield className="w-8 h-8 text-[#EF4444]" />
            </div>
            <h1 className="text-2xl font-black text-white uppercase tracking-wider">Admin Portal</h1>
            <p className="text-gray-400 mt-2 text-sm text-center">Enter your credentials to access the management dashboard.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {errorMsg && (
              <div className="p-3 bg-[#EF4444]/10 border border-[#EF4444]/50 rounded-lg text-[#EF4444] text-sm text-center animate-in fade-in zoom-in duration-300">
                {errorMsg}
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="email" className="text-gray-300">Email Address</Label>
              <Input
                id="email"
                type="email"
                placeholder="admin@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                disabled={isSubmitting}
                className="bg-white/10 border-white/20 text-white placeholder:text-gray-500 focus-visible:ring-[#EF4444]"
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password" className="text-gray-300">Password</Label>
                <button 
                  onClick={handleForgotPassword}
                  className="text-xs text-[#EF4444] hover:text-white transition-colors disabled:opacity-50"
                  type="button"
                  disabled={isSubmitting}
                >
                  Forgot Password?
                </button>
              </div>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                disabled={isSubmitting}
                className="bg-white/10 border-white/20 text-white placeholder:text-gray-500 focus-visible:ring-[#EF4444]"
              />
            </div>

            <Button 
              type="submit" 
              className="w-full bg-[#EF4444] hover:bg-[#DC2626] text-white font-bold h-12 transition-all duration-300"
              disabled={isSubmitting || !email.trim() || !password.trim()}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Authenticating...
                </>
              ) : (
                'Login to Dashboard'
              )}
            </Button>
          </form>
        </div>
      </div>
    </>
  );
};

export default AdminLoginPage;