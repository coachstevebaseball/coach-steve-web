import React from 'react';
import { motion } from 'framer-motion';

const HRVsLSUVideo = () => {
  return (
    <section className="py-16 md:py-24 bg-[#0A1628] relative overflow-hidden">
      <div className="container mx-auto px-4 sm:px-6 md:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-12 lg:gap-20 max-w-7xl mx-auto">
          
          {/* Left Column: Video */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="w-full md:w-1/2 relative"
          >
            <div className="relative rounded-2xl overflow-hidden shadow-2xl shadow-black/60 border border-gray-800/40 aspect-video w-full transform md:-rotate-2 hover:rotate-0 transition-transform duration-500">
              <video
                src="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/index.mp4"
                autoPlay
                loop
                muted
                playsInline
                className="w-full h-full object-cover"
                poster="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/stonybrook-swing.png"
              >
                Your browser does not support the video tag.
              </video>
              {/* Subtle overlay gradient to blend with the dark background nicely */}
              <div className="absolute inset-0 bg-gradient-to-tr from-black/20 to-transparent pointer-events-none"></div>
            </div>
          </motion.div>

          {/* Right Column: Text Content */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
            className="w-full md:w-1/2 flex flex-col items-start text-left"
          >
            {/* Red Accent Bar */}
            <div className="w-16 h-1.5 bg-[#EF4444] mb-6 rounded-full"></div>
            
            <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-white mb-6 tracking-tight uppercase leading-[1.1]">
              HR VS LSU THAT CLINCHED <br />
              <span className="text-[#EF4444]">OMAHA</span>
            </h2>
            
            <p className="text-base sm:text-lg md:text-xl text-gray-300 font-light">
              2012. Baton Rouge. Packed house. 2 strikes. One swing changed everything.
            </p>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default HRVsLSUVideo;