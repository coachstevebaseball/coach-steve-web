import React from 'react';
import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: 'Joe M',
      role: 'Parent of Player 13u',
      text: 'Steve, I will be honest with you about your style of coaching I found that you got the best out of Joe. I went in and told him Steve was really good for Joe today.',
      rating: 5
    },
    {
      name: "Gavin's Parent",
      role: 'Parent of Youth Athlete 16u',
      text: "Steve Goldstein is a godsend. He committed that he'd transition Gavin from a solid singles contact hitter to a dominant gap-to-gap doubles guy and hasn't disappointed. Gavin is truly thriving and is now realistically talking about playing beyond high school.",
      rating: 5
    },
    {
      name: 'Carlos V',
      role: 'Parent of Youth Player 15u',
      text: 'His skills have truly transformed, and its exciting to see how far he can go with your guidance. The dedication you have shown as a coach has made all the difference in his development.',
      rating: 5
    },
    {
      name: 'Mike J',
      role: 'Parent of Youth Athlete 10u',
      text: 'Jack had a great game this past weekend. He hit a double over head and had a lot of other big hits. He was proud to get the game ball. Alex also pulled me aside to tell me how great Jack was hitting in the simulator cage today.',
      rating: 5
    }
  ];

  return (
    <section className="py-12 md:py-24 bg-gradient-to-b from-[#0F1F3A] to-[#0A1628] relative overflow-hidden">
      {/* Decorative BG */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-[#d4af37]/5 skew-x-12 pointer-events-none"></div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-10 md:mb-20"
        >
          <div className="inline-flex items-center gap-2 bg-[#d4af37]/10 border border-[#d4af37] rounded-full px-5 py-2 mb-4 md:mb-6">
            <Quote className="text-[#d4af37]" size={14} fill="#d4af37" />
            <span className="text-[#d4af37] font-black text-xs tracking-[0.2em] uppercase">Real Feedback</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-7xl font-black text-white mb-4 md:mb-6 tracking-tighter leading-none">
            SUCCESS <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#4FC3F7] to-[#d4af37]">STORIES</span>
          </h2>
          <div className="w-16 md:w-24 h-1.5 bg-gradient-to-r from-[#d4af37] to-[#C9A961] mx-auto mb-6 md:mb-8 rounded-full"></div>
          <p className="text-base md:text-xl text-gray-300 max-w-3xl mx-auto font-light leading-relaxed px-2">
            Real results from real families and athletes who have trusted the process.
          </p>
        </motion.div>

        <div className="flex flex-col lg:flex-row-reverse items-start gap-8 md:gap-12 max-w-7xl mx-auto">
          
          {/* Right Column (Desktop): Image Card */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="w-full lg:w-5/12 sticky top-24"
          >
             <div className="relative rounded-2xl overflow-hidden border border-[#d4af37]/30 shadow-2xl group">
               <img 
                 src="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/4A43932C-1D1C-4A0B-883A-5EFD23B88580%20(1).png" 
                 alt="Coach Steve Team Talk Post Game" 
                 className="w-full h-auto object-cover transform group-hover:scale-105 transition-transform duration-700 ease-out min-h-[300px] md:min-h-[500px]"
                 loading="lazy"
               />
               <div className="absolute inset-0 bg-gradient-to-t from-[#0A1628] via-[#0A1628]/40 to-transparent opacity-90"></div>
               
               <div className="absolute top-6 right-6">
                 <div className="bg-[#d4af37] p-3 md:p-4 rounded-xl shadow-lg transform rotate-6 hover:rotate-0 transition-transform duration-300">
                   <Quote className="text-[#0A1628]" size={24} md:size={32} fill="#0A1628" />
                 </div>
               </div>

               <div className="absolute bottom-6 md:bottom-8 left-6 md:left-8 right-6 md:right-8">
                  <div className="border-l-4 border-[#d4af37] pl-4 md:pl-6">
                    <p className="text-white font-bold text-lg md:text-xl italic leading-relaxed mb-3 md:mb-4">
                      "The impact goes beyond the diamond. We're building young men of character, discipline, and resilience."
                    </p>
                    <p className="text-[#d4af37] font-black uppercase tracking-widest text-xs">- Coach Steve</p>
                  </div>
               </div>
             </div>
          </motion.div>

          {/* Left Column (Desktop): Testimonials Grid */}
          <div className="w-full lg:w-7/12">
            <div className="grid grid-cols-1 gap-6">
              {testimonials.map((testimonial, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  whileHover={{ x: 10, backgroundColor: 'rgba(212, 175, 55, 0.05)' }}
                  className="bg-gradient-to-br from-[#0F1F3A] to-[#0A1628] border border-[#d4af37]/10 rounded-2xl p-6 md:p-8 hover:border-[#d4af37]/50 transition-all duration-300 shadow-lg flex flex-col relative group"
                >
                  <div className="absolute top-6 md:top-8 right-6 md:right-8 opacity-10 group-hover:opacity-20 transition-opacity">
                    <Quote size={40} md:size={48} className="text-[#d4af37]" />
                  </div>

                  <div className="flex gap-1 mb-4 md:mb-6">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="text-[#d4af37]" size={16} md:size={18} fill="#d4af37" />
                    ))}
                  </div>
                  
                  <p className="text-gray-300 italic leading-loose mb-6 md:mb-8 text-sm md:text-base font-light relative z-10">
                    "{testimonial.text}"
                  </p>
                  
                  <div className="border-t border-[#d4af37]/10 pt-4 md:pt-6 mt-auto flex items-center gap-4">
                    <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-gradient-to-br from-[#d4af37] to-[#C9A961] flex items-center justify-center text-[#0A1628] font-black text-xs md:text-sm">
                      {testimonial.name.charAt(0)}
                    </div>
                    <div>
                      <p className="text-white font-black text-sm md:text-base uppercase tracking-wide">{testimonial.name}</p>
                      <p className="text-[#4FC3F7] font-bold text-[10px] md:text-xs uppercase tracking-widest">{testimonial.role}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;