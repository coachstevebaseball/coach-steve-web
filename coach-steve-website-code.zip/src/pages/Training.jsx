import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Target, Zap, Brain, Eye, Users, MapPin, Award } from 'lucide-react';
import Footer from '@/components/Footer';
import SupabaseVideoGallery from '@/components/training/SupabaseVideoGallery';
import TextRevealAnimation from '@/components/TextRevealAnimation';
import WhyParentsTrust from '@/components/home/WhyParentsTrust';

const Training = () => {
  const workOnCards = [{
    title: "Mechanical Excellence",
    description: "Refining hitting, throwing, and fielding mechanics for consistent, high-level performance.",
    icon: <Target className="w-8 h-8 md:w-10 md:h-10 text-blue-600" />,
    borderColor: "border-blue-600/30"
  }, {
    title: "Game Situational Work",
    description: "Training that replicates real competition pressure and decision-making scenarios.",
    icon: <Zap className="w-8 h-8 md:w-10 md:h-10 text-red-500" />,
    borderColor: "border-red-500/30"
  }, {
    title: "Mental Approach",
    description: "Building confidence, focus, and the ability to perform under pressure.",
    icon: <Brain className="w-8 h-8 md:w-10 md:h-10 text-blue-600" />,
    borderColor: "border-blue-600/30"
  }, {
    title: "Baseball IQ",
    description: "Understanding the why behind every play, developing instincts and game awareness.",
    icon: <Eye className="w-8 h-8 md:w-10 md:h-10 text-red-500" />,
    borderColor: "border-red-500/30"
  }];

  return <>
      <Helmet>
        <title>Baseball Training Services | Private Hitting Lessons Long Island | Coach Steve</title>
        <meta name="description" content="Private baseball hitting instruction, Blast Motion swing analytics, drill libraries, and more. Coach Steve Baseball trains youth and travel ball players on Long Island." />
        <link rel="canonical" href="https://www.coachstevebaseball.com/training" />
        <meta property="og:title" content="Baseball Training Services | Coach Steve Baseball Long Island" />
        <meta property="og:description" content="Private hitting lessons, swing analytics, and player development programs. Serving Long Island youth & travel ball." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.coachstevebaseball.com/training" />
        <meta property="og:image" content="https://images.unsplash.com/photo-1490326149782-dd42fa59bd9f" />
        <meta property="og:image:alt" content="Baseball Training Services" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Baseball Training Services | Coach Steve Baseball Long Island" />
      </Helmet>

      <div className="bg-navy-950 min-h-screen font-sans text-white overflow-x-hidden">
        
        <div className="relative min-h-[100dvh] flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 z-0">
            <img src="https://images.unsplash.com/photo-1490326149782-dd42fa59bd9f" alt="Baseball training background" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-r from-navy-950 via-navy-950/90 to-navy-950/60 md:to-transparent"></div>
            <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-transparent to-transparent"></div>
          </div>

          <div className="container mx-auto px-4 sm:px-6 md:px-8 z-10 pt-24 pb-12">
            <motion.div initial={{
            opacity: 0,
            y: 30
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.8
          }} className="max-w-4xl mx-auto md:mx-0">
              <div className="inline-flex items-center gap-2 bg-blue-600/20 backdrop-blur-sm text-blue-600 px-3 py-1.5 sm:px-4 sm:py-2 rounded-full text-xs sm:text-sm font-bold tracking-wide mb-6 border border-blue-600/30">
                <Users size={14} className="sm:w-4 sm:h-4" />
                <span>AGES 8-18</span>
              </div>

              <h1 className="text-3xl sm:text-5xl md:text-7xl lg:text-8xl font-black text-white leading-[1.1] md:leading-[0.9] tracking-tighter mb-6 font-montserrat">
                <TextRevealAnimation>
                  STOP WASTING <br />
                  <span className="text-red-500">AT BATS</span>
                </TextRevealAnimation>
              </h1>

              <h3 className="md:text-7xl font-black text-white leading-[1.1] md:leading-[0.9] tracking-tighter mb-6 font-montserrat">
                <TextRevealAnimation>
                 Train Like a Real Hitter <br />
                  <span className="text-red-500"> — Or Stay Average</span>
                </TextRevealAnimation>
              </h3>

              <p className="text-base sm:text-lg md:text-2xl text-gray-300 font-light leading-relaxed max-w-2xl mb-8">
                Private 1-on-1 Hitting Lessons in Westbury, NY
With Long Island’s Former #1 Prospect
              </p>

              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 sm:gap-6 mb-10 text-sm md:text-base font-semibold tracking-wide text-blue-600">
                <div className="flex items-center gap-2">
                  <MapPin className="text-red-500 w-5 h-5 flex-shrink-0" />
                  <span className="text-white">Nassau County, NY</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-gray-700/50 pt-8 max-w-3xl">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-1 sm:h-10 bg-red-500 rounded-full"></div>
                  <span className="font-bold text-gray-200 text-sm sm:text-base">ELITE HITTING<br />INSTRUCTOR</span>
                </div>
                <div className="flex items-center gap-3">
                   <div className="h-8 w-1 sm:h-10 bg-blue-600 rounded-full"></div>
                  <span className="font-bold text-gray-200 text-sm sm:text-base">PROVEN<br />RESULTS</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        <section className="py-12 bg-navy-900">
          <div className="container mx-auto px-4 max-w-7xl">
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} className="flex flex-col lg:flex-row items-center gap-8 bg-navy-950 rounded-3xl overflow-hidden border border-red-500/20 shadow-2xl">
              <div className="w-full lg:w-2/3">
                <video src="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/PRIVATE%20LESSONS%20COVER.mp4" autoPlay loop muted playsInline className="w-full h-auto object-cover" aria-label="Coach Steve providing expert baseball instruction during a private lesson">
                  Your browser does not support the video tag.
                </video>
              </div>
              <div className="w-full lg:w-1/3 p-8 md:p-12">
                <div className="flex items-center gap-3 mb-4">
                  <Award className="text-red-500 w-6 h-6" />
                  <span className="text-red-500 font-black tracking-widest text-sm uppercase">PERSONALIZATION</span>
                </div>
                <h3 className="text-2xl md:text-3xl font-black text-white mb-4 leading-tight font-montserrat">Train Like a Real Hitter — Or Stay Average</h3>
                <p className="text-gray-400 font-light leading-relaxed">
                  Players don’t just improve… they separate.

Exit velocity jumps (10+ MPH isn’t rare)
Swing becomes repeatable under pressure
Approach becomes intentional, not reactive
                </p>
              </div>
            </motion.div>
          </div>
        </section>

        <SupabaseVideoGallery />
        
        <WhyParentsTrust />

        <section className="py-12 md:py-24 bg-navy-950 relative">
          <div className="container mx-auto px-4 sm:px-6 md:px-8">
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} className="text-center mb-10 md:mb-16">
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-white mb-4 font-montserrat">
                <TextRevealAnimation>
                  WHAT WE <span className="text-blue-600">WORK ON</span>
                </TextRevealAnimation>
              </h2>
              <div className="w-16 md:w-24 h-1.5 bg-red-500 mx-auto rounded-full"></div>
            </motion.div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
              {workOnCards.map((card, idx) => <motion.div key={idx} initial={{
              opacity: 0,
              y: 20
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              delay: idx * 0.1
            }} className={`bg-navy-900 p-6 md:p-8 rounded-2xl border ${card.borderColor} shadow-lg hover:shadow-2xl hover:shadow-blue-900/10 md:hover:scale-105 transition-all duration-300 group`}>
                  <div className="bg-navy-800 w-16 h-16 md:w-20 md:h-20 rounded-2xl flex items-center justify-center mb-4 md:mb-6 shadow-inner md:group-hover:scale-110 transition-transform duration-300 border border-gray-800">
                    {card.icon}
                  </div>
                  <h3 className="text-lg md:text-xl font-bold text-white mb-2 md:mb-3 tracking-tight font-montserrat">{card.title}</h3>
                  <p className="text-gray-400 leading-relaxed text-sm font-light">
                    {card.description}
                  </p>
                </motion.div>)}
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>;
};

export default Training;