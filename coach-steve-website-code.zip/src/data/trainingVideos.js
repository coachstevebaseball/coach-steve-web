export const categories = [
  'ALL',
  'TRAINING',
  'HITTING FUNDAMENTALS',
  'SWING MECHANICS',
  'HITTING DRILL',
  'ADJUSTABILITY',
  'CONSTRAINT DRILLS',
  'TIMING AND ADJUSTABILITY',
  'BASEBALL IQ'
];

export const trainingVideos = [
  {
    id: 'video-01',
    type: 'youtube',
    url: 'https://www.youtube.com/watch?v=quk5pjARILc',
    thumbnailUrl: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/Sean%20cover%20photo.jpg',
    title: 'Batting Technique Fundamentals',
    caption: 'Master the core batting mechanics and swing fundamentals used by elite players.',
    category: 'HITTING FUNDAMENTALS',
    youtubeId: 'quk5pjARILc'
  },
  {
    id: 'video-02',
    type: 'mp4',
    url: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/brady%20trainingmp4.mp4',
    thumbnailUrl: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/Coach%20Steve%20demonstrating%20launch%20position%20with%20youth%20baseball%20player.PNG',
    title: 'Brady Training Session',
    caption: 'Focused training session highlighting specific drill progression and mechanics adjustments.',
    category: 'HITTING DRILL',
    youtubeId: null
  },
  {
    id: 'video-03',
    type: 'youtube',
    url: 'https://www.youtube.com/watch?v=k6PpEcDzND4',
    thumbnailUrl: 'https://img.youtube.com/vi/k6PpEcDzND4/maxresdefault.jpg',
    title: 'Hip Rotation Mechanics',
    caption: 'Learn how to properly engage your hips to generate explosive rotational power for baseball.',
    category: 'SWING MECHANICS',
    youtubeId: 'k6PpEcDzND4'
  },
  {
    id: 'video-04',
    type: 'mp4',
    url: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/WESLEY%20FINISHING%20UP%20AFTER%20A%20LONG%20SESSION%20AND%20SHOWING%20MENTAL%20TOUGHNESS.mp4',
    thumbnailUrl: 'https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/Wesley%20learning%20how%20to%20get%20the%20correct%20launch%20position.jpg',
    title: 'Finish Strong: Mental Toughness',
    caption: 'Witness Wesley demonstrating exceptional mental toughness and determination, pushing through to finish strong after a demanding training session.',
    category: 'TRAINING',
    youtubeId: null
  },
  {
    id: 'video-05',
    type: 'youtube',
    url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    thumbnailUrl: 'https://img.youtube.com/vi/dQw4w9WgXcQ/maxresdefault.jpg',
    title: 'Launch Position Mastery',
    caption: 'Perfect your launch position to maximize power and consistency in your swing.',
    category: 'HITTING FUNDAMENTALS',
    youtubeId: 'dQw4w9WgXcQ'
  },
  {
    id: 'video-06',
    type: 'youtube',
    url: 'https://www.youtube.com/watch?v=oHg5SJYRHA0',
    thumbnailUrl: 'https://img.youtube.com/vi/oHg5SJYRHA0/maxresdefault.jpg',
    title: 'Timing Drills for Better Contact',
    caption: 'Develop precise timing to consistently square up fastballs and breaking pitches.',
    category: 'TIMING AND ADJUSTABILITY',
    youtubeId: 'oHg5SJYRHA0'
  },
  {
    id: 'video-07',
    type: 'youtube',
    url: 'https://www.youtube.com/watch?v=9bZkp7q19f0',
    thumbnailUrl: 'https://img.youtube.com/vi/9bZkp7q19f0/maxresdefault.jpg',
    title: 'Adjustability to Different Pitch Locations',
    caption: 'Learn to adjust your swing path to handle inside, outside, high, and low pitches.',
    category: 'ADJUSTABILITY',
    youtubeId: '9bZkp7q19f0'
  },
  {
    id: 'video-08',
    type: 'youtube',
    url: 'https://www.youtube.com/watch?v=kJQP7kiw5Fk',
    thumbnailUrl: 'https://img.youtube.com/vi/kJQP7kiw5Fk/maxresdefault.jpg',
    title: 'Constraint Training for Power Development',
    caption: 'Use constraint-based drills to unlock explosive bat speed and rotational power.',
    category: 'CONSTRAINT DRILLS',
    youtubeId: 'kJQP7kiw5Fk'
  },
  {
    id: 'video-09',
    type: 'youtube',
    url: 'https://www.youtube.com/watch?v=lXMskKTw3Bc',
    thumbnailUrl: 'https://img.youtube.com/vi/lXMskKTw3Bc/maxresdefault.jpg',
    title: 'Reading Pitch Types: Baseball IQ',
    caption: 'Develop elite pitch recognition skills to anticipate and react faster at the plate.',
    category: 'BASEBALL IQ',
    youtubeId: 'lXMskKTw3Bc'
  },
  {
    id: 'video-10',
    type: 'youtube',
    url: 'https://www.youtube.com/watch?v=jNQXAC9IVRw',
    thumbnailUrl: 'https://img.youtube.com/vi/jNQXAC9IVRw/maxresdefault.jpg',
    title: 'Advanced Swing Path Mechanics',
    caption: 'Optimize your swing path for maximum barrel control and hard contact.',
    category: 'SWING MECHANICS',
    youtubeId: 'jNQXAC9IVRw'
  },
  {
    id: 'video-11',
    type: 'youtube',
    url: 'https://www.youtube.com/watch?v=y6120QOlsfU',
    thumbnailUrl: 'https://img.youtube.com/vi/y6120QOlsfU/maxresdefault.jpg',
    title: 'Tee Work Progression Drills',
    caption: 'Essential tee work drills to build muscle memory and perfect your swing mechanics.',
    category: 'HITTING DRILL',
    youtubeId: 'y6120QOlsfU'
  },
  {
    id: 'video-12',
    type: 'youtube',
    url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    thumbnailUrl: 'https://img.youtube.com/vi/dQw4w9WgXcQ/maxresdefault.jpg',
    title: 'One-Handed Constraint Drill',
    caption: 'Isolate and strengthen specific swing mechanics using one-handed hitting drills.',
    category: 'CONSTRAINT DRILLS',
    youtubeId: 'dQw4w9WgXcQ'
  },
  {
    id: 'video-13',
    type: 'youtube',
    url: 'https://www.youtube.com/watch?v=kXYiU_JCYtU',
    thumbnailUrl: 'https://img.youtube.com/vi/kXYiU_JCYtU/maxresdefault.jpg',
    title: 'In-Game Approach and Situational Hitting',
    caption: 'Master the mental approach and situational awareness needed for game-time success.',
    category: 'BASEBALL IQ',
    youtubeId: 'kXYiU_JCYtU'
  },
  {
    id: 'video-14',
    type: 'youtube',
    url: 'https://www.youtube.com/watch?v=ZZ5LpwO-An4',
    thumbnailUrl: 'https://img.youtube.com/vi/ZZ5LpwO-An4/maxresdefault.jpg',
    title: 'Two-Strike Approach Adjustments',
    caption: 'Learn how to adjust your approach and mechanics with two strikes to battle and compete.',
    category: 'TIMING AND ADJUSTABILITY',
    youtubeId: 'ZZ5LpwO-An4'
  },
  {
    id: 'video-15',
    type: 'youtube',
    url: 'https://www.youtube.com/watch?v=fC7oUOUEEi4',
    thumbnailUrl: 'https://img.youtube.com/vi/fC7oUOUEEi4/maxresdefault.jpg',
    title: 'Full Training Session Breakdown',
    caption: 'Complete breakdown of a comprehensive training session from warm-up to game-speed reps.',
    category: 'TRAINING',
    youtubeId: 'fC7oUOUEEi4'
  }
];