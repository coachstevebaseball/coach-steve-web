import React from 'react';
import { Helmet } from 'react-helmet-async';
import Hero from '@/components/home/Hero';
import CredibilityBadges from '@/components/home/CredibilityBadges';
import EliteLeagues from '@/components/home/EliteLeagues';
import MLBStars from '@/components/home/MLBStars';
import ResultsSection from '@/components/landing/ResultsSection';
import MeetCoachSection from '@/components/landing/MeetCoachSection';
import CwsMomentsSection from '@/components/home/CwsMomentsSection';
import CoachingPhilosophy from '@/components/home/CoachingPhilosophy';
import Footer from '@/components/Footer';

const Home = () => {
  const schemaData = {
    "@context": "https://schema.org",
    "@type": "ProfessionalService",
    "name": "Coach Steve Baseball",
    "image": "https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/stonybrook-swing.png",
    "description": "Expert baseball hitting instruction on Long Island. Personalized coaching for youth and elite players. Improve your swing with proven techniques.",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "Common Sense Baseball",
      "addressLocality": "Westbury",
      "addressRegion": "NY",
      "postalCode": "11590",
      "addressCountry": "US"
    },
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": "40.755655",
      "longitude": "-73.587624"
    },
    "url": "https://coachstevebaseball.com",
    "telephone": "+15165550123",
    "priceRange": "$$",
    "openingHoursSpecification": [
      {
        "@type": "OpeningHoursSpecification",
        "dayOfWeek": [
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday",
          "Sunday"
        ],
        "opens": "09:00",
        "closes": "21:00"
      }
    ]
  };

  return (
    <>
      <Helmet>
        <title>Coach Steve Baseball | Elite Hitting Instructor Long Island, NY</title>
        <meta name="description" content="Expert baseball hitting instruction on Long Island, NY. D1 All-American, 2012 College World Series. Private lessons for youth & travel ball players." />
        <link rel="canonical" href="https://www.coachstevebaseball.com/" />
        
        {/* Open Graph tags */}
        <meta property="og:site_name" content="Coach Steve Baseball" />
        <meta property="og:locale" content="en_US" />
        <meta property="og:title" content="Coach Steve Baseball | Elite Hitting Instructor Long Island" />
        <meta property="og:description" content="D1 All-American & 2012 CWS player. Private hitting lessons for youth & travel ball on Long Island, NY." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.coachstevebaseball.com/" />
        <meta property="og:image" content="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/stonybrook-swing.png" />
        <meta property="og:image:alt" content="Coach Steve Baseball Training" />
        
        {/* Twitter Card tags */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Coach Steve Baseball | Elite Hitting Instructor Long Island" />
        <meta name="twitter:description" content="D1 All-American & 2012 CWS player. Private hitting lessons for youth & travel ball on Long Island, NY." />
        
        <script type="application/ld+json">
          {JSON.stringify(schemaData)}
        </script>
      </Helmet>
      
      <div className="min-h-screen bg-navy-950 text-foreground font-sans">
        <Hero />
        <MeetCoachSection />
        <CredibilityBadges />
        <CwsMomentsSection />
        <CoachingPhilosophy />
        <EliteLeagues />
        <MLBStars />
        <ResultsSection />
        <Footer />
      </div>
    </>
  );
};

export default Home;