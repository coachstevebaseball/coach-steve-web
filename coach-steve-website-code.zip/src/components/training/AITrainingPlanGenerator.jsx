import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Loader2, ArrowRight, RefreshCw, AlertCircle, CheckCircle2 } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { supabase } from '@/lib/customSupabaseClient';
import { cn } from '@/lib/utils';
import { useToast } from '@/components/ui/use-toast';

const AITrainingPlanGenerator = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState('');
  const [plan, setPlan] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  const [debugInfo, setDebugInfo] = useState(null);
  
  const [formData, setFormData] = useState({
    age: '',
    position: 'Hitter',
    goal: '',
    struggle: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    // Clear error when user starts typing again
    if (errorMsg) setErrorMsg(null);
  };

  const handleSubmit = async (e) => {
    if (e) e.preventDefault();
    
    // Validation
    if (!formData.age || !formData.goal || !formData.struggle) {
      toast({
        variant: "destructive",
        title: "Missing Information",
        description: "Please fill in all fields so Coach Steve can build your plan.",
      });
      return;
    }

    setLoading(true);
    setLoadingMsg("Connecting to AI Coach...");
    setPlan(null);
    setErrorMsg(null);
    setDebugInfo(null);

    console.log("Submitting form data:", formData);

    try {
      setLoadingMsg("Analyzing your swing mechanics...");
      
      // Invoke Supabase Edge Function
      const { data, error } = await supabase.functions.invoke('generate-training-plan', {
        body: formData, 
      });

      console.log("Edge Function Complete Response:", { data, error });

      // 1. Network/Supabase Invocation Errors
      if (error) {
        console.error("Supabase Invocation Error:", error);
        let niceMessage = "Connection failed. Please check your internet.";
        
        // Check for specific function missing error
        if (error.message?.includes('Function not found')) {
          niceMessage = "AI Service is currently offline (Function not deployed).";
        } else if (error instanceof Error) {
          niceMessage = error.message;
        }

        setDebugInfo(JSON.stringify(error, null, 2));
        throw new Error(niceMessage);
      }

      // 2. Logic Errors returned by the function itself
      if (!data) {
        throw new Error("No response received from the AI coach.");
      }

      // Check for 'success: false' pattern
      if (data.success === false) {
        setDebugInfo(data.error); // Show the specific technical error in debug
        // If it's an API key error, show a friendly message
        if (data.error?.includes('API Key') || data.error?.includes('403')) {
           throw new Error("Coach Steve is taking a quick break (Configuration Error). Please try again later.");
        }
        throw new Error(data.error || "The AI coach encountered an issue.");
      }

      // 3. Data Integrity Check
      // Note: We look for 'trainingPlan' as per updated Edge Function specs, 
      // but check 'plan' for backwards compatibility if needed
      const resultPlan = data.trainingPlan || data.plan;

      if (!resultPlan) {
        setDebugInfo(JSON.stringify(data, null, 2));
        throw new Error("Received an empty plan from the AI.");
      }

      // Success
      setPlan(resultPlan);
      toast({
        title: "Plan Ready!",
        description: "Coach Steve has analyzed your data.",
        action: <CheckCircle2 className="text-green-500 w-5 h-5" />
      });

    } catch (err) {
      console.error('Error in handleSubmit:', err);
      const message = err.message || "Something went wrong. Please try again.";
      setErrorMsg(message);
      toast({
        variant: "destructive",
        title: "Generation Failed",
        description: "Check the error message above for details.",
      });
    } finally {
      setLoading(false);
      setLoadingMsg('');
    }
  };

  const resetForm = () => {
    setPlan(null);
    setErrorMsg(null);
    setDebugInfo(null);
    setFormData({
      age: '',
      position: 'Hitter',
      goal: '',
      struggle: ''
    });
  };

  const retry = () => {
    handleSubmit(null);
  };

  const inputClasses = "w-full bg-[#0f192b] border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-[#C9A961] focus:ring-1 focus:ring-[#C9A961] transition-all min-h-[44px]";
  const labelClasses = "block text-sm font-bold text-[#C9A961] mb-2 uppercase tracking-wider";

  return (
    <section className="py-20 bg-[#0A1628] relative overflow-hidden" id="ai-training-plan">
      {/* Background Accents */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#C9A961]/5 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-blue-500/5 rounded-full blur-[80px] pointer-events-none" />

      <div className="container mx-auto px-4 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto"
        >
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 bg-[#112240] border border-[#C9A961]/30 px-4 py-1.5 rounded-full mb-4">
              <Sparkles className="w-4 h-4 text-[#C9A961]" />
              <span className="text-[#C9A961] text-xs font-bold tracking-[0.2em] uppercase">AI Assistant</span>
            </div>
            <h2 className="font-montserrat font-black text-3xl sm:text-4xl md:text-5xl text-white mb-4">
              GET A CUSTOM <span className="text-[#C9A961]">TRAINING PLAN</span>
            </h2>
            <p className="text-gray-300 text-lg max-w-2xl mx-auto font-light">
              Tell Coach Steve about your game, and get an instant, personalized breakdown of drills and mental cues to fix your specific struggle.
            </p>
          </div>

          <div className="bg-[#112240] rounded-2xl border border-gray-800 shadow-2xl overflow-hidden relative">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-[#C9A961] to-[#b5952f]" />
            
            <div className="p-6 md:p-10">
              <AnimatePresence mode="wait">
                {/* Error State Display */}
                {errorMsg && !plan && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mb-6 bg-red-900/20 border border-red-900/50 rounded-lg p-4"
                  >
                    <div className="flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />
                      <div className="flex-1">
                        <h4 className="text-red-500 font-bold text-sm">Error Generating Plan</h4>
                        <p className="text-red-400 text-sm mt-1">{errorMsg}</p>
                        {debugInfo && (
                          <details className="mt-2 text-xs text-red-400/70 font-mono cursor-pointer">
                            <summary>Technical Details</summary>
                            <pre className="mt-1 p-2 bg-black/30 rounded whitespace-pre-wrap">{debugInfo}</pre>
                          </details>
                        )}
                        <button 
                          onClick={retry}
                          className="mt-3 text-xs bg-red-800/50 hover:bg-red-800 text-white px-3 py-1.5 rounded transition-colors flex items-center gap-1 font-bold uppercase tracking-wide"
                        >
                          <RefreshCw className="w-3 h-3" /> Try Again
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}

                {!plan ? (
                  <motion.form 
                    key="form"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    onSubmit={handleSubmit} 
                    className="space-y-6"
                  >
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <label className={labelClasses}>Player Age</label>
                        <input 
                          type="number" 
                          name="age" 
                          required 
                          value={formData.age} 
                          onChange={handleChange} 
                          className={inputClasses} 
                          placeholder="e.g. 15" 
                          min="5"
                          max="99"
                        />
                      </div>
                      <div>
                        <label className={labelClasses}>Position</label>
                        <select 
                          name="position" 
                          value={formData.position} 
                          onChange={handleChange} 
                          className={inputClasses}
                        >
                          <option value="Hitter">Hitter</option>
                          <option value="Pitcher">Pitcher</option>
                          <option value="Catcher">Catcher</option>
                          <option value="Infield">Infield</option>
                          <option value="Outfield">Outfield</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className={labelClasses}>Primary Goal</label>
                      <input 
                        type="text" 
                        name="goal" 
                        required 
                        value={formData.goal} 
                        onChange={handleChange} 
                        className={inputClasses} 
                        placeholder="e.g. Hit for more power, Stop striking out, Throw harder" 
                      />
                    </div>

                    <div>
                      <label className={labelClasses}>Current Struggle</label>
                      <textarea 
                        name="struggle" 
                        required 
                        rows="4" 
                        value={formData.struggle} 
                        onChange={handleChange} 
                        className={inputClasses} 
                        placeholder="e.g. I keep rolling over on outside pitches, or I get nervous with runners in scoring position..." 
                      />
                    </div>

                    <div className="pt-2">
                      <button 
                        type="submit" 
                        disabled={loading}
                        className={cn(
                          "w-full bg-gradient-to-r from-[#C9A961] to-[#b5952f] text-[#0A1628] font-black text-lg py-4 rounded-lg shadow-lg hover:shadow-[#C9A961]/20 hover:scale-[1.01] transition-all flex items-center justify-center gap-2 uppercase tracking-wider min-h-[50px]",
                          loading && "opacity-70 cursor-wait"
                        )}
                      >
                        {loading ? (
                          <div className="flex items-center gap-2">
                            <Loader2 className="animate-spin w-5 h-5" />
                            <span>{loadingMsg || "Processing..."}</span>
                          </div>
                        ) : (
                          <>
                            <span>Generate Plan</span>
                            <ArrowRight className="w-5 h-5" />
                          </>
                        )}
                      </button>
                    </div>
                  </motion.form>
                ) : (
                  <motion.div
                    key="result"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-6"
                  >
                    <div className="flex items-center justify-between border-b border-gray-700 pb-4 mb-4">
                      <h3 className="text-2xl font-black text-white italic">COACH STEVE'S GAMEPLAN</h3>
                      <button 
                        onClick={resetForm}
                        className="text-gray-400 hover:text-[#C9A961] transition-colors flex items-center gap-2 text-sm font-bold uppercase tracking-wide"
                      >
                        <RefreshCw className="w-4 h-4" /> New Plan
                      </button>
                    </div>
                    
                    <div className="prose prose-invert max-w-none prose-p:text-gray-300 prose-headings:text-[#C9A961] prose-strong:text-white prose-li:text-gray-300">
                      <ReactMarkdown>{plan}</ReactMarkdown>
                    </div>

                    <div className="mt-8 pt-6 border-t border-gray-700 bg-[#0f192b]/50 -mx-6 -mb-6 p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
                      <p className="text-sm text-gray-400 font-medium">Need more help? Let's work on this in person.</p>
                      <a 
                        href="https://calendly.com/coachstevengoldstein/free-inital-1-hour-session"
                        target="_blank"
                        rel="noopener noreferrer" 
                        className="bg-[#C9A961] text-[#0A1628] font-bold px-6 py-3 rounded hover:bg-white transition-colors uppercase text-sm tracking-wider w-full sm:w-auto text-center"
                      >
                        Book a Lesson
                      </a>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default AITrainingPlanGenerator;