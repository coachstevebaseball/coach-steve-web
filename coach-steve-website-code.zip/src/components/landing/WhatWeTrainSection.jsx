import React from 'react';
import { motion } from 'framer-motion';
import { Zap, Activity, Target, TrendingUp, ArrowUpRight } from 'lucide-react';

const WhatWeTrainSection = () => {
  const cards = [
    {
      title: "Stance & Setup",
      icon: <Zap className="w-8 h-8" />,
      desc: "Goal: Create a consistent, athletic starting position",
      color: "from-[#d4af37] to-[#b5952f]"
    },
    {
      title: "Load & Timing",
      icon: <TrendingUp className="w-8 h-8" />,
      desc: "Goal: Stay in rhythm with the pitcher",
      color: "from-[#4FC3F7] to-[#2196F3]"
    },
    {
      title: "Swing Path & Barrel Control",
      icon: <Activity className="w-8 h-8" />,
      desc: "Goal: Level, efficient path with adjustability.",
      color: "from-[#ff6b6b] to-[#ee5253]"
    },
    {
      title: "Intent and Approach",
      icon: <Target className="w-8 h-8" />,
      desc: "Goal: Hunt the pitch you want + swing with purpose.",
      color: "from-[#a8e6cf] to-[#1dd1a1]"
    }
  ];

  return (
    <section className="py-24 bg-[#0a0e12] relative overflow-hidden">
      {/* Background Grid */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px] [mask-image:radial-gradient(ellipse_60%_60%_at_50%_50%,black,transparent)] pointer-events-none"></div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 30 }} 
          whileInView={{ opacity: 1, y: 0 }} 
          viewport={{ once: true }} 
          className="text-center mb-20"
        >
          <span className="text-[#d4af37] font-bold tracking-widest text-sm uppercase mb-3 block">BECOMING A COMPLETE HITTER</span>
          <h2 className="font-montserrat font-black text-4xl sm:text-6xl text-white mb-6">
            WHAT WE <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#d4af37] to-[#fff]">WORK ON</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">Mechanics + IQ = Complete Players</p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
          {cards.map((card, index) => (
            <motion.div 
              key={index} 
              initial={{ opacity: 0, y: 30 }} 
              whileInView={{ opacity: 1, y: 0 }} 
              viewport={{ once: true }} 
              transition={{ delay: index * 0.1 }} 
              whileHover={{ y: -10 }} 
              className="group relative bg-[#0f1419] p-8 rounded-2xl border border-gray-800 overflow-hidden hover:border-[#d4af37]/50 transition-all duration-300"
            >
              {/* Background Gradient on Hover */}
              <div className={`absolute inset-0 bg-gradient-to-br ${card.color} opacity-0 group-hover:opacity-5 transition-opacity duration-500`}></div>
              
              {/* Animated Bottom Line */}
              <div className="absolute bottom-0 left-0 h-1 bg-[#d4af37] w-0 group-hover:w-full transition-all duration-500 ease-out"></div>

              {/* Icon */}
              <div className="mb-6 relative">
                <div className="w-16 h-16 rounded-2xl bg-[#1a1f26] flex items-center justify-center group-hover:scale-110 transition-transform duration-300 border border-gray-800 group-hover:border-[#d4af37]/30">
                  <div className="text-white group-hover:text-[#d4af37] transition-colors">
                    {card.icon}
                  </div>
                </div>
              </div>

              {/* Content */}
              <h3 className="font-montserrat font-bold text-2xl text-white mb-3 group-hover:text-[#d4af37] transition-colors">{card.title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed group-hover:text-gray-300 transition-colors">
                {card.desc}
              </p>

              {/* Hover Arrow */}
              <div className="absolute top-6 right-6 opacity-0 group-hover:opacity-100 transform translate-x-4 group-hover:translate-x-0 transition-all duration-300">
                <ArrowUpRight className="text-[#d4af37]" size={20} />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
export default WhatWeTrainSection;