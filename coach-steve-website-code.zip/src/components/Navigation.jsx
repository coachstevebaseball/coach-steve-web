import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, LogOut } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAdminAuth } from '@/contexts/AdminAuthContext.jsx';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

const Navigation = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { isAuthenticated: isAdminAuthenticated } = useAdminAuth();
  const { isAuthenticated, signOut, currentUser } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isMobileMenuOpen]);

  const handleSignOut = async () => {
    try {
      await signOut();
      toast({
        title: "Signed Out",
        description: "You have been successfully signed out.",
      });
      navigate('/');
    } catch (error) {
      console.error('Sign out error:', error);
      toast({
        title: "Sign Out Failed",
        description: "Unable to sign out. Please try again.",
        variant: "destructive"
      });
    }
  };

  const navLinks = [
    { to: '/', label: 'HOME' },
    { to: '/about', label: 'ABOUT' },
    { to: '/training', label: 'TRAINING' },
    { to: '/hitters-lab', label: 'HITTERS LAB' },
    { to: '/assessment', label: 'ASSESSMENT' },
    { to: '/coach-steve-highlights', label: 'HIGHLIGHTS' },
    { to: '/videos', label: 'VIDEOS' },
    { to: '/blog', label: 'BLOG' },
    { to: '/testimonials', label: 'TESTIMONIALS' },
  ];

  if (isAdminAuthenticated) {
    navLinks.push({ to: '/admin/videos', label: 'ADMIN VIDEOS' });
    navLinks.push({ to: '/admin/appointments', label: 'ADMIN APPOINTMENTS' });
  }

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={cn(
        'fixed top-0 left-0 right-0 z-[100] transition-all duration-300 border-b',
        isScrolled 
          ? 'bg-navy-950/95 backdrop-blur-md shadow-xl border-red-500/10' 
          : 'bg-navy-950/80 md:bg-transparent border-transparent md:backdrop-blur-sm'
      )}
    >
      <div className="container mx-auto px-4 md:px-6 py-3 md:py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 group min-h-[44px]">
            <div className="w-10 h-10 md:w-12 md:h-12 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform border border-red-400/30">
              <span className="text-white font-black text-lg md:text-xl">CS</span>
            </div>
            <div className="flex flex-col">
              <span className="text-white font-black text-base md:text-lg tracking-tight leading-none group-hover:text-red-500 transition-colors">COACH STEVE</span>
              <span className="text-red-500 text-[10px] md:text-xs font-bold tracking-wider">BASEBALL</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden xl:flex items-center gap-4 2xl:gap-6">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className={cn(
                  'font-bold text-xs tracking-widest transition-all duration-300 hover:text-red-500 relative py-2 uppercase min-h-[44px] flex items-center',
                  location.pathname === link.to ? 'text-red-500' : 'text-gray-300'
                )}
              >
                {link.label}
                {location.pathname === link.to && (
                  <motion.div
                    layoutId="activeNav"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-red-500"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  />
                )}
              </Link>
            ))}
            
            <Link
              to="/booking"
              className="px-6 py-2 bg-gradient-to-r from-red-500 to-red-600 text-white font-black text-xs xl:text-sm tracking-widest rounded hover:shadow-lg hover:shadow-red-500/20 hover:scale-105 transition-all duration-300 uppercase min-h-[44px] flex items-center justify-center whitespace-nowrap"
            >
              Book Now
            </Link>

            {/* Sign Out Button (Desktop) */}
            {isAuthenticated && (
              <button
                onClick={handleSignOut}
                className="px-4 py-2 border border-gray-600 text-gray-300 hover:border-red-500 hover:text-red-500 font-bold text-xs tracking-widest rounded transition-all duration-300 uppercase min-h-[44px] flex items-center gap-2"
                title={`Signed in as ${currentUser?.email}`}
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            )}
          </div>

          {/* Mobile Menu Toggle Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="xl:hidden text-white hover:bg-white/10 rounded-full transition-colors min-h-[48px] min-w-[48px] flex items-center justify-center touch-manipulation z-50 relative"
            aria-expanded={isMobileMenuOpen}
            aria-label="Toggle navigation menu"
          >
            {isMobileMenuOpen ? <X size={28} className="text-red-500" /> : <Menu size={28} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="xl:hidden fixed top-[70px] left-0 w-full h-[calc(100vh-70px)] bg-[#0a0d12] z-40 flex flex-col overflow-y-auto"
          >
            <div className="container mx-auto px-4 py-8 flex flex-col space-y-4">
              {navLinks.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={cn(
                    'block px-6 py-4 font-bold text-base tracking-widest transition-all rounded-xl uppercase min-h-[56px] flex items-center',
                    location.pathname === link.to 
                      ? 'bg-red-500/20 text-red-500 border-l-4 border-red-500' 
                      : 'text-white hover:bg-white/10 hover:text-red-500'
                  )}
                >
                  {link.label}
                </Link>
              ))}
              
              <div className="pt-6 mt-4 border-t border-gray-700 space-y-4">
                <Link
                  to="/booking"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block w-full px-6 py-5 font-black text-lg tracking-widest bg-gradient-to-r from-red-500 to-red-600 text-white text-center rounded-xl uppercase hover:shadow-lg transition-all min-h-[60px] flex items-center justify-center"
                >
                  Book Now
                </Link>

                {/* Sign Out Button (Mobile) */}
                {isAuthenticated && (
                  <button
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      handleSignOut();
                    }}
                    className="block w-full px-6 py-5 font-black text-lg tracking-widest border-2 border-gray-600 text-gray-300 text-center rounded-xl uppercase hover:border-red-500 hover:text-red-500 transition-all min-h-[60px] flex items-center justify-center gap-2"
                  >
                    <LogOut className="w-5 h-5" />
                    Sign Out
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
};

export default Navigation;