import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { ChevronRight, Target, ClipboardCheck, TrendingUp, Dumbbell, Shield, CalendarCheck } from 'lucide-react';

// Modals
import ProcessModal from '@/components/training-guides/ProcessModal';
import FirstSessionModal from '@/components/training-guides/FirstSessionModal';
import ProgressModal from '@/components/training-guides/ProgressModal';
import DrillsModal from '@/components/training-guides/DrillsModal';
import EquipmentModal from '@/components/training-guides/EquipmentModal';
import SeasonPrepModal from '@/components/training-guides/SeasonPrepModal';

const TrainingGuidesPage = () => {
  const [activeModal, setActiveModal] = useState(null);

  const closeModal = () => setActiveModal(null);

  const guides = [
    {
      id: 'process',
      title: 'Understanding the Training Process',
      description: 'Learn how Coach Steve breaks down the swing, builds foundation, and develops elite mechanics over time.',
      icon: <Target size={32} className="text-[#e4002b] mb-4" />
    },
    {
      id: 'first-session',
      title: 'Your First Session',
      description: 'Know exactly what to expect, what to bring, and how we establish your baseline metrics on day one.',
      icon: <ClipboardCheck size={32} className="text-[#e4002b] mb-4" />
    },
    {
      id: 'progress',
      title: 'How Progress is Measured',
      description: 'Discover the quantitative metrics and qualitative assessments we use to ensure your game translates.',
      icon: <TrendingUp size={32} className="text-[#e4002b] mb-4" />
    },
    {
      id: 'drills',
      title: 'Practice Drills for Home',
      description: 'Essential tee work, dry swings, and timing drills you can perform at home to accelerate your development.',
      icon: <Dumbbell size={32} className="text-[#e4002b] mb-4" />
    },
    {
      id: 'equipment',
      title: 'Equipment Recommendations',
      description: 'Coach Steve’s guide to essential and optional baseball gear, including budget considerations.',
      icon: <Shield size={32} className="text-[#e4002b] mb-4" />
    },
    {
      id: 'season-prep',
      title: 'Season Preparation Checklist',
      description: 'Interactive timeline checklist to ensure you are physically and mentally ready for opening day.',
      icon: <CalendarCheck size={32} className="text-[#e4002b] mb-4" />
    }
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white font-sans pt-[70px]">
      <Helmet>
        <title>Baseball Training Guides | Coach Steve Baseball</title>
        <meta name="description" content="Explore comprehensive training guides, session expectations, home drills, and season preparation checklists by Coach Steve." />
        <link rel="canonical" href="https://www.coachstevebaseball.com/training-guides" />
        <meta property="og:title" content="Baseball Training Guides | Coach Steve Baseball" />
        <meta property="og:url" content="https://www.coachstevebaseball.com/training-guides" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Baseball Training Guides | Coach Steve Baseball" />
        <meta property="og:image:alt" content="Baseball Training Guides" />
      </Helmet>

      {/* Header Banner */}
      <section className="bg-gradient-to-br from-[#0a0a0a] to-[#1a1a1a] border-b border-[#2a2a2a] relative overflow-hidden py-16 md:py-24">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#e4002b] rounded-full blur-[120px] opacity-10 pointer-events-none"></div>
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-black uppercase tracking-tight text-white mb-4">
            Training <span className="text-[#e4002b]">Guides</span>
          </h1>
          <p className="text-[#b0b0b0] text-lg md:text-xl max-w-2xl font-light">
            Everything you need to know about our training process, what to expect, and how to maximize your development on and off the field.
          </p>
        </div>
      </section>

      {/* Guides Grid */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {guides.map((guide) => (
              <div 
                key={guide.id}
                className="bg-[#111] border border-[#2a2a2a] hover:border-[#e4002b] rounded-xl p-8 transition-all duration-300 group flex flex-col h-full"
              >
                {guide.icon}
                <h3 className="text-xl font-bold uppercase tracking-wider mb-3 text-white group-hover:text-[#e4002b] transition-colors">
                  {guide.title}
                </h3>
                <p className="text-[#b0b0b0] text-sm mb-8 flex-grow">
                  {guide.description}
                </p>
                <button 
                  onClick={() => setActiveModal(guide.id)}
                  className="flex items-center text-[#e4002b] font-bold uppercase tracking-wider text-sm hover:text-white transition-colors mt-auto"
                >
                  Read Guide <ChevronRight size={18} className="ml-1 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-[#e4002b] relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="container mx-auto px-4 md:px-6 relative z-10 text-center">
          <h2 className="text-3xl md:text-4xl font-black uppercase tracking-tight text-white mb-6">
            Ready to Start the Process?
          </h2>
          <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">
            Now that you know what to expect, take the first step towards elite mechanics and in-game power.
          </p>
          <Link 
            to="/booking" 
            className="inline-flex items-center justify-center bg-white text-[#e4002b] font-black uppercase tracking-wider rounded-lg hover:scale-105 transition-transform duration-300 shadow-xl px-8 py-4"
          >
            Book Your First Session
          </Link>
        </div>
      </section>

      {/* Modals */}
      <ProcessModal isOpen={activeModal === 'process'} onClose={closeModal} />
      <FirstSessionModal isOpen={activeModal === 'first-session'} onClose={closeModal} />
      <ProgressModal isOpen={activeModal === 'progress'} onClose={closeModal} />
      <DrillsModal isOpen={activeModal === 'drills'} onClose={closeModal} />
      <EquipmentModal isOpen={activeModal === 'equipment'} onClose={closeModal} />
      <SeasonPrepModal isOpen={activeModal === 'season-prep'} onClose={closeModal} />
    </div>
  );
};

export default TrainingGuidesPage;