import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import bcrypt from 'bcryptjs';

const AdminAuthContext = createContext();

export const AdminAuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const storedUser = localStorage.getItem('adminUser');
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
      setIsAuthenticated(true);
    }
    setIsLoading(false);
  }, []);

  const login = async (email, password) => {
    try {
      setIsLoading(true);
      console.log(`[Admin Auth] Attempting login for email: ${email}`);

      // 1. Query admin_users table by email
      const { data, error } = await supabase
        .from('admin_users')
        .select('*')
        .eq('email', email)
        .single();

      if (error || !data) {
        console.warn('[Admin Auth] User not found or query error:', error?.message);
        throw new Error('Invalid email or password');
      }

      console.log('[Admin Auth] User found. Verifying password hash...');

      // 2. Use bcrypt to verify the provided password against stored hash
      const isValidPassword = await bcrypt.compare(password, data.password_hash);
      
      console.log(`[Admin Auth] Password comparison result: ${isValidPassword}`);

      if (!isValidPassword) {
        console.warn('[Admin Auth] Password mismatch');
        throw new Error('Invalid email or password');
      }

      // 4. Set auth state correctly on successful login
      console.log('[Admin Auth] Login successful. Setting auth state.');
      
      const userPayload = {
        id: data.id,
        email: data.email,
        created_at: data.created_at
      };

      setCurrentUser(userPayload);
      setIsAuthenticated(true);
      localStorage.setItem('adminUser', JSON.stringify(userPayload));
      
      return { success: true };
    } catch (error) {
      console.error('[Admin Auth] Login error:', error.message);
      return { success: false, error: error.message };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    console.log('[Admin Auth] Logging out user');
    setCurrentUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('adminUser');
  };

  return (
    <AdminAuthContext.Provider value={{ currentUser, isAuthenticated, login, logout, isLoading }}>
      {children}
    </AdminAuthContext.Provider>
  );
};

export const useAdminAuth = () => useContext(AdminAuthContext);