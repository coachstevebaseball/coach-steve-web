import React from 'react';
import { motion } from 'framer-motion';
import { Crosshair, Activity, BarChart3, Lock } from 'lucide-react';
import TextRevealAnimation from '@/components/TextRevealAnimation';

const CoachingPhilosophy = () => {
  const principles = [
    {
      icon: Crosshair,
      title: 'GAME-DAY FOCUSED',
      description: 'Every drill, every rep is designed to translate directly to game situations. No wasted time on techniques that don\'t work under pressure.'
    },
    {
      icon: Activity,
      title: 'PLAYER-CENTERED',
      description: 'Each athlete is unique. Training plans are personalized based on individual strengths, weaknesses, goals, and learning styles.'
    },
    {
      icon: BarChart3,
      title: 'MEASURABLE PROGRESS',
      description: 'Data-driven development with video analysis, performance metrics, and regular progress tracking to ensure continuous improvement.'
    },
    {
      icon: Lock,
      title: 'LONG-TERM SUCCESS',
      description: 'Building fundamentally sound athletes who can adapt and excel at every level, from youth ball to college and beyond.'
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-navy-900 to-navy-950 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-red-500/30 to-transparent"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl md:text-6xl font-black text-white mb-4 tracking-tighter">
            <TextRevealAnimation>
              THE COACHING <span className="text-red-500">PHILOSOPHY</span>
            </TextRevealAnimation>
          </h2>
          <div className="w-24 h-1.5 bg-gradient-to-r from-red-500 to-red-600 mx-auto mb-6 rounded-full"></div>
          <p className="text-lg sm:text-xl text-gray-300 max-w-3xl mx-auto font-light leading-relaxed">
            A proven approach built on elite experience and real results.
          </p>
        </motion.div>

        <div className="flex flex-col lg:flex-row items-center gap-12 max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="w-full lg:w-1/2 space-y-8"
          >
             <div className="relative rounded-2xl overflow-hidden border border-red-500/20 shadow-2xl bg-navy-950 group">
               <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-transparent to-transparent opacity-80 z-10"></div>
               <video 
                 src="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/_users_f01d1fdd-ee86-4372-bb2f-a2b2db4f4d3f_generated_fa89a2cb-4cd3-47e9-9220-6f801f99bb43_generated_video.mov" 
                 className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700 ease-out min-h-[400px]"
                 autoPlay
                 muted
                 loop
                 playsInline
               />
               
               <div className="absolute bottom-6 left-6 right-6 z-20">
                 <div className="bg-navy-900/90 backdrop-blur-md border border-red-500/30 p-6 rounded-xl shadow-lg transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                   <p className="text-red-500 font-black text-xs uppercase tracking-widest mb-2">MENTORSHIP</p>
                   <p className="text-white text-lg font-bold leading-tight italic">
                     "It's not just about the mechanics. It's about building the confidence to trust those mechanics when it matters most."
                   </p>
                 </div>
               </div>
             </div>

             {/* The second card's image element has been removed as requested */}
             
             <div className="absolute -z-10 top-6 -right-6 w-full h-full border-2 border-red-500/10 rounded-2xl hidden md:block"></div>
          </motion.div>

          <div className="w-full lg:w-1/2">
            <div className="grid gap-6">
              {principles.map((principle, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  whileHover={{ x: 5, backgroundColor: 'rgba(228, 0, 43, 0.05)' }}
                  className="bg-gradient-to-r from-navy-900 to-navy-950 border border-red-500/10 rounded-xl p-6 hover:border-red-500/50 transition-all duration-300 flex items-start gap-5 group shadow-lg"
                >
                  <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-red-600 rounded-lg flex items-center justify-center flex-shrink-0 shadow-lg group-hover:scale-110 transition-transform duration-300">
                    <principle.icon className="text-white" size={22} strokeWidth={2.5} />
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-white mb-2 tracking-tight group-hover:text-red-500 transition-colors uppercase">
                      {principle.title}
                    </h3>
                    <p className="text-gray-400 text-sm leading-relaxed font-medium">
                      {principle.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CoachingPhilosophy;