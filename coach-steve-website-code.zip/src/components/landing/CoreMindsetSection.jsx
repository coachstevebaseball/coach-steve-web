import React from 'react';
import { motion } from 'framer-motion';

const CoreMindsetSection = () => {
  const mindsets = [
    "Train like the game.",
    "Win the pitch.",
    "Quality at-bats matter.",
    "Preparation beats talent.",
    "Good players react. Great players anticipate.",
    "Every rep has a purpose."
  ];

  return (
    <section className="py-24 bg-[#0f1419] relative overflow-hidden">
      {/* Background Diamond Pattern */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] border border-[#d4af37]/5 rotate-45 pointer-events-none"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] border border-[#d4af37]/5 rotate-45 pointer-events-none"></div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <h2 className="font-montserrat font-black text-4xl sm:text-6xl text-white mb-6">
            HOW GREAT PLAYERS <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#d4af37] to-[#f3e5ab]">THINK</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">Championships are won in the mind before they are won on the field.</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-10 max-w-5xl mx-auto">
          {mindsets.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              className="group flex flex-col justify-center"
            >
              <h3 className="font-montserrat font-black text-3xl md:text-4xl text-white/90 group-hover:text-white transition-colors leading-tight mb-4">
                {item}
              </h3>
              <div className="h-1 w-0 bg-[#d4af37] group-hover:w-24 transition-all duration-500 ease-out rounded-full"></div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CoreMindsetSection;