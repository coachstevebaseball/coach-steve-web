import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { Plus, Edit2, Trash2, RefreshCcw, LogOut, Video } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { useAdminAuth } from '@/contexts/AdminAuthContext';
import AddVideoModal from '@/components/admin/AddVideoModal';
import EditVideoModal from '@/components/admin/EditVideoModal';
import DeleteVideoConfirmation from '@/components/admin/DeleteVideoConfirmation';
import { useToast } from '@/hooks/use-toast';

const AdminVideosPage = () => {
  const { logout, currentUser } = useAdminAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [videos, setVideos] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // Modal States
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [selectedVideo, setSelectedVideo] = useState(null);

  const fetchVideos = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase
        .from('training_videos')
        .select('*')
        .order('sort_order', { ascending: true, nullsFirst: false })
        .order('created_at', { ascending: false });

      if (error) throw error;
      setVideos(data || []);
    } catch (err) {
      console.error('Error fetching videos:', err);
      setError(err.message);
      toast({
        title: "Error fetching videos",
        description: err.message,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchVideos();
  }, []);

  const handleEditClick = (video) => {
    setSelectedVideo(video);
    setIsEditOpen(true);
  };

  const handleDeleteClick = (video) => {
    setSelectedVideo(video);
    setIsDeleteOpen(true);
  };

  const handleModalSuccess = () => {
    setIsAddOpen(false);
    setIsEditOpen(false);
    setIsDeleteOpen(false);
    setSelectedVideo(null);
    fetchVideos();
  };

  const handleLogout = () => {
    logout();
    navigate('/admin/login');
  };

  return (
    <>
      <Helmet>
        <title>Manage Videos - Admin - Coach Steve</title>
        <meta name="robots" content="noindex, nofollow" />
      </Helmet>

      <div className="min-h-screen bg-[#0A1628] pt-24 pb-16">
        <div className="container mx-auto px-4 max-w-7xl">
          
          {/* Header & Actions */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 bg-white/5 p-6 rounded-xl border border-white/10 shadow-lg">
            <div>
              <h1 className="text-3xl font-black text-white flex items-center gap-3">
                <Video className="w-8 h-8 text-[#EF4444]" />
                Video Management
              </h1>
              <p className="text-gray-400 mt-2">
                Logged in as <span className="text-white font-semibold">{currentUser?.email || 'Admin'}</span>
              </p>
            </div>
            
            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsAddOpen(true)}
                className="inline-flex items-center gap-2 px-6 py-3 bg-white text-[#0A1628] font-black text-lg rounded-lg hover:bg-gray-200 transition-colors"
              >
                <Plus className="w-6 h-6 stroke-[3px]" />
                Add New Video
              </button>
              <button
                onClick={handleLogout}
                className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#EF4444] text-white font-bold rounded-lg hover:bg-[#DC2626] transition-colors shadow-lg shadow-[#EF4444]/20"
                title="Logout"
              >
                <LogOut className="w-5 h-5" />
                Logout
              </button>
            </div>
          </div>

          {/* Video Grid Content */}
          <div className="min-h-[400px]">
            {isLoading ? (
              <div className="p-12 text-center bg-white/5 rounded-xl border border-white/10">
                <div className="w-12 h-12 border-4 border-[#EF4444] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-gray-400 text-lg font-bold">Loading your videos...</p>
              </div>
            ) : error ? (
              <div className="p-12 text-center bg-white/5 rounded-xl border border-red-900/30">
                <p className="text-red-400 mb-4 font-bold">{error}</p>
                <button
                  onClick={fetchVideos}
                  className="inline-flex items-center gap-2 px-6 py-2 bg-white/10 text-white font-bold rounded-lg hover:bg-white/20 transition-colors"
                >
                  <RefreshCcw className="w-5 h-5" />
                  Try Again
                </button>
              </div>
            ) : videos.length === 0 ? (
              <div className="p-16 text-center bg-white/5 rounded-xl border border-white/10 flex flex-col items-center justify-center">
                <Video className="w-16 h-16 text-gray-600 mb-4" />
                <h3 className="text-2xl font-black text-white mb-2">No Videos Found</h3>
                <p className="text-gray-400 mb-8 max-w-md mx-auto">You haven't uploaded any training videos yet. Start building your gallery to help your players train better.</p>
                <button
                  onClick={() => setIsAddOpen(true)}
                  className="inline-flex items-center gap-2 px-8 py-3 bg-[#EF4444] text-white font-black text-lg rounded-lg hover:bg-[#DC2626] transition-colors shadow-lg shadow-[#EF4444]/20"
                >
                  <Plus className="w-6 h-6 stroke-[3px]" />
                  Add Your First Video
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {videos.map((video) => (
                  <div key={video.id} className="bg-white/5 rounded-xl border border-white/10 overflow-hidden shadow-lg flex flex-col hover:border-white/20 transition-colors group">
                    {/* Thumbnail */}
                    <div className="relative aspect-video bg-[#0A1628] w-full overflow-hidden border-b border-white/10">
                      <img 
                        src={video.thumbnail || 'https://placehold.co/640x360/1c2128/ffffff?text=No+Thumbnail'} 
                        alt={video.title} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        onError={(e) => e.target.src = 'https://placehold.co/640x360/1c2128/ffffff?text=No+Thumbnail'}
                      />
                      <div className="absolute top-2 right-2 px-2 py-1 bg-[#0A1628]/80 backdrop-blur-sm border border-white/10 text-white text-[10px] font-black rounded uppercase tracking-wider">
                        {video.category || 'TRAINING'}
                      </div>
                    </div>
                    
                    {/* Content */}
                    <div className="p-5 flex-grow flex flex-col">
                      <h3 className="text-lg font-bold text-white mb-2 line-clamp-2 leading-tight transition-colors" title={video.title}>
                        {video.title}
                      </h3>
                      <p className="text-sm text-gray-400 line-clamp-2 mb-4 flex-grow" title={video.description}>
                        {video.description || 'No description provided.'}
                      </p>
                      
                      {/* Action Buttons */}
                      <div className="flex items-center gap-3 mt-auto pt-4 border-t border-white/10">
                        <button
                          onClick={() => handleEditClick(video)}
                          className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 bg-white/10 hover:bg-white/20 text-white font-bold text-sm rounded-lg transition-colors border border-transparent"
                        >
                          <Edit2 className="w-4 h-4" />
                          Edit
                        </button>
                        <button
                          onClick={() => handleDeleteClick(video)}
                          className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 bg-[#EF4444]/10 hover:bg-[#EF4444]/20 text-[#EF4444] font-bold text-sm rounded-lg transition-colors border border-transparent hover:border-[#EF4444]/50"
                        >
                          <Trash2 className="w-4 h-4" />
                          Delete
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <AddVideoModal 
        isOpen={isAddOpen} 
        onClose={() => setIsAddOpen(false)} 
        onSuccess={handleModalSuccess} 
      />
      
      <EditVideoModal 
        isOpen={isEditOpen} 
        onClose={() => setIsEditOpen(false)} 
        onSuccess={handleModalSuccess}
        video={selectedVideo} 
      />
      
      <DeleteVideoConfirmation 
        isOpen={isDeleteOpen} 
        onClose={() => setIsDeleteOpen(false)} 
        onSuccess={handleModalSuccess}
        video={selectedVideo} 
      />
    </>
  );
};

export default AdminVideosPage;