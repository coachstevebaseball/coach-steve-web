import React from 'react';
import { motion } from 'framer-motion';
import { Star, Award, Shield } from 'lucide-react';

const TestimonialCard = ({ testimonial, index, avatar, playerId }) => {
  const renderStars = (rating) => {
    return [...Array(5)].map((_, i) => (
      <Star
        key={i}
        size={18}
        className={i < rating ? 'text-red-500' : 'text-gray-600'}
        fill={i < rating ? '#e4002b' : 'none'}
      />
    ));
  };

  const getIcon = () => {
    const role = testimonial.role.toLowerCase();
    if (role.includes('parent')) return Shield;
    if (role.includes('player') || role.includes('commit')) return Award;
    return Star;
  };

  const Icon = getIcon();

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="bg-gradient-to-br from-navy-950 to-navy-900 border-2 border-red-500/30 rounded-xl p-8 shadow-lg hover:shadow-2xl hover:scale-105 transition-all duration-300 backdrop-blur-sm bg-opacity-90 relative overflow-hidden"
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex gap-1">
          {renderStars(testimonial.rating)}
        </div>
        <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-red-700 rounded-full flex items-center justify-center shadow-lg">
          <Icon className="text-white" size={24} />
        </div>
      </div>

      <div className="mb-6">
        <p className="text-gray-300 italic leading-relaxed text-lg">
          "{testimonial.content}"
        </p>
      </div>

      <div className="border-t border-blue-600/30 pt-6">
        <div className="flex flex-col items-start gap-4 mb-2">
          {avatar && (
            <img
              src={avatar}
              alt={testimonial.name}
              data-player-id={playerId}
              className="w-24 h-24 rounded-full object-cover border-2 border-red-500/50 shadow-lg"
            />
          )}
          <div>
            <p className="text-white font-black text-xl tracking-tight">{testimonial.name}</p>
            <p className="text-blue-600 font-bold text-base tracking-wide">{testimonial.role}</p>
          </div>
        </div>
      </div>

      <div className="absolute top-4 right-4 w-20 h-20 bg-red-500/5 rounded-full blur-2xl"></div>
    </motion.div>
  );
};

export default TestimonialCard;