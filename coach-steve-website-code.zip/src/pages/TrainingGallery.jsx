import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Camera, ArrowRight, Calendar } from 'lucide-react';
import Footer from '@/components/Footer';
import { galleryImages } from '@/data/galleryImages';

const TrainingGallery = () => {
  return (
    <>
      <Helmet>
        <title>Training Gallery | Coach Steve Baseball</title>
        <link rel="canonical" href="https://www.coachstevebaseball.com/training-gallery" />
        <meta property="og:title" content="Training Gallery | Coach Steve Baseball" />
        <meta property="og:url" content="https://www.coachstevebaseball.com/training-gallery" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Training Gallery | Coach Steve Baseball" />
        <meta property="og:image:alt" content="Baseball Training Gallery" />
      </Helmet>

      <div className="min-h-screen bg-navy-950 font-sans text-white">
        
        <div className="relative pt-32 pb-16 md:pt-40 md:pb-24 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-navy-900 to-navy-950 opacity-90"></div>
          
          <div className="container mx-auto px-4 relative z-10 text-center">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <div className="inline-flex items-center gap-2 bg-red-500/10 border border-red-500/20 text-red-500 px-4 py-1.5 rounded-full text-sm font-black tracking-wide mb-6 uppercase">
                <Camera size={16} />
                <span>In Action</span>
              </div>
              
              <h1 className="text-5xl md:text-7xl font-black tracking-tight mb-6 font-montserrat text-white">
                TRAINING <span className="text-red-500">GALLERY</span>
              </h1>
            </motion.div>
          </div>
        </div>

        <section className="py-12 bg-navy-950">
          <div className="container mx-auto px-4 md:px-8">
            {galleryImages.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {galleryImages.map((image, idx) => (
                  <motion.div
                    key={image.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.1, duration: 0.5 }}
                    className="group relative h-[400px] w-full rounded-xl overflow-hidden shadow-2xl border border-gray-800 hover:border-red-500/50 transition-all duration-500 cursor-pointer bg-navy-900"
                  >
                    <img src={image.url} alt={image.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-90 group-hover:opacity-100" />
                    <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-transparent to-transparent opacity-80" />
                    <div className="absolute bottom-0 left-0 right-0 p-6 flex flex-col justify-end">
                      <span className="inline-block text-red-500 text-xs font-black uppercase tracking-widest mb-2">{image.category}</span>
                      <h3 className="text-white font-bold tracking-tight">{image.title}</h3>
                    </div>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="text-center py-20 bg-navy-900 rounded-2xl border border-gray-800">
                <Camera className="w-16 h-16 text-gray-700 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-gray-400">No images available yet</h3>
              </div>
            )}
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default TrainingGallery;