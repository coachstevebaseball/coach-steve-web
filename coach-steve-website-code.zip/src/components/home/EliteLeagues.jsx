import React from 'react';
import { motion } from 'framer-motion';

const EliteLeagues = () => {
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: "spring", stiffness: 100, damping: 10 } }
  };

  const mainCards = [
    {
      id: 1,
      tag: "College World Series",
      title: "Beating LSU to reach Omaha",
      description: "Historic 2012 Run",
      image: "https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/Coach%20steve%20celebration%20team%20Omaha.jpeg",
      alt: "Coach Steve celebrating with team in Omaha"
    },
    {
      id: 2,
      tag: "Top Prospect Showcase",
      title: "Cape Cod League",
      description: "Premier Summer Ball",
      image: "https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/Coach%20Steve%20sliding%20into%20home%20plate%20for%20the%20Born%20Braves%20in%20the%20Cape%20Cod%20League..png",
      alt: "Coach Steve sliding into home plate"
    },
    {
      id: 3,
      tag: "Professional Development",
      title: "Northwoods League",
      description: "Elite Competition",
      image: "https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/Coach%20Steve%20playing%20in%20the%20Northwoods%20League..png",
      alt: "Coach Steve playing in Northwoods League"
    }
  ];

  return (
    <section className="py-12 md:py-20 bg-navy-950 relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-5"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={{
            hidden: { opacity: 0, y: 30 },
            visible: { opacity: 1, y: 0, transition: { duration: 0.6, staggerChildren: 0.1 } }
          }}
          className="text-center mb-10 md:mb-16"
        >
          <motion.h1 
            variants={itemVariants} 
            className="font-montserrat font-black text-3xl sm:text-5xl md:text-7xl lg:text-8xl text-white mb-4 md:mb-6 leading-none tracking-tight"
          >
            ELITE <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-red-300 to-red-500">
              EXPERIENCE
            </span>
          </motion.h1>
          <div className="w-16 md:w-24 h-1.5 bg-gradient-to-r from-red-500 to-red-600 mx-auto mb-6 md:mb-8 rounded-full"></div>
          <p className="text-base md:text-xl text-gray-300 max-w-3xl mx-auto font-light leading-relaxed px-4">
            From the College World Series to the premier summer leagues in the country.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 md:gap-8 max-w-7xl mx-auto mb-10 md:mb-16">
          {mainCards.map((card, index) => (
            <motion.div
              key={card.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              whileHover={{ y: -10 }}
              className="relative rounded-2xl overflow-hidden border border-red-500/20 shadow-2xl group h-[400px] md:h-[500px] bg-navy-900"
            >
              <img 
                src={card.image} 
                alt={card.alt} 
                className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700 ease-out"
                loading="lazy"
              />
              
              <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-navy-950/60 to-transparent opacity-90"></div>
              <div className="absolute inset-0 border-2 border-transparent group-hover:border-red-500/50 rounded-2xl transition-colors duration-300"></div>

              <div className="absolute bottom-6 md:bottom-8 left-6 md:left-8 right-6 md:right-8 z-10">
                <div className="inline-block bg-red-500 text-white text-[10px] font-black px-3 py-1.5 rounded uppercase tracking-widest mb-3 md:mb-4 shadow-lg min-h-[24px]">
                  {card.tag}
                </div>
                <h3 className="text-white font-black text-xl md:text-3xl leading-none drop-shadow-xl mb-3 uppercase">
                  {card.title}
                </h3>
                {card.description && (
                   <p className="text-red-300 text-xs md:text-sm font-bold tracking-wide uppercase border-l-2 border-red-500 pl-3">
                     {card.description}
                   </p>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default EliteLeagues;