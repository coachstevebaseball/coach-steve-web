import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Quote } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import TestimonialGrid from '@/components/testimonials/TestimonialGrid';
import Footer from '@/components/Footer';
import { useToast } from '@/components/ui/use-toast';
import TextRevealAnimation from '@/components/TextRevealAnimation';

const Testimonials = () => {
  const [testimonials, setTestimonials] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { toast } = useToast();

  const fetchTestimonials = useCallback(async (retryCount = 0) => {
    try {
      setLoading(true);
      setError(null);
      const { data, error: fetchError } = await supabase.from('testimonials').select('*').order('created_at', { ascending: false });
      if (fetchError) throw fetchError;
      setTestimonials(data || []);
    } catch (err) {
      setError(err.message || 'Failed to load testimonials.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchTestimonials(); }, [fetchTestimonials]);

  return (
    <>
      <Helmet>
        <title>Players & Parents Testimonials | Coach Steve Baseball Training Reviews</title>
        <meta name="description" content="Real reviews from Long Island baseball players and parents. See how Coach Steve's personalized hitting instruction improved bat speed, mechanics, and confidence." />
        <link rel="canonical" href="https://www.coachstevebaseball.com/testimonials" />
        <meta property="og:title" content="Players & Parents Testimonials | Coach Steve Baseball" />
        <meta property="og:description" content="Real reviews from Long Island players & parents. See how Coach Steve's hitting instruction transforms players." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.coachstevebaseball.com/testimonials" />
        <meta property="og:image" content="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/coach%20steve%20teaching%20hitting%20to%20youth%20baseball%20players.png" />
        <meta property="og:image:alt" content="Coach Steve teaching hitting" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Players & Parents Testimonials | Coach Steve Baseball" />
      </Helmet>

      <div className="min-h-screen bg-navy-950 text-white font-sans flex flex-col">
        <section className="relative min-h-[60vh] md:min-h-[80vh] flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 z-0">
            <img className="w-full h-full object-cover object-center" alt="Baseball team" src="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/coach%20steve%20teaching%20hitting%20to%20youth%20baseball%20players.png" />
            <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-navy-950/90 to-navy-950/70"></div>
          </div>

          <div className="container mx-auto px-4 sm:px-6 relative z-10 pt-24 pb-12 text-center">
            <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
              <div className="inline-flex items-center gap-2 sm:gap-3 bg-red-500/10 border border-red-500/30 rounded-full px-4 sm:px-6 py-2 sm:py-3 mb-6 sm:mb-8">
                <Quote className="text-red-500 w-4 h-4 sm:w-6 sm:h-6" />
                <span className="text-red-500 font-black text-xs sm:text-sm tracking-[0.2em] uppercase">Real Stories</span>
              </div>
              <h1 className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-black tracking-tighter text-white mb-4 sm:mb-6 leading-none font-montserrat px-2">
                <TextRevealAnimation>HEAR WHAT PARENTS & <span className="text-red-500">PLAYERS ARE SAYING</span></TextRevealAnimation>
              </h1>
              <p className="text-base sm:text-xl md:text-2xl text-gray-300 leading-relaxed max-w-2xl mx-auto font-light px-4">
                Discover how Coach Steve's elite training programs have transformed athletes' games.
              </p>
            </motion.div>
          </div>
        </section>

        <section id="testimonials" className="py-16 sm:py-24 md:py-32 bg-navy-950 flex-grow">
          <div className="container mx-auto px-4 sm:px-6">
            {error ? (
              <div className="text-center py-12">
                <p className="text-red-400 mb-4 bg-red-500/10 border border-red-500/20 inline-block px-6 py-4 rounded-xl">{error}</p>
              </div>
            ) : (
              <TestimonialGrid testimonials={testimonials} loading={loading} error={error} onRetry={() => fetchTestimonials()} />
            )}
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default Testimonials;