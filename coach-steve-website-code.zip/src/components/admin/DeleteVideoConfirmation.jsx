import React, { useState } from 'react';
import { AlertTriangle } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';

const DeleteVideoConfirmation = ({ isOpen, onClose, onSuccess, video }) => {
  const { toast } = useToast();
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDelete = async () => {
    if (!video) return;
    setIsDeleting(true);

    try {
      const { error } = await supabase
        .from('training_videos')
        .delete()
        .eq('id', video.id);

      if (error) throw error;

      toast({
        title: "Deleted",
        description: "Video has been permanently removed.",
      });
      
      onSuccess();
    } catch (error) {
      console.error('Error deleting video:', error);
      toast({
        title: "Error",
        description: "Failed to delete video. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsDeleting(false);
    }
  };

  if (!isOpen || !video) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-navy-950/80 backdrop-blur-sm">
      <div className="bg-navy-900 rounded-xl border border-gray-800 w-full max-w-md overflow-hidden shadow-2xl p-6 text-center">
        <div className="w-16 h-16 bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
          <AlertTriangle className="w-8 h-8 text-red-500" />
        </div>
        
        <h2 className="text-xl font-black text-white mb-2">Delete Video?</h2>
        <p className="text-gray-400 mb-6">
          Are you sure you want to delete <span className="text-white font-bold">"{video.title}"</span>? This action cannot be undone.
        </p>

        <div className="flex justify-center gap-3">
          <button
            type="button"
            onClick={onClose}
            disabled={isDeleting}
            className="px-6 py-2 rounded-lg font-bold text-gray-300 hover:bg-white/5 transition-colors border border-gray-700"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleDelete}
            disabled={isDeleting}
            className="px-6 py-2 bg-red-600 text-white font-black rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50"
          >
            {isDeleting ? 'Deleting...' : 'Delete'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default DeleteVideoConfirmation;