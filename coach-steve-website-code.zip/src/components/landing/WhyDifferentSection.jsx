import React from 'react';
import { motion } from 'framer-motion';
import { Flame } from 'lucide-react';

const WhyDifferentSection = () => {
  const points = ["You're not running generic drills.", "You're not copying someone else's swing.", "You're not guessing in games."];
  return (
    <section className="py-24 bg-[#0f1419] relative">
      {/* Background Accent */}
      <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-[#d4af37]/5 to-transparent pointer-events-none"></div>

      <div className="container mx-auto px-4 max-w-5xl">
        <motion.div 
          initial={{ opacity: 0, y: 20 }} 
          whileInView={{ opacity: 1, y: 0 }} 
          viewport={{ once: true }} 
          className="text-center mb-16"
        >
          <div className="inline-block bg-[#d4af37] text-black font-bold px-3 py-1 text-sm rounded-sm mb-4 uppercase tracking-wider">
            Personalized Attention
          </div>
          <h2 className="font-montserrat font-black text-4xl sm:text-5xl md:text-6xl text-white mb-6">
            This Isn't <span className="text-gray-600 line-through decoration-[#d4af37]">Team Practice</span>.
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {points.map((point, index) => (
            <motion.div 
              key={index} 
              initial={{ opacity: 0, scale: 0.9 }} 
              whileInView={{ opacity: 1, scale: 1 }} 
              viewport={{ once: true }} 
              transition={{ delay: index * 0.15 }} 
              className="bg-[#0a0e12] p-8 rounded-lg border border-gray-800 text-center hover:border-[#d4af37] transition-all group"
            >
              <Flame className="w-12 h-12 text-red-500/50 mx-auto mb-6 group-hover:text-red-500 transition-colors" />
              <p className="text-xl font-bold text-gray-300 group-hover:text-white transition-colors">
                {point}
              </p>
            </motion.div>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0 }} 
          whileInView={{ opacity: 1 }} 
          viewport={{ once: true }} 
          transition={{ delay: 0.5 }} 
          className="bg-gradient-to-r from-[#0a0e12] via-[#161b22] to-[#0a0e12] p-8 md:p-12 rounded-2xl border border-[#d4af37]/30 text-center relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
          <Flame className="w-16 h-16 text-[#d4af37] mx-auto mb-6 opacity-80" />
          <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">Custom Plans Based on Your Player's Goals</h3>
          <p className="text-gray-300 text-lg md:text-xl leading-relaxed max-w-3xl mx-auto">
            Every session is built around you — your swing, your body, your mindset, and the situations you face in real games. We build a roadmap for <span className="text-[#d4af37] font-bold">your specific success</span>.
          </p>
        </motion.div>
      </div>
    </section>
  );
};
export default WhyDifferentSection;