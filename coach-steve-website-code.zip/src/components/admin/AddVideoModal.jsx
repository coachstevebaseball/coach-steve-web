import React, { useState } from 'react';
import { X } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { categories } from '@/data/trainingVideos';

const AddVideoModal = ({ isOpen, onClose, onSuccess }) => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    url: '',
    category: 'TRAINING',
    thumbnailUrl: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.title || !formData.url) {
      toast({
        title: "Validation Error",
        description: "Title and Video URL are required.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    try {
      // Extract a potential YouTube ID for the video_id field
      let videoId = '';
      if (formData.url.includes('youtube.com/watch?v=')) {
        videoId = new URL(formData.url).searchParams.get('v');
      } else if (formData.url.includes('youtu.be/')) {
        videoId = formData.url.split('youtu.be/')[1].split('?')[0];
      }

      const { error } = await supabase
        .from('training_videos')
        .insert({
          title: formData.title,
          description: formData.description,
          url: formData.url,
          video_id: videoId || formData.url, 
          category: formData.category,
          thumbnail: formData.thumbnailUrl || (videoId ? `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg` : ''),
          type: videoId ? 'youtube' : 'video',
          created_at: new Date().toISOString()
        });

      if (error) throw error;

      toast({
        title: "Success!",
        description: "Video has been added successfully.",
      });
      
      setFormData({ title: '', description: '', url: '', category: 'TRAINING', thumbnailUrl: '' });
      onSuccess();
    } catch (error) {
      console.error('Error adding video:', error);
      toast({
        title: "Error",
        description: "Failed to add video. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  const availableCategories = categories && categories.length > 0 
    ? categories.filter(c => c !== 'ALL') 
    : ['TRAINING', 'HITTING', 'FIELDING', 'PITCHING', 'MINDSET'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-navy-950/80 backdrop-blur-sm">
      <div className="bg-navy-900 rounded-xl border border-gray-800 w-full max-w-2xl overflow-hidden shadow-2xl">
        <div className="flex justify-between items-center p-6 border-b border-gray-800">
          <h2 className="text-xl font-black text-white">Add New Video</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-bold text-gray-300 mb-1">Title <span className="text-red-500">*</span></label>
            <input
              required
              type="text"
              name="title"
              value={formData.title}
              onChange={handleChange}
              className="w-full bg-navy-950 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-gold-500 focus:outline-none"
              placeholder="Enter video title"
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-300 mb-1">Description</label>
            <textarea
              name="description"
              rows="3"
              value={formData.description}
              onChange={handleChange}
              className="w-full bg-navy-950 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-gold-500 focus:outline-none resize-none"
              placeholder="Enter video description"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-bold text-gray-300 mb-1">Video URL <span className="text-red-500">*</span></label>
              <input
                required
                type="url"
                name="url"
                value={formData.url}
                onChange={handleChange}
                placeholder="https://youtube.com/..."
                className="w-full bg-navy-950 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-gold-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-300 mb-1">Category</label>
              <select
                name="category"
                value={formData.category}
                onChange={handleChange}
                className="w-full bg-navy-950 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-gold-500 focus:outline-none"
              >
                {availableCategories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-300 mb-1">Thumbnail URL (Optional)</label>
            <input
              type="url"
              name="thumbnailUrl"
              value={formData.thumbnailUrl}
              onChange={handleChange}
              placeholder="Leave blank to auto-generate from YouTube URL"
              className="w-full bg-navy-950 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-gold-500 focus:outline-none"
            />
          </div>

          <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-gray-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg font-bold text-gray-300 hover:bg-white/5 transition-colors border border-transparent hover:border-gray-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2 bg-gradient-to-r from-gold-500 to-gold-600 text-navy-950 font-black rounded-lg hover:scale-105 transition-transform disabled:opacity-50 disabled:hover:scale-100"
            >
              {isSubmitting ? 'Saving...' : 'Save Video'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddVideoModal;