import React from 'react';
import { AlertCircle } from 'lucide-react';

const VideoPlayer = ({ video }) => {
  // Guard against undefined or null video prop
  if (!video) {
    return (
      <div className="relative w-full pb-[56.25%] bg-navy-950 rounded-xl overflow-hidden shadow-2xl border border-gray-800 flex items-center justify-center">
        <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-400 p-4 text-center">
          <AlertCircle className="w-12 h-12 mb-3 text-red-500/50" />
          <p className="font-medium">Video data is missing or unavailable.</p>
        </div>
      </div>
    );
  }

  // Determine if it's an MP4 file based on type property or URL extension
  const isMp4 = video.type === 'mp4' || (video.url && video.url.endsWith('.mp4'));

  return (
    <div className="relative w-full pb-[56.25%] bg-black rounded-xl overflow-hidden shadow-2xl border border-gray-800">
      {isMp4 ? (
        video.url ? (
          <video 
            controls 
            autoPlay 
            className="absolute top-0 left-0 w-full h-full object-contain bg-black"
            playsInline
          >
            <source src={video.url} type="video/mp4" />
            Your browser does not support the video tag.
          </video>
        ) : (
          <div className="absolute inset-0 flex items-center justify-center text-gray-400">
            Invalid video URL source.
          </div>
        )
      ) : (
        video.id ? (
          <iframe
            src={`https://www.youtube.com/embed/${video.id}?autoplay=1`}
            title={video.title || "YouTube video player"}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            className="absolute top-0 left-0 w-full h-full"
          />
        ) : (
           <div className="absolute inset-0 flex items-center justify-center text-gray-400">
            Invalid video ID source.
          </div>
        )
      )}
    </div>
  );
};

export default VideoPlayer;