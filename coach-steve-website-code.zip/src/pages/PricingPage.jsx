import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Check, Star } from 'lucide-react';
import MeetCoachSection from '@/components/landing/MeetCoachSection.jsx';

const PricingPage = () => {
  const packages = [
    {
      tier: "STARTER",
      sessions: 12,
      total: 720,
      perSession: 60,
      label: "12-Session Pack",
      badge: null,
      description: "The entry point. Premium instruction with no long-term commitment — perfect for new players and families who want to experience the process before going all in.",
      includes: [
        "Baseline swing evaluation & development plan",
        "Blast Motion swing analytics every session",
        "Session video breakdowns",
        "Access to Coach Steve's drill library"
      ],
      tagline: "Premium instruction. No discount. No fluff. Just results.",
      highlight: false,
      color: "border-white-800 hover:border-red-500/40",
      badgeBg: null,
    },
    {
      tier: "DEVELOPMENT",
      sessions: 24,
      total: 1320,
      perSession: 55,
      bonus: "2 FREE sessions ($240 value)",
      label: "24-Session Pack",
      badge: "Most Popular",
      description: "This is where real development happens. Enough sessions to build, reinforce, and translate mechanics into game performance.",
      includes: [
        "2 FREE bonus 1-hour sessions",
        "Personalized training plan updated every 4 sessions",
        "200+ drill library with custom assigned drills",
        "Blast Motion swing analytics every session",
        "Session video breakdowns",
        "Direct access to Coach Steve between sessions"
      ],
      tagline: "Most families choose this package. The sweet spot between commitment and results.",
      highlight: true,
      color: "border-red-500/70 shadow-2xl shadow-red-500/10",
      badgeBg: "bg-red-500",
    },
    {
      tier: "ELITE",
      sessions: 48,
      total: 2400,
      perSession: 50,
      bonus: "4 FREE sessions ($480 value)",
      label: "48-Session Pack",
      badge: "Most Popular for ages 12-16",
      description: "The complete development cycle. Enough time to fully rebuild mechanics, develop baseball IQ, and make improvements stick under real game pressure.",
      includes: [
        "4 FREE bonus 1-hour sessions",
        "Advanced AI swing analysis",
        "Weekly progress reports with updated metrics",
        "Priority booking & schedule lock-in",
        "Custom hitting portal with 200+ drills",
        "Session notes, swing video & metric tracking"
      ],
      tagline: "Maximum commitment. Maximum results.",
      highlight: true,
      color: "border-gray-800 hover:border-red-500/40",
      badgeBg: "bg-red-500",
    },
    {
      tier: "PRO TRACK",
      sessions: 72,
      total: 3240,
      perSession: 45,
      bonus: "6 FREE sessions ($720 value)",
      label: "72-Session Pack",
      badge: "All In",
      description: "Built for the player who is all in. College-bound athletes, elite travel players, and anyone chasing the highest level of the game.",
      includes: [
        "6 FREE bonus 1-hour sessions",
        "Everything in the Elite Transformation plan",
        "Monthly 1-on-1 video consultation calls",
        "College recruiting exposure guidance",
        "Custom multi-year development roadmap",
        "VIP priority booking & unlimited drill library updates"
      ],
      tagline: "Total commitment to reaching the highest level.",
      highlight: false,
      color: "border-gray-800 hover:border-red-500/40",
      badgeBg: null,
    }
  ];

  const includedInAll = [
    {
      icon: "📋",
      title: "Personalized Training Plans",
      desc: "No two players are the same. Every session is built around your mechanics, your data, and your goals."
    },
    {
      icon: "🎥",
      title: "Session Video Breakdowns",
      desc: "Key drills are recorded and broken down using markup tools — you see the progress, not just feel it."
    },
    {
      icon: "📊",
      title: "Blast Motion Swing Analytics",
      desc: "Bat speed, attack angle, rotational acceleration, time to contact, and on-plane efficiency tracked every session."
    },
    {
      icon: "🎯",
      title: "200+ Drill Library Access",
      desc: "Personally created by Coach Steve and assigned based on your specific development needs."
    }
  ];

  return (
    <>
      <Helmet>
        <title>Lesson Pricing & Packages | Coach Steve Baseball</title>
        <meta name="description" content="View pricing for private baseball hitting lessons and training packages with Coach Steve on Long Island, NY." />
        <link rel="canonical" href="https://www.coachstevebaseball.com/pricing" />
        <meta property="og:title" content="Lesson Pricing & Packages | Coach Steve Baseball" />
        <meta property="og:url" content="https://www.coachstevebaseball.com/pricing" />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="https://tqczkvytkkrfomyosbjp.supabase.co/storage/v1/object/public/website-assets/cs-dogpile.png" />
        <meta property="og:image:alt" content="Lesson Pricing & Packages" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Lesson Pricing & Packages | Coach Steve Baseball" />
      </Helmet>

      <div className="min-h-screen bg-navy-950 text-white font-sans overflow-x-hidden">
        {/* Meet Coach Hero Section */}
        <MeetCoachSection />

        {/* Pricing Cards Section */}
        <section className="py-16 md:py-28 bg-navy-900 px-4 md:px-6 lg:px-8 border-t border-gray-800">
          <div className="container mx-auto max-w-7xl">

            {/* Header */}
            <div className="text-center mb-12">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="inline-flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-full px-4 py-1.5 mb-6"
              >
                <Star className="text-red-500 w-3.5 h-3.5" fill="currentColor" />
                <span className="text-red-500 font-black text-xs tracking-widest uppercase">Private Hitting Lessons — Nassau County & Long Island</span>
              </motion.div>
              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="text-3xl md:text-5xl font-black font-montserrat mb-4"
              >
                Choose Your <span className="text-red-500">Development Path</span>
              </motion.h1>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className="text-gray-400 max-w-2xl mx-auto text-lg font-light leading-relaxed"
              >
                Each session is 30 minutes. Most players combine two back-to-back into one-hour blocks — that's the most effective format. Every package is built around your player's goals, not a generic program.
              </motion.p>
            </div>

            {/* Package Cards */}
            <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-6 mb-16">
              {packages.map((pkg, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className={`relative bg-navy-950 border rounded-2xl p-7 flex flex-col transition-all duration-300 ${pkg.color} ${pkg.highlight ? 'ring-2 ring-red-500/40' : ''}`}
                >
                  {/* Badge */}
                  {pkg.badge && (
                    <div className={`absolute -top-3.5 left-1/2 -translate-x-1/2 ${pkg.badgeBg} text-white text-xs font-black uppercase tracking-wider py-1 px-4 rounded-full whitespace-nowrap`}>
                      {pkg.badge}
                    </div>
                  )}

                  {/* Tier Label */}
                  <p className="text-red-500 font-black text-xs tracking-[0.2em] uppercase mb-2 mt-1">{pkg.tier}</p>

                  {/* Price */}
                  <div className="mb-1">
                    <span className="text-4xl font-black text-white">${pkg.total.toLocaleString()}</span>
                  </div>
                  <p className="text-gray-400 text-sm mb-1">
                    <span className="text-white font-bold">${pkg.perSession}/session</span> · {pkg.sessions} sessions
                  </p>
                  {pkg.bonus && (
                    <p className="text-red-400 text-xs font-bold mb-4">+ {pkg.bonus}</p>
                  )}
                  {!pkg.bonus && <div className="mb-4" />}

                  <p className="text-gray-300 text-sm leading-relaxed mb-6 border-l-2 border-red-500/20 pl-3">
                    {pkg.description}
                  </p>

                  {/* Includes */}
                  <ul className="space-y-2.5 mb-8 flex-grow">
                    {pkg.includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-2.5 text-sm text-gray-300">
                        <div className="flex-shrink-0 w-4 h-4 rounded-full bg-red-500/20 border border-red-500/40 flex items-center justify-center mt-0.5">
                          <Check className="text-red-400 w-2.5 h-2.5" strokeWidth={3} />
                        </div>
                        {item}
                      </li>
                    ))}
                  </ul>

                  {/* Tagline */}
                  <p className="text-gray-500 text-xs italic mb-2 leading-relaxed">{pkg.tagline}</p>
                </motion.div>
              ))}
            </div>

            {/* What's Included In All Programs */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-navy-950 border border-gray-800 rounded-2xl p-8 md:p-12"
            >
              <h3 className="text-xl md:text-2xl font-black text-white mb-2 text-center">What Every Player Gets</h3>
              <p className="text-gray-400 text-center text-sm mb-10">Regardless of package — every player receives a fully individualized experience.</p>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {includedInAll.map((item, idx) => (
                  <div key={idx} className="flex flex-col gap-3">
                    <span className="text-2xl">{item.icon}</span>
                    <h4 className="text-white font-bold text-sm">{item.title}</h4>
                    <p className="text-white-400 text-xs leading-relaxed">{item.desc}</p>
                  </div>
                ))}
              </div>
            </motion.div>

          </div>
        </section>
      </div>
    </>
  );
};

export default PricingPage;